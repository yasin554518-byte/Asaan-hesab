# Asan Hisab Build Status — 2026-10-12

Version: `1.0.1+180`  
Application ID target: `com.asanhisab.app`

## Latest work in this continuation

- Fixed `tool/release_candidate_check.sh` so it removes Python bytecode caches before running and cleans them on exit. This prevents the release gate from failing just because earlier Python tests generated `__pycache__` folders.
- Verified the fix by deliberately creating a dummy `__pycache__`/`.pyc` before running the gate; the release candidate check passed and the cache directory count returned to zero.
- Rechecked 27 shell contract tests successfully in the latest bounded run, including Android prep/signing, backup/restore, CI artifact and permissions/security contracts, ledger invariants, lifecycle, production configuration/security, and QA APK workflow. A wider sequential test sweep exceeded the execution time budget before finishing, so this latest run does not claim all tests completed.
- ZIP package integrity is checked after packaging.

## Previously recorded source-level checks

An earlier review recorded all 60 shell-based `tool/*test.sh` contract tests passing on final runs. Three tests that exceeded a short initial per-test timeout passed when rerun with a longer timeout. The release candidate check also passed after cache cleanup. These are source/contract checks, not a Flutter build or hardware validation.

## Important limitations

- Flutter, Dart, Android SDK, ADB, and Gradle are not installed in the current build environment.
- The environment cannot currently fetch the Flutter SDK/dependencies.
- No APK or AAB has been built in this environment.
- The GitHub Actions QA workflow has not been run/verified on GitHub from this environment.
- The two-device sync contract test passed against its local test setup in the prior review; sync on two real Android phones remains unverified.

## Next required release steps

1. Push the source to an accessible GitHub repository.
2. Run the `QA Android APK` workflow and inspect its logs/artifact.
3. Run Flutter analysis/tests and build a release AAB in a Flutter-enabled CI environment.
4. Install the APK on Android hardware and test ledger calculations, backup/restore, and sync across two devices.
5. Only mark release-ready after successful build and device checks.
