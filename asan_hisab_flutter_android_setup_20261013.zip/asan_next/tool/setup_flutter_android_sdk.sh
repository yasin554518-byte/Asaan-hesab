#!/usr/bin/env bash
# Install the Flutter + Android command-line build environment for Asan Hisab.
# Run on a Linux x86_64 machine with internet access. Does not need sudo.
set -euo pipefail

FLUTTER_VERSION="${FLUTTER_VERSION:-3.41.0}"
ANDROID_API="${ANDROID_API:-35}"
ANDROID_BUILD_TOOLS="${ANDROID_BUILD_TOOLS:-35.0.0}"
ROOT_DIR="${ROOT_DIR:-$HOME/development}"
FLUTTER_DIR="${FLUTTER_DIR:-$ROOT_DIR/flutter}"
ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$HOME/Android/Sdk}"
CMDLINE_TOOLS_URL="${CMDLINE_TOOLS_URL:-https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip}"

for cmd in curl tar unzip java; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Missing required command: $cmd" >&2; exit 1; }
done
mkdir -p "$ROOT_DIR" "$ANDROID_SDK_ROOT/cmdline-tools"

if [[ ! -x "$FLUTTER_DIR/bin/flutter" ]]; then
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  archive="$tmp/flutter.tar.xz"
  url="https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_${FLUTTER_VERSION}-stable.tar.xz"
  echo "Downloading Flutter ${FLUTTER_VERSION}..."
  curl --fail --location --retry 3 --output "$archive" "$url"
  tar -xJf "$archive" -C "$ROOT_DIR"
fi

if [[ ! -x "$ANDROID_SDK_ROOT/cmdline-tools/latest/bin/sdkmanager" ]]; then
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  archive="$tmp/android-cmdline-tools.zip"
  echo "Downloading Android command-line tools..."
  curl --fail --location --retry 3 --output "$archive" "$CMDLINE_TOOLS_URL"
  unzip -q "$archive" -d "$tmp/unpacked"
  rm -rf "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools/latest"
  cp -a "$tmp/unpacked/cmdline-tools/." "$ANDROID_SDK_ROOT/cmdline-tools/latest/"
fi

export ANDROID_HOME="$ANDROID_SDK_ROOT"
export ANDROID_SDK_ROOT
export PATH="$FLUTTER_DIR/bin:$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools:$PATH"

flutter config --android-sdk "$ANDROID_SDK_ROOT"
flutter precache --android
yes | sdkmanager --licenses >/dev/null || true
sdkmanager \
  "platform-tools" \
  "platforms;android-${ANDROID_API}" \
  "build-tools;${ANDROID_BUILD_TOOLS}" \
  "cmdline-tools;latest"
flutter doctor -v

echo
echo "Flutter + Android SDK setup finished. Add these lines to your shell profile:"
echo "export ANDROID_HOME=\"$ANDROID_SDK_ROOT\""
echo "export ANDROID_SDK_ROOT=\"$ANDROID_SDK_ROOT\""
echo "export PATH=\"$FLUTTER_DIR/bin:$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools:\$PATH\""
