# د Flutter او Android SDK د نصب لارښود

دا سکریپټ د Linux x86_64 کمپیوټر لپاره دی؛ په ChatGPT کې د کاروونکي موبایل ته له لرې نصب نه شي کولای.

## د اړتیا وړ شیان
- فعال انټرنېټ (د Flutter او Android SDK فایلونه لوی دي)
- Java/JDK، `curl`، `tar` او `unzip`
- کافي خالي ډیسک ځای

## نصب
د پروژې په فولډر کې دا اجرا کړئ:

```bash
chmod +x tool/setup_flutter_android_sdk.sh
./tool/setup_flutter_android_sdk.sh
```

سکریپټ Flutter 3.41.0، Android command-line tools، platform-tools، Android API 35 او Build Tools 35.0.0 نصبوي. د نسخې بدلون د چاپېریالي متغیرونو له لارې کېدای شي.

## د Asan Hisab د QA جوړول
له نصب وروسته د پروژې په اصلي فولډر کې:

```bash
./tool/prepare_android.sh
flutter pub get
dart analyze
flutter test
flutter build apk --debug
```

د APK متوقع مسیر:
`build/app/outputs/flutter-apk/app-debug.apk`

دا مسیر یوازې هغه وخت موجودېږي چې د جوړولو ټولې مرحلې بریالۍ شي. د خپرولو لپاره signed APK/AAB، د production backend ترتیب، او د واقعي وسیلو ازموینې جلا اړتیاوې دي.
