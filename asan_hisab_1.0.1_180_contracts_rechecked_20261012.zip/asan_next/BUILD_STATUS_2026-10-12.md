# Asan Hisab Build Status — 2026-10-12

Version: `1.0.1+180`  
Application ID target: `com.asanhisab.app`

## Checks executed in this review

All 60 shell-based `tool/*test.sh` contract tests passed on final runs. Three tests exceeded a short initial per-test timeout and were rerun with a longer timeout; they passed on rerun. Coverage includes Android preparation/signing contracts, CI and QA workflow structure/security/artifacts, release manifest/provenance/checksum integrity, ledger and statement invariants, backup/restore safety, and sync queue/scheduler/two-device API contract behavior.

The release candidate check had previously passed after generated Python cache files were removed from the source tree. This is source/contract validation, not a Flutter build or hardware validation.

## Important limitations

- Flutter, Dart, Android SDK, ADB, and Gradle are not installed in the current build environment.
- The environment cannot currently fetch the Flutter SDK/dependencies.
- No APK or AAB was built in this environment.
- The GitHub Actions QA workflow has not been run/verified on GitHub from this environment.
- The two-device sync contract test passed against its local test setup; sync on two real Android phones remains unverified.

## Next required release steps

1. Push the source to an accessible GitHub repository.
2. Run the `QA Android APK` workflow and inspect its logs/artifact.
3. Run Flutter analysis/tests and build a release AAB in a Flutter-enabled CI environment.
4. Install the APK on Android hardware and test ledger calculations, backup/restore, and sync across two devices.
5. Only mark release-ready after successful build and device checks.
