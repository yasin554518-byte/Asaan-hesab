# Asan Hisab build status — 2026-10-12

Project version: 1.0.1+180
Android application ID: com.asanhisab.app

## Checks run in this environment

The following checks completed successfully on the current source snapshot:

- QA APK workflow contract
- Android prepare contract
- Release static invariants
- CI workflow structure contract
- Sync queue idempotency contract
- Latest-backup discovery contract
- API security headers contract
- Release candidate check (1.0.1+180)

The release-candidate check first reported generated Python `__pycache__` files in the working tree. Those generated cache files were removed, and the release-candidate check was run again successfully.

## Not verified / remaining blockers

- Flutter and Dart SDKs are not installed in this execution environment.
- `flutter pub get`, `dart analyze`, `flutter test`, and actual APK/AAB builds have not been run here.
- GitHub Actions has not been triggered or observed from this environment.
- No physical Android install test or real two-device sync test has been completed.
- A successful contract/static check is not equivalent to a compiled or release-ready app.

## Next required validation

Run `.github/workflows/qa-apk.yml` in a connected GitHub repository. Confirm that dependency resolution, Dart analysis, Flutter tests, and the debug APK build all pass. Then run the release workflow to build the AAB, and install/test the APK on Android, including backup/restore and sync between two devices.
