#!/usr/bin/env bash
set -euo pipefail
if [[ $# -lt 1 || $# -gt 2 ]]; then
  echo "Usage: $0 <app-build.gradle[.kts]> [application-id]" >&2
  exit 2
fi
FILE="$1"
EXPECTED="${2:-com.asanhisab.app}"
[[ -f "$FILE" ]] || { echo "ERROR: Android Gradle file not found: $FILE" >&2; exit 1; }
if [[ ! "$EXPECTED" =~ ^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$ ]]; then
  echo "ERROR: invalid Android application ID: $EXPECTED" >&2
  exit 2
fi
# Handle modern Kotlin/Groovy assignment syntax and older Groovy DSL syntax.
sed -i -E "s/^([[:space:]]*namespace[[:space:]]*=?[[:space:]]*).*/\\1\\\"$EXPECTED\\\"/" "$FILE"
sed -i -E "s/^([[:space:]]*applicationId[[:space:]]*=?[[:space:]]*).*/\\1\\\"$EXPECTED\\\"/" "$FILE"
namespace_count="$(grep -Ec '^[[:space:]]*namespace([[:space:]]|=)' "$FILE" || true)"
application_id_count="$(grep -Ec '^[[:space:]]*applicationId([[:space:]]|=)' "$FILE" || true)"
if [[ "$namespace_count" -ne 1 || "$application_id_count" -ne 1 ]]; then
  echo "ERROR: expected exactly one namespace and applicationId in $FILE (found $namespace_count / $application_id_count)." >&2
  exit 1
fi
grep -Eq "^[[:space:]]*namespace[[:space:]]*=?[[:space:]]*\\\"$EXPECTED\\\"[[:space:]]*$" "$FILE" || { echo "ERROR: failed to normalize namespace in $FILE" >&2; exit 1; }
grep -Eq "^[[:space:]]*applicationId[[:space:]]*=?[[:space:]]*\\\"$EXPECTED\\\"[[:space:]]*$" "$FILE" || { echo "ERROR: failed to normalize applicationId in $FILE" >&2; exit 1; }
echo "PASS: Android namespace and applicationId set to $EXPECTED in $FILE"
