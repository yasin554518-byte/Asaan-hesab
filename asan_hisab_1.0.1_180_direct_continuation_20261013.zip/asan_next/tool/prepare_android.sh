#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

# Generate the Android host project without replacing application source/assets.
# The package id is pinned before the first Play publication.
if ! command -v flutter >/dev/null 2>&1; then
  echo "ERROR: Flutter SDK is required to generate Android platform files." >&2
  exit 1
fi

flutter create \
  --platforms=android \
  --project-name asan_hisab \
  --org com.asanhisab \
  --overwrite \
  .

EXPECTED='com.asanhisab.app'
APP_GRADLE='android/app/build.gradle'
APP_KTS='android/app/build.gradle.kts'
MANIFEST='android/app/src/main/AndroidManifest.xml'

# Flutter templates have varied between Groovy and Kotlin DSL and between
# assignment and legacy Groovy syntax. Normalize both supported app modules.
if [[ -f "$APP_GRADLE" ]]; then
  "$ROOT/tool/normalize_android_gradle_identity.sh" "$APP_GRADLE" "$EXPECTED"
elif [[ -f "$APP_KTS" ]]; then
  "$ROOT/tool/normalize_android_gradle_identity.sh" "$APP_KTS" "$EXPECTED"
else
  echo "ERROR: Flutter did not generate an Android app module." >&2
  exit 1
fi

# Keep the generated Kotlin/Java package declaration aligned with the app id.
find android/app/src -type f \( -name '*.kt' -o -name '*.java' \) -print0 2>/dev/null | \
  xargs -0 -r sed -i -E 's/package com\.asanhisab\.[A-Za-z0-9_]+/package com.asanhisab.app/'

# Keep the manifest label explicit as a defense-in-depth check.
if [[ -f "$MANIFEST" ]]; then
  sed -i -E 's/android:label="[^"]*"/android:label="آسان حساب"/' "$MANIFEST" || true
fi

echo "Android platform generated and normalized to $EXPECTED."
