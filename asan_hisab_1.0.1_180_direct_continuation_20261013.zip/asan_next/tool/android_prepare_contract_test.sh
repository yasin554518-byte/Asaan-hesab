#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCRIPT="$ROOT/tool/prepare_android.sh"
NORMALIZER="$ROOT/tool/normalize_android_gradle_identity.sh"
EXPECTED="com.asanhisab.app"
grep -Fq "EXPECTED='${EXPECTED}'" "$SCRIPT"
grep -Fq 'normalize_android_gradle_identity.sh' "$SCRIPT"
test -x "$NORMALIZER"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/build.gradle" <<'EOF'
android {
    namespace = "com.example.oldapp"
    defaultConfig {
        applicationId = "com.example.oldapp"
    }
}
EOF
"$NORMALIZER" "$TMP/build.gradle" "$EXPECTED" >/dev/null
grep -Eq "^[[:space:]]*namespace[[:space:]]*=[[:space:]]*\\\"$EXPECTED\\\"$" "$TMP/build.gradle"
grep -Eq "^[[:space:]]*applicationId[[:space:]]*=[[:space:]]*\\\"$EXPECTED\\\"$" "$TMP/build.gradle"
cat > "$TMP/build.gradle.kts" <<'EOF'
android {
    namespace = "com.example.oldapp"
    defaultConfig {
        applicationId = "com.example.oldapp"
    }
}
EOF
"$NORMALIZER" "$TMP/build.gradle.kts" "$EXPECTED" >/dev/null
grep -Eq "^[[:space:]]*namespace[[:space:]]*=[[:space:]]*\\\"$EXPECTED\\\"$" "$TMP/build.gradle.kts"
grep -Eq "^[[:space:]]*applicationId[[:space:]]*=[[:space:]]*\\\"$EXPECTED\\\"$" "$TMP/build.gradle.kts"
cat > "$TMP/old-style.gradle" <<'EOF'
android {
    namespace 'com.example.oldapp'
    defaultConfig {
        applicationId 'com.example.oldapp'
    }
}
EOF
"$NORMALIZER" "$TMP/old-style.gradle" "$EXPECTED" >/dev/null
grep -Eq "^[[:space:]]*namespace[[:space:]]+\\\"$EXPECTED\\\"$" "$TMP/old-style.gradle"
grep -Eq "^[[:space:]]*applicationId[[:space:]]+\\\"$EXPECTED\\\"$" "$TMP/old-style.gradle"
echo "PASS: Android prepare contract (Groovy/Kotlin and legacy syntax)"
