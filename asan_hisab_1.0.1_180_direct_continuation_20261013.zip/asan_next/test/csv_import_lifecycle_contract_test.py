from pathlib import Path

s = Path('lib/features/home/management_pages.dart').read_text()
# Verify behavior rather than a particular formatting style: the async preview
# must not update widget state after disposal, and failures must be guarded.
assert 'if (!mounted) return;\n      setState(() {' in s
assert 'preview = p;' in s
assert "catch(e){if(mounted)setState(()=>result='ستونزه: $e');}" in s
assert 'finally{if(mounted)setState(()=>busy=false);}' in s
# Import completion must also guard its post-await state update and cleanup.
assert 'if (!mounted) return;\n      setState(()=>result=' in s
assert 'finally{if(mounted)setState(()=>importing=false);}' in s
print('CSV import lifecycle contract: PASS')
