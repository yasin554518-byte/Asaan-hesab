# Asan Hisab build status — 2026-10-13

- Source version: `1.0.1+180`
- Intended Android application ID: `com.asanhisab.app`
- This archive contains source code and build helpers; it is **not** an installable APK/AAB.

## Work completed in this follow-up

- Updated `tool/prepare_android.sh` to use a dedicated Gradle identity normalizer after `flutter create`.
- Added `tool/normalize_android_gradle_identity.sh` to normalize and verify the Android `namespace` and `applicationId` for generated Groovy/Kotlin Gradle files, including older Groovy DSL syntax.
- Expanded `tool/android_prepare_contract_test.sh` to exercise both modern Groovy/Kotlin syntax and legacy Groovy syntax without requiring Flutter.

## Checks run in this environment

Passed:
- `python backend/contract_test.py`
- `python tool/two_device_sync_contract_test.py` (local contract/simulation, not two physical phones)
- `bash tool/sync_queue_idempotency_contract_test.sh`
- `bash tool/sync_manual_retry_contract_test.sh`
- `bash tool/backup_restore_recovery_contract_test.sh`
- `bash tool/qa_apk_workflow_contract_test.sh`
- `bash tool/android_prepare_contract_test.sh`
- `bash tool/android_signing_contract_test.sh`
- `bash tool/release_candidate_check.sh`

The earlier broad shell-test batch was interrupted by the execution time limit; it is not reported as a complete pass.

## Build and release blockers

Flutter, Dart, Android SDK (`sdkmanager`), `adb`, and Gradle are not installed in this environment. Network/DNS access for fetching the SDK is unavailable. Therefore:

- Android platform generation was not completed.
- `flutter pub get`, `dart analyze`, and `flutter test` have not been run here.
- No debug/release APK or AAB has been built or installed.
- The GitHub Actions QA workflow has not been triggered or observed from this environment.
- Production backend deployment, signed release artifact, and real two-device sync testing remain unverified.

## Required path to release

1. Run this source tree in a Flutter-enabled build environment or GitHub Actions.
2. Execute `tool/prepare_android.sh`, `flutter pub get`, `dart analyze`, `flutter test`, and the QA APK workflow.
3. Fix any failures surfaced by the actual Flutter/Android build.
4. Configure and verify the production sync backend and release-signing secrets.
5. Install on real Android devices; verify ledger operations, backup/restore, and sync with two devices before calling the app release-ready.
