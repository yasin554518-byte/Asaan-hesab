# Asan Hisab v107

- Version: 1.0.1+93
- Tightened release bundle manifest validation: manifest_version must be exactly 3.
- Added a contract assertion that the manifest version validation is present.
- Existing provenance, checksum, bundle identity, backend, and release preflight gates remain required.
