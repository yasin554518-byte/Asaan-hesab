# Asan Hisab v66

## Release Provenance Schema Gate

- Added a strict provenance schema validator for release metadata.
- Validates exact keys, semantic version format, release tag/ref alignment, and 64-character lowercase SHA-256.
- Rejects secret-like provenance content such as passwords, private keys, keystores, secrets, or tokens.
- Wired the schema gate into tag-based CI immediately after provenance generation.
- Added negative contract tests for secret leakage and tag/ref mismatch.
