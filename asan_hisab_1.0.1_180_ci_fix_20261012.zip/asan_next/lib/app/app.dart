import 'dart:async';
import 'package:flutter/material.dart';
import '../core/database/app_database.dart';
import '../core/security/pin_service.dart';
import '../core/security/session_service.dart';
import '../core/security/permission_service.dart';
import '../core/utils/ids.dart';
import '../core/sync/sync_config_service.dart';
import '../core/sync/rest_cloud_sync_adapter.dart';
import '../core/sync/sync_worker.dart';
import '../core/sync/sync_scheduler.dart';
import '../core/sync/device_service.dart';
import '../shared/services/dashboard_service.dart';
import '../features/home/home_shell.dart';

class AsanHisabApp extends StatelessWidget {
  final AppDatabase database;
  const AsanHisabApp({super.key, required this.database});

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'آسان حساب',
        locale: const Locale('ps'),
        supportedLocales: const [Locale('ps'), Locale('en')],
        theme: ThemeData(useMaterial3: true, fontFamily: 'NotoNaskhArabic'),
        home: BootstrapGate(database: database),
      );
}

class BootstrapGate extends StatelessWidget {
  const BootstrapGate({super.key, required this.database});
  final AppDatabase database;

  Future<String?> _businessId() async {
    final rows = await database.db.query('app_settings', where: 'key = ?', whereArgs: ['active_business_id']);
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<String?>(
        future: _businessId(),
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          final id = snapshot.data;
          return id == null
              ? SetupScreen(database: database)
              : PinGate(database: database, businessId: id);
        },
      );
}


class PinGate extends StatefulWidget {
  const PinGate({super.key, required this.database, required this.businessId});
  final AppDatabase database;
  final String businessId;

  @override
  State<PinGate> createState() => _PinGateState();
}

class _PinGateState extends State<PinGate> {
  final username = TextEditingController(text: 'owner');
  final pin = TextEditingController();
  final pinService = PinService();
  bool checking = false;
  int attempts = 0;
  DateTime? lockedUntil;
  Timer? countdownTimer;
  int secondsLeft = 0;

  Future<Map<String, Object?>?> _user() async {
    final rows = await widget.database.db.query(
      'users',
      columns: ['id', 'name', 'username', 'pin_hash', 'role', 'active'],
      where: 'business_id = ? AND username = ? AND active = 1',
      whereArgs: [widget.businessId, username.text.trim()],
      limit: 1,
    );
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> unlock() async {
    final until = lockedUntil;
    if (until != null && DateTime.now().isBefore(until)) return;
    if (!RegExp(r'^\d{4,8}$').hasMatch(pin.text)) {
      _message('PIN باید ۴ تر ۸ عددونه وي');
      return;
    }
    setState(() => checking = true);
    try {
      final user = await _user();
      final stored = user?['pin_hash']?.toString();
      if (user == null || stored == null || !pinService.verifyPin(pin.text, stored)) {
        attempts++;
        pin.clear();
        if (attempts >= 3) {
          lockedUntil = DateTime.now().add(const Duration(seconds: 30));
          _startCountdown();
          attempts = 0;
          _message('۳ ځله ناسم PIN؛ د ۳۰ ثانیو لپاره قفل شو');
        } else {
          _message('PIN ناسم دی (${3 - attempts} هڅې پاتې دي)');
        }
        return;
      }
      attempts = 0;
      pin.clear();
      if (mounted && user != null) {
        final role = switch (user['role']?.toString()) {
          'manager' => UserRole.manager,
          'cashier' => UserRole.cashier,
          _ => UserRole.owner,
        };
        Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => SessionShell(database: widget.database, businessId: widget.businessId, role: role)));
      }
    } finally {
      if (mounted) setState(() => checking = false);
    }
  }

  void _startCountdown() {
    countdownTimer?.cancel();
    void tick() {
      final until = lockedUntil;
      if (until == null) return;
      final left = until.difference(DateTime.now()).inSeconds;
      if (left <= 0) {
        countdownTimer?.cancel();
        if (mounted) setState(() { lockedUntil = null; secondsLeft = 0; });
      } else if (mounted) {
        setState(() => secondsLeft = left);
      }
    }
    tick();
    countdownTimer = Timer.periodic(const Duration(seconds: 1), (_) => tick());
  }

  void _message(String text) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    countdownTimer?.cancel();
    username.dispose();
    pin.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final locked = lockedUntil != null && DateTime.now().isBefore(lockedUntil!);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('آسان حساب • امنیت')),
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                children: [
                  const Icon(Icons.lock_outline, size: 64),
                  const SizedBox(height: 16),
                  Text('د کاروونکي Username او PIN ولیکئ', style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  TextField(
                    controller: username,
                    enabled: !locked && !checking,
                    decoration: const InputDecoration(labelText: 'Username', border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: pin,
                    obscureText: true,
                    enabled: !locked && !checking,
                    keyboardType: TextInputType.number,
                    maxLength: 8,
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(labelText: 'PIN', border: OutlineInputBorder()),
                    onSubmitted: (_) => unlock(),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: locked || checking ? null : unlock,
                    icon: const Icon(Icons.lock_open),
                    label: Text(locked ? 'بیا هڅه په $secondsLeft ثانیو کې' : checking ? 'کتل کېږي...' : 'خلاصول'),
                  ),
                  const SizedBox(height: 12),
                  const Text('۳ ناسمې هڅې وروسته لنډمهاله قفل فعالېږي.'),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SessionShell extends StatefulWidget {
  const SessionShell({super.key, required this.database, required this.businessId, required this.role});
  final AppDatabase database;
  final String businessId;
  final UserRole role;

  @override
  State<SessionShell> createState() => _SessionShellState();
}

class _SessionShellState extends State<SessionShell> with WidgetsBindingObserver {
  late final SessionService session;
  late final SyncScheduler _syncScheduler;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    session = SessionService(onLocked: _lockToPin);
    session.start();
    _syncScheduler = SyncScheduler(callback: _runAutoSync);
    _syncScheduler.start();
  }

  void _lockToPin() {
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => PinGate(database: widget.database, businessId: widget.businessId),
      ),
      (route) => false,
    );
  }

  void _touch() => session.touch();

  Future<void> _runAutoSync() async {
    if (!mounted) return;
    final cfg = SyncConfigService(widget.database);
    final url = await cfg.baseUrl();
    final token = await cfg.authToken();
    if (url == null || token == null || url.isEmpty || token.isEmpty) return;
    final adapter = RestCloudSyncAdapter(baseUrl: url, authToken: token);
    if (!adapter.isConfigured) return;
    // Let SyncScheduler observe transport/server failures so its bounded
    // exponential backoff is actually used. Local bookkeeping remains safe:
    // the scheduler catches the failure at its trigger boundary.
    await SyncWorker(widget.database, adapter).run(widget.businessId);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Lock immediately when the app leaves the foreground. This prevents
    // sensitive financial data from remaining visible in the task switcher.
    if (state == AppLifecycleState.resumed) {
      _syncScheduler.resume();
    } else if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached) {
      _syncScheduler.pause();
      session.lock();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _syncScheduler.dispose();
    session.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: _touch,
        onPanDown: (_) => _touch(),
        child: HomeShell(database: widget.database, businessId: widget.businessId, role: widget.role),
      );
}


class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key, required this.database});
  final AppDatabase database;
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final name = TextEditingController();
  final pin = TextEditingController();
  bool saving = false;

  Future<void> _create() async {
    if (name.text.trim().isEmpty || !RegExp(r'^\d{4,8}$').hasMatch(pin.text)) return;
    setState(() => saving = true);
    final now = DateTime.now().toUtc().toIso8601String();
    final businessId = newId();
    final userId = newId();
    final hash = PinService().hashPin(pin.text);
    await widget.database.db.transaction((txn) async {
      await txn.insert('businesses', {
        'id': businessId, 'name': name.text.trim(), 'currency': 'AFN', 'invoice_prefix': 'INV-',
        'next_invoice_number': 1, 'created_at': now, 'updated_at': now,
      });
      await txn.insert('users', {
        'id': userId, 'business_id': businessId, 'name': 'Owner', 'username': 'owner',
        'pin_hash': hash, 'role': 'owner', 'active': 1, 'created_at': now, 'updated_at': now,
      });
      await txn.insert('app_settings', {'key': 'active_business_id', 'value': businessId});
    });
    if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => PinGate(database: widget.database, businessId: businessId)));
  }

  @override
  void dispose() { name.dispose(); pin.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('د آسان حساب پیل')), 
          body: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'د کاروبار نوم')),
              TextField(controller: pin, keyboardType: TextInputType.number, obscureText: true, decoration: const InputDecoration(labelText: 'Owner PIN (۴–۸ عددونه)')),
              const SizedBox(height: 20),
              FilledButton(onPressed: saving ? null : _create, child: Text(saving ? 'ثبتېږي...' : 'شروع کول')),
            ]),
          ),
        ),
      );
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.database, required this.businessId});
  final AppDatabase database;
  final String businessId;

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          appBar: AppBar(title: const Text('آسان حساب')),
          body: FutureBuilder<DashboardSummary>(
            future: DashboardService(database.db).load(businessId),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              final s = snapshot.data!;
              final cards = <_CardData>[
                _CardData('د نن پلور', s.todaySales), _CardData('د نن پېرود', s.todayPurchases),
                _CardData('د نن مصارف', s.todayExpenses), _CardData('نغدې پیسې', s.cashBalance),
                _CardData('د مشتریانو قرض', s.customerDue), _CardData('د عرضه کوونکو قرض', s.supplierDue),
                _CardData('د ذخیرې ارزښت', s.stockValue), _CardData('خالصه ګټه', s.netProfit),
              ];
              return ListView(padding: const EdgeInsets.all(12), children: [
                GridView.builder(
                  shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.55, crossAxisSpacing: 10, mainAxisSpacing: 10),
                  itemCount: cards.length,
                  itemBuilder: (_, i) => Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(cards[i].title), const Spacer(), Text(cards[i].value.toString(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))]))),
                ),
                const SizedBox(height: 16),
                Wrap(spacing: 8, runSpacing: 8, children: const [
                  Chip(label: Text('➕ قرض اضافه')), Chip(label: Text('🧾 رسید/تادیه')), Chip(label: Text('🧮 ماشین حساب')),
                  Chip(label: Text('🛒 نوی پلور')), Chip(label: Text('📦 نوی پېرود')),
                ]),
              ]);
            },
          ),
        ),
      );
}

class _CardData { const _CardData(this.title, this.value); final String title; final int value; }
