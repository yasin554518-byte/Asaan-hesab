import 'package:flutter/widgets.dart';
import 'app/app.dart';
import 'core/database/app_database.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final database = await AppDatabase.open();
  runApp(AsanHisabApp(database: database));
}
