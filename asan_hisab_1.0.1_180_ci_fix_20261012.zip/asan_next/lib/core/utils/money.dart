class Money {
  static int nonNegative(int value, String field) {
    if (value < 0) throw ArgumentError('$field cannot be negative');
    return value;
  }

  static int afterDiscount({required int subtotal, required int discount}) {
    nonNegative(subtotal, 'subtotal');
    nonNegative(discount, 'discount');
    if (discount > subtotal) {
      throw ArgumentError('Discount exceeds subtotal');
    }
    return subtotal - discount;
  }

  static int remaining({required int total, required int paid}) {
    nonNegative(total, 'total');
    nonNegative(paid, 'paid');
    if (paid > total) {
      throw ArgumentError('Paid exceeds total');
    }
    return total - paid;
  }
}
