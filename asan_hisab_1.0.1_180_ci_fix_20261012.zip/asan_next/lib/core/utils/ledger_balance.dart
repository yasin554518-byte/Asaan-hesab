/// Centralized party-ledger balance arithmetic.
///
/// Customer balances increase with debit and decrease with credit.
/// Supplier balances increase with credit and decrease with debit.
class LedgerBalance {
  const LedgerBalance._();


  /// Applies aggregate debit/credit totals. Unlike a single entry, an
  /// aggregate naturally may contain both debit and credit values.
  static int fromTotals({
    required String partyType,
    required int balance,
    required int debit,
    required int credit,
  }) {
    if (debit < 0 || credit < 0) {
      throw ArgumentError('Ledger amounts cannot be negative');
    }
    final type = partyType.toUpperCase();
    if (type == 'CUSTOMER') return balance + debit - credit;
    if (type == 'SUPPLIER') return balance + credit - debit;
    throw ArgumentError('Invalid party type');
  }

  static int apply({
    required String partyType,
    required int balance,
    required int debit,
    required int credit,
  }) {
    if (debit < 0 || credit < 0) {
      throw ArgumentError('Ledger amounts cannot be negative');
    }
    if (debit > 0 && credit > 0) {
      throw ArgumentError('A ledger entry cannot contain both debit and credit');
    }
    final type = partyType.toUpperCase();
    if (type == 'CUSTOMER') return balance + debit - credit;
    if (type == 'SUPPLIER') return balance + credit - debit;
    throw ArgumentError('Invalid party type');
  }
}
