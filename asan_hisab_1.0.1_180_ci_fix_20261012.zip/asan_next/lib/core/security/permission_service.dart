enum UserRole { owner, manager, cashier }

enum Permission {
  sales,
  customers,
  suppliers,
  purchases,
  payments,
  returns,
  expenses,
  stock,
  reports,
  backup,
  restore,
  userManagement,
  settings,
}

class PermissionService {
  bool can(UserRole role, Permission permission) {
    if (role == UserRole.owner) return true;
    if (role == UserRole.manager) {
      return !{Permission.backup, Permission.restore, Permission.userManagement}.contains(permission);
    }
    return {
      Permission.sales,
      Permission.payments,
      Permission.customers,
      Permission.suppliers,
      Permission.stock,
    }.contains(permission);
  }
}
