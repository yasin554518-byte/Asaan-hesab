import '../database/app_database.dart';
import '../utils/ids.dart';

class AuditService {
  AuditService(this.database);
  final AppDatabase database;

  Future<void> log({
    required String businessId,
    String? userId,
    required String action,
    required String module,
    String? recordId,
    required String result,
    String? details,
  }) async {
    await database.db.insert('audit_logs', {
      'id': newId(),
      'business_id': businessId,
      'user_id': userId,
      'action': action,
      'module': module,
      'record_id': recordId,
      'result': result,
      'details': details,
      'created_at': DateTime.now().toUtc().toIso8601String(),
    });
  }
}
