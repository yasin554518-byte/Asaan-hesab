import 'dart:async';

class SessionService {
  SessionService({this.timeout = const Duration(minutes: 5), this.onLocked});

  final Duration timeout;
  final void Function()? onLocked;
  Timer? _timer;
  bool locked = true;

  void start() {
    locked = false;
    _resetTimer();
  }

  void touch() {
    if (!locked) _resetTimer();
  }

  void lock() {
    if (locked) return;
    locked = true;
    _timer?.cancel();
    _timer = null;
    onLocked?.call();
  }

  void _resetTimer() {
    _timer?.cancel();
    _timer = Timer(timeout, lock);
  }

  void dispose() {
    _timer?.cancel();
    _timer = null;
  }
}
