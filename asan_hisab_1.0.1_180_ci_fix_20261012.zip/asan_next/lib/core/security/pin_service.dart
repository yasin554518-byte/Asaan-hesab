import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';

class PinService {
  String _salt() {
    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));
    return base64UrlEncode(bytes);
  }

  String hashPin(String pin, {String? salt}) {
    if (!RegExp(r'^\d{4,8}$').hasMatch(pin)) {
      throw ArgumentError('PIN must contain 4 to 8 digits');
    }
    final actualSalt = salt ?? _salt();
    final digest = sha256.convert(utf8.encode('$actualSalt:$pin'));
    return '$actualSalt:${digest.toString()}';
  }

  bool verifyPin(String pin, String storedHash) {
    final parts = storedHash.split(':');
    if (parts.length != 2) return false;
    return hashPin(pin, salt: parts[0]) == storedHash;
  }
}
