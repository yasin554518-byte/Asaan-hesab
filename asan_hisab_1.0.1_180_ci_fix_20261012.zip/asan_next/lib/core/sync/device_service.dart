import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../utils/ids.dart';

/// Keeps a stable local device identity per installed app/business.
class DeviceService {
  DeviceService(this.database);
  final AppDatabase database;

  Future<String> ensureDevice(String businessId, {String deviceName = 'Android'}) async {
    return database.db.transaction((txn) => ensureDeviceInTransaction(txn, businessId: businessId, deviceName: deviceName));
  }

  /// Resolves/creates the device identity inside an existing transaction.
  /// This is used by financial writes so record + sync queue + device identity
  /// can commit or roll back as one unit.
  static Future<String> ensureDeviceInTransaction(
    DatabaseExecutor txn, {
    required String businessId,
    String deviceName = 'Android',
  }) async {
    final key = 'device_id_$businessId';
    final settings = await txn.query('app_settings', columns: ['value'], where: 'key = ?', whereArgs: [key], limit: 1);
    final savedId = settings.isNotEmpty ? settings.first['value']?.toString() : null;
    if (savedId != null && savedId.isNotEmpty) {
      final active = await txn.query('devices', columns: ['id'], where: 'id = ? AND business_id = ? AND active = 1', whereArgs: [savedId, businessId], limit: 1);
      if (active.isNotEmpty) return savedId;
    }

    final id = newId();
    final now = DateTime.now().toUtc().toIso8601String();
    await txn.insert('devices', {
      'id': id,
      'business_id': businessId,
      'device_name': deviceName,
      'device_key': newId(),
      'active': 1,
      'created_at': now,
    });
    await txn.insert('app_settings', {'key': key, 'value': id}, conflictAlgorithm: ConflictAlgorithm.replace);
    return id;
  }
}
