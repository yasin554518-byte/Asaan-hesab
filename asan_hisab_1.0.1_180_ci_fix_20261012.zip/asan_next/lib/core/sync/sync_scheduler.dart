import 'dart:async';
import 'sync_queue_service.dart';

typedef SyncCallback = Future<void> Function();

/// Coordinates safe automatic sync triggers while the Flutter session is alive.
/// It coalesces overlapping runs, retries transient failures with bounded
/// exponential backoff, and never lets a failed sync break bookkeeping.
class SyncScheduler {
  SyncScheduler({
    required this.callback,
    this.interval = const Duration(minutes: 5),
    this.maxRetryDelay = const Duration(minutes: 30),
  });

  final SyncCallback callback;
  final Duration interval;
  final Duration maxRetryDelay;
  Timer? _timer;
  bool _running = false;
  bool _disposed = false;
  bool _paused = false;
  int _consecutiveFailures = 0;
  Object? _lastError;
  DateTime? _lastAttemptAt;
  DateTime? _lastSuccessAt;
  DateTime? _lastFailureAt;

  bool get isRunning => _running;
  bool get isPaused => _paused;
  int get consecutiveFailures => _consecutiveFailures;
  Object? get lastError => _lastError;
  DateTime? get lastAttemptAt => _lastAttemptAt;
  DateTime? get lastSuccessAt => _lastSuccessAt;
  DateTime? get lastFailureAt => _lastFailureAt;

  /// Immediately retries the sync operation, bypassing any pending backoff.
  /// A running sync is still protected by the single-flight guard.
  Future<void> retryNow() async {
    if (_disposed || _paused || _running) return;
    _timer?.cancel();
    _timer = null;
    _consecutiveFailures = 0;
    await trigger();
  }

  void start() {
    if (_disposed) return;
    _paused = false;
    _timer?.cancel();
    _timer = null;
    _scheduleNext(Duration.zero);
  }

  /// Pauses all automatic scheduling while the app is not in the foreground.
  /// An in-flight callback is allowed to finish; no new trigger is started.
  void pause() {
    if (_disposed) return;
    _paused = true;
    _timer?.cancel();
    _timer = null;
  }

  /// Resumes automatic scheduling after returning to the foreground.
  /// By default it performs one immediate sync attempt.
  void resume({bool runImmediately = true}) {
    if (_disposed) return;
    _paused = false;
    _timer?.cancel();
    _timer = null;
    if (runImmediately) {
      _scheduleNext(Duration.zero);
    } else {
      _scheduleNext(interval);
    }
  }

  void _scheduleNext(Duration delay) {
    if (_disposed || _paused) return;
    _timer?.cancel();
    _timer = Timer(delay, () => trigger());
  }

  /// Exposes the scheduler's durable retry policy for deterministic tests and UI diagnostics.
  static Duration retryDelay(int consecutiveFailures) {
    final minutes = SyncQueueService.retryDelayMinutes(consecutiveFailures - 1);
    return Duration(minutes: minutes);
  }

  Duration _retryDelay() {
    // Keep scheduler retries aligned with SyncQueueService's durable retry
    // policy: 1, 2, 4, 8, 16 minutes, capped at 30 minutes. The normal
    // success interval remains configurable and is intentionally separate.
    final base = retryDelay(_consecutiveFailures);
    final maxSeconds = maxRetryDelay.inSeconds;
    return Duration(seconds: base.inSeconds.clamp(1, maxSeconds));
  }

  Future<void> trigger() async {
    if (_disposed || _paused || _running) return;
    _running = true;
    _lastAttemptAt = DateTime.now().toUtc();
    _timer?.cancel();
    _timer = null;
    try {
      await callback();
      _consecutiveFailures = 0;
      _lastError = null;
      _lastSuccessAt = DateTime.now().toUtc();
      _scheduleNext(interval);
    } catch (error) {
      _lastError = error;
      _lastFailureAt = DateTime.now().toUtc();
      _consecutiveFailures++;
      _scheduleNext(_retryDelay());
    } finally {
      _running = false;
    }
  }

  void dispose() {
    _disposed = true;
    _timer?.cancel();
    _timer = null;
  }
}
