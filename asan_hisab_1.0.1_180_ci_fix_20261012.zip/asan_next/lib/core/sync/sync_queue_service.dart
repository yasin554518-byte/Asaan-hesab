import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../utils/ids.dart';

class SyncQueueStatus {
  static const pending = 'pending';
  static const retry = 'retry';
  static const synced = 'synced';
  static const failed = 'failed';
  static const conflict = 'conflict';
}

class SyncQueueService {
  SyncQueueService(this.database);
  final AppDatabase database;

  Future<String> enqueue({
    required String businessId,
    required String recordId,
    required String tableName,
    required String operation,
    required String deviceId,
    required int version,
    required Map<String, dynamic> payload,
  }) async {
    return database.db.transaction((txn) => enqueueInTransactionStatic(
      txn,
      businessId: businessId,
      recordId: recordId,
      tableName: tableName,
      operation: operation,
      deviceId: deviceId,
      version: version,
      payload: payload,
    ));
  }

  /// Enqueues an operation using the caller's transaction.
  ///
  /// Financial writes use this method so the source record and its durable
  /// sync envelope commit atomically. If the transaction rolls back, no local
  /// record can be left behind without a corresponding sync operation.
  static Future<String> enqueueInTransactionStatic(
    DatabaseExecutor txn, {
    required String businessId,
    required String recordId,
    required String tableName,
    required String operation,
    required String deviceId,
    required int version,
    required Map<String, dynamic> payload,
  }) async {
    final existing = await txn.query(
      'sync_queue',
      columns: ['id'],
      where: 'business_id = ? AND record_id = ? AND table_name = ? AND operation = ? AND device_id = ? AND version = ?',
      whereArgs: [businessId, recordId, tableName, operation, deviceId, version],
      limit: 1,
    );
    if (existing.isNotEmpty) return existing.first['id'] as String;

    final id = newId();
    await txn.insert(
      'sync_queue',
      {
        'id': id,
        'business_id': businessId,
        'record_id': recordId,
        'table_name': tableName,
        'operation': operation,
        'device_id': deviceId,
        'version': version,
        'payload': jsonEncode(payload),
        'status': SyncQueueStatus.pending,
        'retry_count': 0,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
    final canonical = await txn.query(
      'sync_queue',
      columns: ['id'],
      where: 'business_id = ? AND record_id = ? AND table_name = ? AND operation = ? AND device_id = ? AND version = ?',
      whereArgs: [businessId, recordId, tableName, operation, deviceId, version],
      limit: 1,
    );
    return canonical.first['id'] as String;
  }

  Future<List<Map<String, Object?>>> pending(String businessId, {int limit = 100}) async {
    // Retry with bounded exponential backoff so a temporarily unavailable
    // server cannot cause a tight retry loop. Pending items are always eligible;
    // retry items wait 1, 2, 4, ... minutes up to 30 minutes.
    // Filter retry eligibility in SQLite before applying the limit. The old
    // limit*2 prefetch could starve an older eligible retry behind many newer
    // ineligible rows, delaying financial operations indefinitely.
    final rows = await database.db.query(
      'sync_queue',
      where: '''business_id = ? AND (
        status = ? OR
        (status = ? AND (
          last_attempt_at IS NULL OR
          datetime(last_attempt_at) <= datetime(
            'now',
            '-' || CASE
              WHEN retry_count <= 0 THEN 1
              WHEN retry_count = 1 THEN 2
              WHEN retry_count = 2 THEN 4
              WHEN retry_count = 3 THEN 8
              ELSE 16
            END || ' minutes'
          )
        ))
      )''',
      whereArgs: [businessId, SyncQueueStatus.pending, SyncQueueStatus.retry],
      orderBy: 'created_at ASC',
      limit: limit,
    );
    return rows;
  }

  /// Returns the bounded exponential delay for a failed sync attempt.
  /// 0=>1m, 1=>2m, 2=>4m, 3=>8m, 4+=>16m (capped at 30m).
  static int retryDelayMinutes(int retryCount) {
    final exponent = retryCount.clamp(0, 4).toInt();
    return (1 << exponent).clamp(1, 30).toInt();
  }

  Future<Map<String, int>> counts(String businessId) async {
    final rows = await database.db.rawQuery(
      'SELECT status, COUNT(*) AS c FROM sync_queue WHERE business_id = ? GROUP BY status',
      [businessId],
    );
    return {for (final r in rows) (r['status'] as String): (r['c'] as num).toInt()};
  }

  Future<bool> wasApplied(String operationId) async {
    final rows = await database.db.query('sync_operations', columns: ['operation_id'], where: 'operation_id = ?', whereArgs: [operationId], limit: 1);
    return rows.isNotEmpty;
  }

  Future<void> recordApplied({required String operationId, required String businessId, required String recordId, required String operation}) async {
    await database.db.insert('sync_operations', {
      'operation_id': operationId,
      'business_id': businessId,
      'record_id': recordId,
      'operation': operation,
      'applied_at': DateTime.now().toUtc().toIso8601String(),
    }, conflictAlgorithm: ConflictAlgorithm.ignore);
  }

  Future<void> markSynced(String id) async {
    await database.db.update('sync_queue', {'status': SyncQueueStatus.synced}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> markFailed(String id) async {
    await database.db.update('sync_queue', {'status': SyncQueueStatus.failed, 'last_attempt_at': DateTime.now().toUtc().toIso8601String()}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> markConflict(String id) async {
    await database.db.update('sync_queue', {'status': SyncQueueStatus.conflict, 'last_attempt_at': DateTime.now().toUtc().toIso8601String()}, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> retryFailed(String businessId) async {
    // A user-initiated retry is an explicit request to try now. Reset the
    // backoff timestamp/count so a previously failed item is not silently
    // delayed by the automatic retry window.
    await database.db.update(
      'sync_queue',
      {'status': SyncQueueStatus.pending, 'retry_count': 0, 'last_attempt_at': null},
      where: 'business_id = ? AND status = ?',
      whereArgs: [businessId, SyncQueueStatus.failed],
    );
  }

  Future<void> markRetry(String id) async {
    await database.db.rawUpdate(
      "UPDATE sync_queue SET status = '${SyncQueueStatus.retry}', retry_count = retry_count + 1, last_attempt_at = ? WHERE id = ?",
      [DateTime.now().toUtc().toIso8601String(), id],
    );
  }
}
