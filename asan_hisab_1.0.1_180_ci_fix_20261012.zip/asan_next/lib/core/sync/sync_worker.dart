import 'dart:convert';
import 'cloud_sync_adapter.dart';
import 'sync_apply_service.dart';
import 'sync_queue_service.dart';
import '../database/app_database.dart';
import 'sync_config_service.dart';
import 'device_service.dart';

class SyncRunResult {
  const SyncRunResult({required this.processed, required this.synced, required this.conflicts, required this.skipped, required this.pullApplied, required this.pullConflicts});
  final int processed;
  final int synced;
  final int conflicts;
  final int skipped;
  final int pullApplied;
  final int pullConflicts;
}

/// Processes the local queue only when a real cloud adapter is configured.
/// Financial operations are idempotent: the operation id is recorded locally
/// before/after application so a retry cannot execute the same operation twice.
class SyncWorker {
  SyncWorker(this.database, this.adapter);
  final AppDatabase database;
  final CloudSyncAdapter adapter;

  Future<SyncRunResult> run(String businessId, {int limit = 50}) async {
    if (!adapter.isConfigured) {
      return const SyncRunResult(processed: 0, synced: 0, conflicts: 0, skipped: 0, pullApplied: 0, pullConflicts: 0);
    }

    final queue = SyncQueueService(database);
    final rows = await queue.pending(businessId, limit: limit);

    final envelopes = <SyncEnvelope>[];
    final ids = <String>[];
    for (final row in rows) {
      final id = row['id'] as String;
      ids.add(id);
      final payload = jsonDecode(row['payload'] as String) as Map<String, dynamic>;
      envelopes.add(SyncEnvelope(
        operationId: id,
        recordId: row['record_id'] as String,
        tableName: row['table_name'] as String,
        operation: row['operation'] as String,
        deviceId: row['device_id'] as String,
        version: (row['version'] as num).toInt(),
        payload: payload,
      ));
    }

    var processed = 0;
    var synced = 0;
    var conflicts = 0;
    var skipped = 0;

    if (envelopes.isNotEmpty) {
      SyncPushResult result;
      try {
        result = await adapter.push(businessId: businessId, operations: envelopes);
      } catch (error, stackTrace) {
        // A transport/auth/server failure must not leave rows permanently in
        // 'pending'. Move the whole attempted batch to retry, then propagate
        // the failure so SyncScheduler can apply its bounded exponential
        // backoff. Treating a failed push as a successful sync would otherwise
        // reset the retry counter and delay recovery.
        for (final id in ids) {
          await queue.markRetry(id);
        }
        Error.throwWithStackTrace(error, stackTrace);
      }
      // Only count/mark operation IDs that belong to the batch we actually
      // pushed. A defensive server response must not inflate counters or
      // accidentally mark an unrelated local queue item as synced/conflict.
      final pushedIds = ids.toSet();
      final syncedIds = result.syncedOperationIds.toSet().intersection(pushedIds);
      final conflictIds = result.conflictOperationIds.toSet().intersection(pushedIds);
      for (final id in ids) {
        if (conflictIds.contains(id)) {
          await queue.markConflict(id);
        } else if (syncedIds.contains(id)) {
          await queue.markSynced(id);
        } else {
          await queue.markRetry(id);
        }
      }
      processed = ids.length;
      synced = syncedIds.length;
      conflicts = conflictIds.length;
      skipped = ids.length - synced - conflicts;
    }

    // A real sync cycle must also pull remote changes. This makes sync
    // automatic in both directions whenever the worker is triggered.
    final deviceId = await DeviceService(database).ensureDevice(businessId);
    final cfg = SyncConfigService(database);
    final cursor = await cfg.cursor(businessId: businessId, deviceId: deviceId);
    final pull = await pullAndApply(businessId, deviceId: deviceId, cursor: cursor);
    processed += pull.applied + pull.skipped + pull.conflicts;
    synced += pull.applied;
    conflicts += pull.conflicts;
    skipped += pull.skipped;

    return SyncRunResult(
      processed: processed,
      synced: synced,
      conflicts: conflicts,
      skipped: skipped,
      pullApplied: pull.applied,
      pullConflicts: pull.conflicts,
    );
  }
  Future<SyncApplyResult> pullAndApply(String businessId, {required String deviceId, String? cursor}) async {
    if (!adapter.isConfigured) {
      return const SyncApplyResult(applied: 0, skipped: 0, conflicts: 0);
    }
    final remote = await adapter.pull(businessId: businessId, deviceId: deviceId, cursor: cursor);
    if (remote.operations.isEmpty) {
      if (remote.nextCursor != null && remote.nextCursor!.isNotEmpty) {
        await SyncConfigService(database).setCursor(businessId: businessId, deviceId: deviceId, value: remote.nextCursor);
      }
      return const SyncApplyResult(applied: 0, skipped: 0, conflicts: 0);
    }
    final result = await SyncApplyService(database).applyAll(businessId: businessId, envelopes: remote.operations);
    // Never advance past a conflict: keeping the cursor allows the conflict
    // to be retried/resolved instead of silently losing a remote operation.
    if (result.conflicts == 0 && remote.nextCursor != null && remote.nextCursor!.isNotEmpty) {
      await SyncConfigService(database).setCursor(businessId: businessId, deviceId: deviceId, value: remote.nextCursor);
    }
    return result;
  }

}
