import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';

class SyncConfigService {
  SyncConfigService(this.database, {FlutterSecureStorage? secureStorage})
      : _secureStorage = secureStorage ?? const FlutterSecureStorage();

  final AppDatabase database;
  final FlutterSecureStorage _secureStorage;
  static const _tokenKey = 'sync_auth_token';

  Future<void> save({required String baseUrl, required String authToken}) async {
    final normalized = baseUrl.trim();
    if (!normalized.startsWith('https://')) {
      throw ArgumentError('Sync server URL must use HTTPS.');
    }
    if (authToken.trim().isEmpty) {
      throw ArgumentError('Sync authentication token is required.');
    }
    await database.db.transaction((txn) async {
      await txn.insert('app_settings', {'key': 'sync_base_url', 'value': normalized}, conflictAlgorithm: ConflictAlgorithm.replace);
      // Token is deliberately not stored in SQLite; use the OS secure keychain/keystore.
      await txn.delete('app_settings', where: 'key = ?', whereArgs: [_tokenKey]);
    });
    await _secureStorage.write(key: _tokenKey, value: authToken.trim());
  }

  Future<String?> baseUrl() async => _get('sync_base_url');
  Future<String?> authToken() => _secureStorage.read(key: _tokenKey);

  Future<String?> cursor({required String businessId, required String deviceId}) async =>
      _get(_cursorKey(businessId, deviceId));

  Future<void> setCursor({required String businessId, required String deviceId, String? value}) async {
    final key = _cursorKey(businessId, deviceId);
    if (value == null || value.isEmpty) {
      await database.db.delete('app_settings', where: 'key = ?', whereArgs: [key]);
      return;
    }
    await database.db.insert('app_settings', {'key': key, 'value': value}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> clear() async {
    await database.db.delete('app_settings', where: 'key = ?', whereArgs: ['sync_base_url']);
    await database.db.delete('app_settings', where: 'key LIKE ?', whereArgs: ['sync_cursor:%']);
    await _secureStorage.delete(key: _tokenKey);
  }

  String _cursorKey(String businessId, String deviceId) => 'sync_cursor:$businessId:$deviceId';

  Future<String?> _get(String key) async {
    final rows = await database.db.query('app_settings', columns: ['value'], where: 'key = ?', whereArgs: [key], limit: 1);
    return rows.isEmpty ? null : rows.first['value'] as String?;
  }
}
