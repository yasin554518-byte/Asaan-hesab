import 'package:sqflite/sqflite.dart';
import 'cloud_sync_adapter.dart';
import '../database/app_database.dart';
import 'sync_queue_service.dart';

/// Applies remote sync envelopes safely and idempotently.
///
/// Financial records are immutable: remote CREATE is accepted once, while
/// UPDATE/DELETE is rejected so corrections must use the normal reversal or
/// return workflow. Master-data UPDATE/DELETE is allowed for products,
/// customers and suppliers.
class SyncApplyService {
  SyncApplyService(this.database);
  final AppDatabase database;

  static const _masterTables = {'products', 'customers', 'suppliers'};
  static const _financialTables = {
    'sales', 'sale_items', 'purchases', 'purchase_items', 'payments',
    'expenses', 'stock_movements', 'ledger_entries', 'returns',
    'return_items', 'cash_transactions',
  };
  static const _safeTables = {
    'businesses', 'products', 'customers', 'suppliers', 'sales', 'sale_items',
    'purchases', 'purchase_items', 'payments', 'expenses', 'stock_movements',
    'ledger_entries', 'returns', 'return_items', 'cash_transactions',
  };

  Future<SyncApplyResult> applyAll({
    required String businessId,
    required List<SyncEnvelope> envelopes,
  }) async {
    var applied = 0;
    var skipped = 0;
    var conflicts = 0;
    final ordered = [...envelopes]..sort((a, b) {
      const rank = <String, int>{
        'businesses': 0,
        'products': 10,
        'customers': 10,
        'suppliers': 10,
        'sales': 20,
        'purchases': 20,
        'returns': 20,
        'payments': 30,
        'expenses': 30,
        'sale_items': 40,
        'purchase_items': 40,
        'return_items': 40,
        'stock_movements': 50,
        'ledger_entries': 50,
        'cash_transactions': 50,
      };
      final ar = rank[a.tableName] ?? 999;
      final br = rank[b.tableName] ?? 999;
      if (ar != br) return ar.compareTo(br);
      final v = a.version.compareTo(b.version);
      return v != 0 ? v : a.operationId.compareTo(b.operationId);
    });
    await database.db.transaction((txn) async {
      for (final envelope in ordered) {
        // Reject malformed envelopes before touching SQLite. Empty operation
        // IDs are especially dangerous because sync_operations uses the
        // operation ID as its idempotency key; accepting one could make all
        // later malformed operations look like already-applied work.
        if (envelope.operationId.trim().isEmpty ||
            envelope.recordId.trim().isEmpty ||
            envelope.deviceId.trim().isEmpty ||
            envelope.version < 0) {
          conflicts++;
          continue;
        }
        // Every synced record must belong to the requested business. Some
        // child tables (sale_items, purchase_items, return_items) do not
        // store business_id themselves, so their parent row must be checked
        // before the record can be applied.
        if (!_safeTables.contains(envelope.tableName)) {
          conflicts++;
          continue;
        }
        if (!await _belongsToBusiness(txn, businessId, envelope.tableName, envelope.payload)) {
          conflicts++;
          continue;
        }
        final alreadyApplied = await txn.query('sync_operations', columns: ['operation_id'], where: 'operation_id = ?', whereArgs: [envelope.operationId], limit: 1);
        if (alreadyApplied.isNotEmpty) {
          skipped++;
          continue;
        }

        try {
          await _applyOne(txn, businessId, envelope);
          await txn.insert('sync_operations', {
            'operation_id': envelope.operationId,
            'business_id': businessId,
            'record_id': envelope.recordId,
            'operation': envelope.operation,
            'applied_at': DateTime.now().toUtc().toIso8601String(),
          }, conflictAlgorithm: ConflictAlgorithm.ignore);
          applied++;
        } catch (error) {
          // Financial data must never be partially applied. If one remote
          // financial operation cannot be validated/applied, abort the whole
          // pull transaction so a later retry cannot leave orphaned sale items,
          // ledger rows, stock movements or cash entries behind.
          if (_financialTables.contains(envelope.tableName)) rethrow;
          conflicts++;
        }
      }
    });

    return SyncApplyResult(applied: applied, skipped: skipped, conflicts: conflicts);
  }

  Future<bool> _belongsToBusiness(
    DatabaseExecutor db,
    String businessId,
    String table,
    Map<String, dynamic> payload,
  ) async {
    final direct = payload['business_id']?.toString();
    if (direct != null) return direct == businessId;

    // The businesses table is the root record and therefore has no
    // business_id column of its own. Its primary key is the business ID.
    if (table == 'businesses') {
      final id = payload['id']?.toString();
      return id != null && id == businessId;
    }

    Future<bool> parent(String parentTable, String idColumn) async {
      final id = payload[idColumn]?.toString();
      if (id == null || id.isEmpty) return false;
      final rows = await db.query(
        parentTable,
        columns: ['business_id'],
        where: 'id = ?',
        whereArgs: [id],
        limit: 1,
      );
      return rows.isNotEmpty && rows.first['business_id']?.toString() == businessId;
    }

    switch (table) {
      case 'sale_items':
        return parent('sales', 'sale_id');
      case 'purchase_items':
        return parent('purchases', 'purchase_id');
      case 'return_items':
        return parent('returns', 'return_id');
      default:
        return false;
    }
  }

  Future<void> _applyOne(DatabaseExecutor db, String businessId, SyncEnvelope e) async {
    final data = Map<String, dynamic>.from(e.payload);
    data['id'] ??= e.recordId;
    if (data['id'] != e.recordId) throw StateError('record id mismatch');

    if (_financialTables.contains(e.tableName) && e.operation != 'CREATE') {
      throw StateError('financial records are immutable');
    }

    switch (e.operation.toUpperCase()) {
      case 'CREATE':
        final exists = await db.query(e.tableName, columns: ['id'], where: 'id=?', whereArgs: [e.recordId], limit: 1);
        if (exists.isNotEmpty) return;
        await db.insert(e.tableName, data, conflictAlgorithm: ConflictAlgorithm.abort);
        break;
      case 'UPDATE':
        if (!_masterTables.contains(e.tableName)) throw StateError('update not allowed');
        final count = await db.update(
          e.tableName,
          data,
          where: 'id=? AND business_id=?',
          whereArgs: [e.recordId, businessId],
        );
        if (count == 0) {
          // Only create the missing master record when the payload is still
          // explicitly scoped to this business.
          await db.insert(e.tableName, data, conflictAlgorithm: ConflictAlgorithm.abort);
        }
        break;
      case 'DELETE':
        if (!_masterTables.contains(e.tableName)) throw StateError('delete not allowed');
        await db.update(e.tableName, {
          'deleted_at': DateTime.now().toUtc().toIso8601String(),
          'updated_at': DateTime.now().toUtc().toIso8601String(),
        }, where: 'id=? AND business_id=?', whereArgs: [e.recordId, businessId]);
        break;
      default:
        throw StateError('unknown sync operation');
    }
  }
}

class SyncApplyResult {
  const SyncApplyResult({required this.applied, required this.skipped, required this.conflicts});
  final int applied;
  final int skipped;
  final int conflicts;
}
