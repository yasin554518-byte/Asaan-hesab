import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'cloud_sync_adapter.dart';

/// HTTPS transport for the Asan Hisab sync API.
///
/// Expected API contract:
/// POST {baseUrl}/v1/sync/push
/// { businessId, operations: [...] }
/// -> { syncedOperationIds: [...], conflictOperationIds: [...] }
///
/// GET {baseUrl}/v1/sync/pull?businessId=...&deviceId=...&cursor=...
/// -> { operations: [...], nextCursor: "..." }
///
/// The server must authenticate the device, enforce business isolation and
/// idempotency on operationId, and never execute financial operations twice.
class RestCloudSyncAdapter implements CloudSyncAdapter {
  RestCloudSyncAdapter({required String baseUrl, required this.authToken})
      : baseUrl = baseUrl.replaceFirst(RegExp(r'/+$'), '');

  final String baseUrl;
  final String authToken;

  static const int _maxResponseBytes = 8 * 1024 * 1024;

  @override
  bool get isConfigured => baseUrl.startsWith('https://') && authToken.isNotEmpty;

  Map<String, String> get _headers => {
        'content-type': 'application/json',
        'accept': 'application/json',
        'authorization': 'Bearer $authToken',
      };

  @override
  Future<SyncPushResult> push({
    required String businessId,
    required List<SyncEnvelope> operations,
  }) async {
    _ensureConfigured();
    final client = HttpClient();
    try {
      final request = await client.postUrl(Uri.parse('$baseUrl/v1/sync/push'));
      _headers.forEach(request.headers.set);
      request.write(jsonEncode({
        'businessId': businessId,
        'operations': operations.map((e) => e.toJson()).toList(),
      }));
      final response = await request.close().timeout(const Duration(seconds: 20));
      final body = await _readJsonResponse(response);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Sync push failed (${response.statusCode})', uri: request.uri);
      }
      final json = jsonDecode(body) as Map<String, dynamic>;
      return SyncPushResult(
        syncedOperationIds: (json['syncedOperationIds'] as List? ?? const []).cast<String>(),
        conflictOperationIds: (json['conflictOperationIds'] as List? ?? const []).cast<String>(),
      );
    } finally {
      client.close(force: true);
    }
  }

  @override
  Future<SyncPullResult> pull({
    required String businessId,
    required String deviceId,
    required String? cursor,
  }) async {
    _ensureConfigured();
    final query = <String, String>{
      'businessId': businessId,
      'deviceId': deviceId,
      if (cursor != null && cursor.isNotEmpty) 'cursor': cursor,
    };
    final uri = Uri.parse('$baseUrl/v1/sync/pull').replace(queryParameters: query);
    final client = HttpClient();
    try {
      final request = await client.getUrl(uri);
      _headers.forEach(request.headers.set);
      final response = await request.close().timeout(const Duration(seconds: 20));
      final body = await _readJsonResponse(response);
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw HttpException('Sync pull failed (${response.statusCode})', uri: uri);
      }
      final json = jsonDecode(body) as Map<String, dynamic>;
      final raw = (json['operations'] as List? ?? const []);
      final operations = raw.map((item) {
        final m = Map<String, dynamic>.from(item as Map);
        return SyncEnvelope(
          operationId: m['operationId'] as String,
          recordId: m['recordId'] as String,
          tableName: m['tableName'] as String,
          operation: m['operation'] as String,
          deviceId: m['deviceId'] as String,
          version: (m['version'] as num).toInt(),
          payload: Map<String, dynamic>.from(m['payload'] as Map),
        );
      }).toList();
      return SyncPullResult(nextCursor: json['nextCursor']?.toString(), operations: operations);
    } finally {
      client.close(force: true);
    }
  }

  Future<String> _readJsonResponse(HttpClientResponse response) async {
    final contentType = response.headers.contentType;
    if (contentType == null || contentType.mimeType != 'application/json') {
      throw const FormatException('Sync server returned a non-JSON response.');
    }
    final declaredLength = response.contentLength;
    if (declaredLength > _maxResponseBytes) {
      throw const FormatException('Sync server response is too large.');
    }
    final bytes = BytesBuilder(copy: false);
    var total = 0;
    await for (final chunk in response) {
      total += chunk.length;
      if (total > _maxResponseBytes) {
        throw const FormatException('Sync server response is too large.');
      }
      bytes.add(chunk);
    }
    return utf8.decode(bytes.takeBytes());
  }

  void _ensureConfigured() {
    if (!isConfigured) {
      throw StateError('Use HTTPS and provide a non-empty sync authentication token.');
    }
  }
}
