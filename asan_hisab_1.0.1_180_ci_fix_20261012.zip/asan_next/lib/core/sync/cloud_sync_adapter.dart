import 'dart:convert';

/// Transport-neutral contract for the real two-phone cloud sync backend.
///
/// The local SQLite database remains the source of truth. A production
/// provider (for example a secured REST/WebSocket service) is injected here;
/// this layer deliberately does not pretend that a cloud service exists until
/// credentials/backend configuration are supplied.
abstract class CloudSyncAdapter {
  bool get isConfigured;

  Future<SyncPushResult> push({
    required String businessId,
    required List<SyncEnvelope> operations,
  });

  Future<SyncPullResult> pull({
    required String businessId,
    required String deviceId,
    required String? cursor,
  });
}

class SyncEnvelope {
  const SyncEnvelope({
    required this.operationId,
    required this.recordId,
    required this.tableName,
    required this.operation,
    required this.deviceId,
    required this.version,
    required this.payload,
  });

  final String operationId;
  final String recordId;
  final String tableName;
  final String operation;
  final String deviceId;
  final int version;
  final Map<String, dynamic> payload;

  Map<String, dynamic> toJson() => {
        'operationId': operationId,
        'recordId': recordId,
        'tableName': tableName,
        'operation': operation,
        'deviceId': deviceId,
        'version': version,
        'payload': payload,
      };

  String encode() => jsonEncode(toJson());
}

class SyncPullResult {
  const SyncPullResult({required this.operations, this.nextCursor});

  final List<SyncEnvelope> operations;
  final String? nextCursor;
}

class SyncPushResult {
  const SyncPushResult({required this.syncedOperationIds, this.conflictOperationIds = const []});

  final List<String> syncedOperationIds;
  final List<String> conflictOperationIds;
}

/// Safe default: keeps the app fully offline until a real backend is wired.
class UnconfiguredCloudSyncAdapter implements CloudSyncAdapter {
  const UnconfiguredCloudSyncAdapter();

  @override
  bool get isConfigured => false;

  @override
  Future<SyncPushResult> push({required String businessId, required List<SyncEnvelope> operations}) =>
      throw StateError('Cloud sync backend is not configured');

  @override
  Future<SyncPullResult> pull({required String businessId, required String deviceId, required String? cursor}) =>
      throw StateError('Cloud sync backend is not configured');
}
