const schemaVersion = 5;

const createStatements = <String>[
  '''CREATE TABLE businesses (id TEXT PRIMARY KEY, name TEXT NOT NULL, owner_name TEXT, phone TEXT, address TEXT, logo_path TEXT, currency TEXT NOT NULL DEFAULT 'AFN', invoice_prefix TEXT NOT NULL DEFAULT 'INV-', next_invoice_number INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''',
  '''CREATE TABLE products (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, name TEXT NOT NULL, barcode TEXT, part_number TEXT, sku TEXT, cost_price INTEGER NOT NULL DEFAULT 0, sale_price INTEGER NOT NULL DEFAULT 0, stock_quantity INTEGER NOT NULL DEFAULT 0, minimum_stock INTEGER NOT NULL DEFAULT 0, unit TEXT NOT NULL DEFAULT 'pcs', average_cost INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted_at TEXT)''',
  '''CREATE TABLE customers (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, name TEXT NOT NULL, phone TEXT, address TEXT, opening_balance INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted_at TEXT)''',
  '''CREATE TABLE suppliers (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, name TEXT NOT NULL, phone TEXT, address TEXT, opening_balance INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL, deleted_at TEXT)''',
  '''CREATE TABLE sales (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, reference_no TEXT NOT NULL, customer_id TEXT, subtotal INTEGER NOT NULL, discount INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL, paid INTEGER NOT NULL DEFAULT 0, remaining INTEGER NOT NULL DEFAULT 0, payment_type TEXT NOT NULL, date TEXT NOT NULL, created_at TEXT NOT NULL)''',
  '''CREATE TABLE sale_items (id TEXT PRIMARY KEY, sale_id TEXT NOT NULL, product_id TEXT NOT NULL, quantity INTEGER NOT NULL, unit_price INTEGER NOT NULL, cost_price INTEGER NOT NULL, discount INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL)''',
  '''CREATE TABLE purchases (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, reference_no TEXT NOT NULL, supplier_id TEXT, subtotal INTEGER NOT NULL, discount INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL, paid INTEGER NOT NULL DEFAULT 0, remaining INTEGER NOT NULL DEFAULT 0, payment_type TEXT NOT NULL, date TEXT NOT NULL, created_at TEXT NOT NULL)''',
  '''CREATE TABLE purchase_items (id TEXT PRIMARY KEY, purchase_id TEXT NOT NULL, product_id TEXT NOT NULL, quantity INTEGER NOT NULL, unit_cost INTEGER NOT NULL, total INTEGER NOT NULL)''',
  '''CREATE TABLE payments (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, reference_no TEXT NOT NULL, party_type TEXT NOT NULL, party_id TEXT NOT NULL, amount INTEGER NOT NULL, payment_type TEXT NOT NULL, note TEXT, date TEXT NOT NULL, created_at TEXT NOT NULL)''',
  '''CREATE TABLE expenses (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT, date TEXT NOT NULL, created_at TEXT NOT NULL)''',
  '''CREATE TABLE stock_movements (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, product_id TEXT NOT NULL, movement_type TEXT NOT NULL, quantity INTEGER NOT NULL, reference_type TEXT NOT NULL, reference_id TEXT NOT NULL, unit_cost INTEGER NOT NULL DEFAULT 0, date TEXT NOT NULL, created_at TEXT NOT NULL)''',
  '''CREATE TABLE ledger_entries (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, party_type TEXT NOT NULL, party_id TEXT NOT NULL, entry_type TEXT NOT NULL, debit INTEGER NOT NULL DEFAULT 0, credit INTEGER NOT NULL DEFAULT 0, reference_type TEXT NOT NULL, reference_id TEXT NOT NULL, note TEXT, date TEXT NOT NULL, created_at TEXT NOT NULL)''',
  '''CREATE TABLE returns (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, reference_no TEXT NOT NULL, return_type TEXT NOT NULL, original_reference TEXT NOT NULL, party_id TEXT, total INTEGER NOT NULL, refund INTEGER NOT NULL DEFAULT 0, date TEXT NOT NULL, created_at TEXT NOT NULL)''',
  '''CREATE TABLE return_items (id TEXT PRIMARY KEY, return_id TEXT NOT NULL, product_id TEXT NOT NULL, quantity INTEGER NOT NULL, unit_price INTEGER NOT NULL, cost_price INTEGER NOT NULL, total INTEGER NOT NULL)''',
  '''CREATE TABLE cash_transactions (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, transaction_type TEXT NOT NULL, amount INTEGER NOT NULL, reference_type TEXT, reference_id TEXT, note TEXT, date TEXT NOT NULL, created_at TEXT NOT NULL)''',
  '''CREATE TABLE users (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, name TEXT NOT NULL, username TEXT NOT NULL, pin_hash TEXT NOT NULL, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''',
  '''CREATE TABLE audit_logs (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, user_id TEXT, action TEXT NOT NULL, module TEXT NOT NULL, record_id TEXT, result TEXT NOT NULL, details TEXT, created_at TEXT NOT NULL)''',
  '''CREATE TABLE devices (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, device_name TEXT NOT NULL, device_key TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, last_sync_at TEXT, created_at TEXT NOT NULL)''',
  '''CREATE TABLE sync_queue (id TEXT PRIMARY KEY, business_id TEXT NOT NULL, record_id TEXT NOT NULL, table_name TEXT NOT NULL, operation TEXT NOT NULL, device_id TEXT NOT NULL, version INTEGER NOT NULL, payload TEXT NOT NULL, status TEXT NOT NULL, retry_count INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, last_attempt_at TEXT)''',
];

const indexStatements = <String>[
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_products_barcode ON products(business_id, barcode) WHERE barcode IS NOT NULL AND barcode <> \'\'',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_products_sku ON products(business_id, sku) WHERE sku IS NOT NULL AND sku <> \'\'',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_sales_ref ON sales(business_id, reference_no)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_purchases_ref ON purchases(business_id, reference_no)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_payments_ref ON payments(business_id, reference_no)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_returns_ref ON returns(business_id, reference_no)',
  'CREATE INDEX IF NOT EXISTS ix_products_name ON products(business_id, name)',
  'CREATE INDEX IF NOT EXISTS ix_products_part ON products(business_id, part_number)',
  'CREATE INDEX IF NOT EXISTS ix_customers_name ON customers(business_id, name)',
  'CREATE INDEX IF NOT EXISTS ix_customers_phone ON customers(business_id, phone)',
  'CREATE INDEX IF NOT EXISTS ix_suppliers_name ON suppliers(business_id, name)',
  'CREATE INDEX IF NOT EXISTS ix_suppliers_phone ON suppliers(business_id, phone)',
  'CREATE INDEX IF NOT EXISTS ix_sales_date ON sales(business_id, date)',
  'CREATE INDEX IF NOT EXISTS ix_sales_customer ON sales(business_id, customer_id)',
  'CREATE INDEX IF NOT EXISTS ix_purchases_date ON purchases(business_id, date)',
  'CREATE INDEX IF NOT EXISTS ix_purchases_supplier ON purchases(business_id, supplier_id)',
  'CREATE INDEX IF NOT EXISTS ix_payments_party ON payments(business_id, party_type, party_id, date)',
  'CREATE INDEX IF NOT EXISTS ix_ledger_party ON ledger_entries(business_id, party_type, party_id, date)',
  'CREATE INDEX IF NOT EXISTS ix_stock_product ON stock_movements(business_id, product_id, date)',
  'CREATE INDEX IF NOT EXISTS ix_cash_date ON cash_transactions(business_id, date)',
];

const migrationV2Statements = <String>[
  '''CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)''',
  '''CREATE TABLE IF NOT EXISTS sync_operations (operation_id TEXT PRIMARY KEY, business_id TEXT NOT NULL, record_id TEXT NOT NULL, operation TEXT NOT NULL, applied_at TEXT NOT NULL)''',
  'CREATE INDEX IF NOT EXISTS ix_sync_operations_record ON sync_operations(business_id, record_id)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_devices_key ON devices(business_id, device_key)',
];

const migrationV3Statements = <String>[
  'CREATE INDEX IF NOT EXISTS ix_sync_queue_status ON sync_queue(business_id, status, created_at)',
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_sync_queue_operation ON sync_queue(business_id, record_id, table_name, operation, device_id, version)',
  'CREATE INDEX IF NOT EXISTS ix_audit_business_date ON audit_logs(business_id, created_at)',
  'CREATE INDEX IF NOT EXISTS ix_returns_original ON returns(business_id, original_reference)',
];

const migrationV5Statements = <String>[
  "ALTER TABLE ledger_entries ADD COLUMN note TEXT",
];

const migrationV4Statements = <String>[
  'CREATE UNIQUE INDEX IF NOT EXISTS ux_users_username ON users(business_id, username)',
  'CREATE INDEX IF NOT EXISTS ix_users_active ON users(business_id, active)',
];
