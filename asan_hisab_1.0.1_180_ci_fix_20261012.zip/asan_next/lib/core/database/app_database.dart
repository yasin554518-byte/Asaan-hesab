import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'schema.dart';

class AppDatabase {
  AppDatabase._(this.db, this.path);
  Database db;
  final String path;

  static Future<AppDatabase> open({String? path}) async {
    final base = path ?? p.join(await getDatabasesPath(), 'asan_hisab.db');
    final db = await _openDatabase(base);
    return AppDatabase._(db, base);
  }

  static Future<Database> _openDatabase(String base) async {
    return openDatabase(
      base,
      version: schemaVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
        await db.execute('PRAGMA journal_mode = WAL');
        await db.execute('PRAGMA synchronous = NORMAL');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        await db.transaction((txn) async {
          if (oldVersion < 2) {
            for (final sql in migrationV2Statements) {
              await txn.execute(sql);
            }
          }
          if (oldVersion < 3) {
            for (final sql in migrationV3Statements) {
              await txn.execute(sql);
            }
          }
          if (oldVersion < 4) {
            for (final sql in migrationV4Statements) {
              await txn.execute(sql);
            }
          }
          if (oldVersion < 5) {
            for (final sql in migrationV5Statements) {
              await txn.execute(sql);
            }
          }
        });
      },
      onCreate: (db, version) async {
        await db.transaction((txn) async {
          for (final sql in createStatements) {
            await txn.execute(sql);
          }
          for (final sql in indexStatements) {
            await txn.execute(sql);
          }
          for (final sql in migrationV2Statements) {
            await txn.execute(sql);
          }
          for (final sql in migrationV3Statements) {
            await txn.execute(sql);
          }
          for (final sql in migrationV4Statements) {
            await txn.execute(sql);
          }
          for (final sql in migrationV5Statements) {
            await txn.execute(sql);
          }
        });
      },
    );
  }

  Future<void> replaceDatabaseFile(String backupPath) async {
    final backup = File(backupPath);
    if (!await backup.exists() || await backup.length() == 0) {
      throw StateError('Invalid backup file');
    }
    // Flush WAL before replacing the live database file.
    await db.rawQuery('PRAGMA wal_checkpoint(TRUNCATE)');
    await db.close();
    final current = File(path);
    final safety = File('${path}.before_restore');
    if (await current.exists()) await current.copy(safety.path);
    try {
      // Remove sidecar files from the old database; otherwise stale WAL/SHM
      // state could be applied to the restored database.
      final wal = File('$path-wal');
      final shm = File('$path-shm');
      if (await wal.exists()) await wal.delete();
      if (await shm.exists()) await shm.delete();
      await backup.copy(path);
      final reopened = await _openDatabase(path);
      final rows = await reopened.rawQuery('PRAGMA integrity_check');
      final versionRows = await reopened.rawQuery('PRAGMA user_version');
      final restoredVersion = versionRows.isEmpty ? 0 : (versionRows.first.values.first as num?)?.toInt() ?? 0;
      if (restoredVersion != schemaVersion) {
        await reopened.close();
        throw StateError('Restored schema version mismatch');
      }
      if (rows.isEmpty || rows.first.values.first != 'ok') {
        await reopened.close();
        throw StateError('Backup integrity check failed');
      }
      await reopened.close();
      db = await _openDatabase(path);
      if (await safety.exists()) await safety.delete();
    } catch (_) {
      if (await safety.exists()) {
        await safety.copy(path);
        db = await _openDatabase(path);
      }
      rethrow;
    }
  }

  Future<bool> integrityOk() async {
    final rows = await db.rawQuery('PRAGMA integrity_check');
    return rows.isNotEmpty && rows.first.values.first == 'ok';
  }

  Future<void> close() => db.close();
}
