import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'app_database.dart';
import 'schema.dart';

class BackupService {
  final AppDatabase database;
  const BackupService(this.database);

  Future<File> createBackup(String destinationPath) async {
    if (!await database.integrityOk()) {
      throw StateError('Database integrity check failed');
    }
    final versionRows = await database.db.rawQuery('PRAGMA user_version');
    final version = versionRows.isEmpty ? 0 : (versionRows.first.values.first as num?)?.toInt() ?? 0;
    if (version <= 0) throw StateError('Database schema version is invalid');

    await database.db.rawQuery('PRAGMA wal_checkpoint(TRUNCATE)');
    final source = File(database.path);
    if (!await source.exists()) throw StateError('Database file not found');

    final destination = File(destinationPath);
    if (await destination.exists() && await destination.isSymbolicLink()) {
      throw StateError('Backup destination must not be a symlink');
    }
    if (p.normalize(destination.absolute.path) == p.normalize(File(database.path).absolute.path)) {
      throw StateError('Backup destination must differ from live database');
    }
    await destination.parent.create(recursive: true);
    await source.copy(destination.path);

    if (!await destination.exists() || await destination.length() == 0) {
      throw StateError('Backup verification failed');
    }

    // Verify the copied file independently before reporting success.
    final verification = await openDatabase(destination.path, readOnly: true);
    try {
      final integrity = await verification.rawQuery('PRAGMA integrity_check');
      if (integrity.isEmpty || integrity.first.values.first != 'ok') {
        throw StateError('Copied backup failed integrity check');
      }
      final copiedVersion = await verification.rawQuery('PRAGMA user_version');
      final copied = copiedVersion.isEmpty ? 0 : (copiedVersion.first.values.first as num?)?.toInt() ?? 0;
      if (copied != version || copied != schemaVersion) throw StateError('Backup schema version mismatch');
    } finally {
      await verification.close();
    }
    return destination;
  }

  Future<void> restoreBackup(String backupPath) async {
    final backup = File(backupPath);
    if (p.normalize(backup.absolute.path) == p.normalize(File(database.path).absolute.path)) {
      throw StateError('Backup file must differ from live database');
    }
    if (await backup.exists() && await backup.isSymbolicLink()) {
      throw StateError('Backup file must not be a symlink');
    }
    if (!await backup.exists() || await backup.length() == 0) {
      throw StateError('Invalid backup file');
    }

    // Never replace the live database until the backup itself has been
    // independently verified. This prevents a corrupt/old backup from
    // taking the application offline.
    final verification = await openDatabase(backup.path, readOnly: true);
    try {
      final integrity = await verification.rawQuery('PRAGMA integrity_check');
      if (integrity.isEmpty || integrity.first.values.first != 'ok') {
        throw StateError('Backup integrity check failed');
      }
      final rows = await verification.rawQuery('PRAGMA user_version');
      final version = rows.isEmpty
          ? 0
          : (rows.first.values.first as num?)?.toInt() ?? 0;
      if (version != schemaVersion) {
        throw StateError('Backup schema version $version does not match current $schemaVersion');
      }
    } finally {
      await verification.close();
    }

    await database.replaceDatabaseFile(backup.path);
    if (!await database.integrityOk()) {
      throw StateError('Restored database integrity check failed');
    }
  }
}
