import 'dart:typed_data';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

class InvoicePdfService {
  Future<Uint8List> buildInvoice({
    required String businessName,
    required String invoiceNo,
    required String date,
    required String customer,
    required List<InvoiceLine> items,
    required int subtotal,
    required int discount,
    required int total,
    required int paid,
    required int remaining,
  }) async {
    final doc = pw.Document();
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      build: (_) => [
        pw.Text(businessName, style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 8),
        pw.Text('Invoice: $invoiceNo'),
        pw.Text('Date: $date'),
        pw.Text('Customer: $customer'),
        pw.SizedBox(height: 12),
        pw.Table.fromTextArray(
          headers: const ['Product', 'Qty', 'Price', 'Total'],
          data: items.map((e) => [e.name, e.quantity.toString(), e.unitPrice.toString(), e.total.toString()]).toList(),
        ),
        pw.SizedBox(height: 12),
        pw.Text('Subtotal: $subtotal'),
        pw.Text('Discount: $discount'),
        pw.Text('Total: $total'),
        pw.Text('Paid: $paid'),
        pw.Text('Remaining: $remaining'),
      ],
    ));
    return doc.save();
  }
}

class InvoiceLine {
  const InvoiceLine({required this.name, required this.quantity, required this.unitPrice, required this.total});
  final String name;
  final int quantity;
  final int unitPrice;
  final int total;
}
