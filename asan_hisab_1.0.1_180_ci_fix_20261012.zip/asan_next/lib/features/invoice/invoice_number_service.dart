import '../../core/database/app_database.dart';

class InvoiceNumberService {
  InvoiceNumberService(this.database);
  final AppDatabase database;

  Future<String> nextInvoiceNumber(String businessId) async {
    return database.db.transaction((txn) async {
      final rows = await txn.query('businesses', columns: ['invoice_prefix', 'next_invoice_number'],
          where: 'id = ?', whereArgs: [businessId], limit: 1);
      if (rows.isEmpty) throw StateError('Business not found');
      final prefix = (rows.first['invoice_prefix'] as String?) ?? 'INV-';
      final next = (rows.first['next_invoice_number'] as int?) ?? 1;
      await txn.update('businesses', {'next_invoice_number': next + 1}, where: 'id = ?', whereArgs: [businessId]);
      return '$prefix${next.toString().padLeft(6, '0')}';
    });
  }
}
