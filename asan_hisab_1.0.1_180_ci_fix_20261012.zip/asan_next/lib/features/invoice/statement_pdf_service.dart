import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

/// Builds a printable customer/supplier statement from validated ledger rows.
/// Arabic/Pashto-capable fonts are bundled with the app so PDF output does not
/// depend on fonts installed on the Android device or desktop.
class StatementPdfService {
  Future<Uint8List> buildStatement({
    required String businessName,
    required String partyName,
    required String partyType,
    required String date,
    required int openingBalance,
    required List<StatementPdfRow> rows,
    required int closingBalance,
  }) async {
    final regularData = await rootBundle.load('assets/fonts/NotoNaskhArabic-Regular.ttf');
    final boldData = await rootBundle.load('assets/fonts/NotoNaskhArabic-Bold.ttf');
    final regular = pw.Font.ttf(regularData);
    final bold = pw.Font.ttf(boldData);
    final base = pw.TextStyle(font: regular, fontSize: 9);
    final heading = pw.TextStyle(font: bold, fontSize: 18);
    final strong = pw.TextStyle(font: bold, fontSize: 10);

    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        textDirection: pw.TextDirection.rtl,
        theme: pw.ThemeData.withFont(base: regular, bold: bold),
        build: (_) => [
          pw.Text(businessName, style: heading),
          pw.SizedBox(height: 6),
          pw.Text('${_partyTypeLabel(partyType)}: $partyName', style: strong),
          pw.Text('نېټه: $date', style: base),
          pw.SizedBox(height: 12),
          pw.Text('${date == 'ټول حساب' ? 'د پیل بیلانس' : 'د فلټر د پیل بیلانس'}: $openingBalance', style: strong),
          pw.SizedBox(height: 8),
          pw.Table.fromTextArray(
            headerStyle: strong,
            cellStyle: base,
            headers: const ['نېټه', 'معامله', 'یادښت', 'ډېبټ', 'کریډیټ', 'بیلانس'],
            data: rows.map((r) => [
              r.date,
              _entryTypeLabel(r.entryType),
              r.note,
              r.debit.toString(),
              r.credit.toString(),
              r.balance.toString(),
            ]).toList(),
          ),
          pw.SizedBox(height: 12),
          pw.Text('وروستی بیلانس: $closingBalance', style: strong),
        ],
      ),
    );
    return doc.save();
  }
}

String _partyTypeLabel(String type) {
  switch (type.toUpperCase()) {
    case 'CUSTOMER':
      return 'مشتری';
    case 'SUPPLIER':
      return 'عرضه کوونکی';
    default:
      return type;
  }
}

String _entryTypeLabel(String type) {
  switch (type.toUpperCase()) {
    case 'SALE':
      return 'خرڅلاو';
    case 'PURCHASE':
      return 'پېرود';
    case 'PAYMENT':
    case 'RECEIPT':
      return 'رسید / تادیه';
    case 'SALE_RETURN':
      return 'د خرڅلاو بېرته ستنول';
    case 'PURCHASE_RETURN':
      return 'د پېرود بېرته ستنول';
    case 'EXPENSE':
      return 'مصرف';
    default:
      return type;
  }
}

class StatementPdfRow {
  const StatementPdfRow({
    required this.date,
    required this.entryType,
    required this.note,
    required this.debit,
    required this.credit,
    required this.balance,
  });

  final String date;
  final String entryType;
  final String note;
  final int debit;
  final int credit;
  final int balance;
}
