import 'package:flutter/material.dart';
import '../../core/database/app_database.dart';
import '../../shared/services/dashboard_service.dart';
import '../../shared/services/sale_service.dart';
import '../../shared/services/purchase_service.dart';
import '../../shared/services/payment_service.dart';
import '../../shared/services/return_service.dart';
import '../../shared/services/statement_service.dart';
import '../invoice/statement_pdf_service.dart';
import 'package:printing/printing.dart';
import '../../shared/services/notification_service.dart';
import '../../shared/models/return_models.dart';
import '../../shared/models/sale_models.dart';
import '../../shared/models/purchase_models.dart';
import 'management_pages.dart';
import '../../core/database/backup_service.dart';
import '../../core/sync/sync_queue_service.dart';
import '../../core/sync/sync_config_service.dart';
import '../../core/sync/rest_cloud_sync_adapter.dart';
import '../../core/sync/sync_worker.dart';
import '../../core/sync/device_service.dart';
import '../../core/security/pin_service.dart';
import '../../core/security/permission_service.dart';
import '../../core/security/audit_service.dart';
import '../../core/utils/ids.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

void showCalculator(BuildContext context) {
  Navigator.push(
    context,
    MaterialPageRoute(builder: (_) => const CalculatorPage()),
  );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.database, required this.businessId, required this.role});
  final AppDatabase database;
  final String businessId;
  final UserRole role;
  bool can(Permission permission) => PermissionService().can(role, permission);
  @override State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  @override Widget build(BuildContext context) {
    final destinations = <Widget>[
      DashboardPage(key: ValueKey('dashboard-$index'), database: widget.database, businessId: widget.businessId),
      if (can(Permission.sales)) SalePage(database: widget.database, businessId: widget.businessId),
      if (can(Permission.purchases)) PurchasePage(database: widget.database, businessId: widget.businessId),
      if (can(Permission.customers)) CustomerPage(database: widget.database, businessId: widget.businessId),
      MorePage(database: widget.database, businessId: widget.businessId, role: widget.role),
    ];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Text('آسان حساب')),
      body: IndexedStack(index: index, children: destinations),
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: [
        const NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'کور'),
        if (can(Permission.sales)) const NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), label: 'پلور'),
        if (can(Permission.purchases)) const NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'پېرود'),
        if (can(Permission.customers)) const NavigationDestination(icon: Icon(Icons.people_outline), label: 'مشتریان'),
        const NavigationDestination(icon: Icon(Icons.more_horiz), label: 'نور'),
      ]),
    ));
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key, required this.database, required this.businessId});
  final AppDatabase database; final String businessId;
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _refreshToken = 0;

  Future<void> _openAndRefresh(Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
    if (mounted) setState(() => _refreshToken++);
  }

  @override Widget build(BuildContext context) => FutureBuilder<DashboardSummary>(
    key: ValueKey(_refreshToken),
    future: DashboardService(widget.database.db).load(widget.businessId),
    builder: (context, s) {
      if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
      if (s.hasError) return Center(child: Text('ستونزه: ${s.error}'));
      final d=s.data!; final cards=[('د نن پلور',d.todaySales),('د نن پېرود',d.todayPurchases),('مصارف',d.todayExpenses),('نغدې',d.cashBalance),('مشتریانو قرض',d.customerDue),('عرضه کوونکو قرض',d.supplierDue),('ذخیره',d.stockValue),('خالصه ګټه',d.netProfit)];
      return ListView(padding:const EdgeInsets.all(12),children:[GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:cards.length,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:8,mainAxisSpacing:8,childAspectRatio:1.6),itemBuilder:(_,i)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(cards[i].$1),const Spacer(),Text(cards[i].$2.toString(),style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))])))),const SizedBox(height:14),Wrap(spacing:8,runSpacing:8,children:[if(widget.role == UserRole.owner || widget.role == UserRole.manager || widget.role == UserRole.cashier) FilledButton.icon(onPressed:()=>_openAndRefresh(SalePage(database:widget.database,businessId:widget.businessId)),icon:const Icon(Icons.add_shopping_cart),label:const Text('نوی پلور')),if(widget.role != UserRole.cashier) FilledButton.tonalIcon(onPressed:()=>_openAndRefresh(PurchasePage(database:widget.database,businessId:widget.businessId)),icon:const Icon(Icons.inventory_2),label:const Text('نوی پېرود')),if(PermissionService().can(widget.role, Permission.payments)) ActionChip(label:const Text('🧾 رسید/تادیه'),onPressed:()=>_openAndRefresh(PaymentPage(database:widget.database,businessId:widget.businessId))),if(PermissionService().can(widget.role, Permission.customers)) ActionChip(label:const Text('➕ قرض اضافه'),onPressed:()=>_openAndRefresh(LoanAddPage(database:widget.database,businessId:widget.businessId))),ActionChip(label:const Text('🧮 ماشین حساب'),onPressed:()=>showCalculator(context))])]);
    });
}

class SalePage extends StatefulWidget { const SalePage({super.key,required this.database,required this.businessId}); final AppDatabase database; final String businessId; @override State<SalePage> createState()=>_SalePageState(); }
class _SalePageState extends State<SalePage>{String? productId,customerId;final q=TextEditingController(text:'1'),price=TextEditingController(),discount=TextEditingController(text:'0'),paid=TextEditingController(text:'0');bool saving=false;Future<List<Map<String,dynamic>>> rows(String t)=>widget.database.db.query(t,where:'business_id = ? AND deleted_at IS NULL',whereArgs:[widget.businessId],orderBy:'name ASC');void msg(String x){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));}Future<void> save()async{if(productId==null)return msg('محصول وټاکئ');final qty=int.tryParse(q.text)??0,p=int.tryParse(price.text)??0,d=int.tryParse(discount.text)??0,pa=int.tryParse(paid.text)??0;if(qty<=0||p<0||d<0||pa<0)return msg('معلومات سم کړئ');final gross=qty*p;if(d>gross)return msg('تخفیف له ټول مبلغ زیات دی');final total=gross-d;if(pa>total)return msg('تادیه له ټول مبلغ زیاته ده');if(!mounted)return;setState(()=>saving=true);try{await SaleService(widget.database.db).createSale(businessId:widget.businessId,referenceNo:'INV-${DateTime.now().millisecondsSinceEpoch}-${newId().substring(0, 8)}',customerId:customerId,lines:[SaleLineInput(productId:productId!,quantity:qty,unitPrice:p,discount:d)],paid:pa,paymentType:pa==0?'CREDIT':pa==total?'CASH':'PARTIAL');if(mounted)msg('پلور ثبت شو');}catch(e){if(mounted)msg('ستونزه: $e');}finally{if(mounted)setState(()=>saving=false);}}@override void dispose(){q.dispose();price.dispose();discount.dispose();paid.dispose();super.dispose();}@override Widget build(BuildContext c)=>FutureBuilder<List<dynamic>>(future:Future.wait([rows('products'),rows('customers')]),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final ps=s.data![0] as List<Map<String,dynamic>>,cs=s.data![1] as List<Map<String,dynamic>>;return ListView(padding:const EdgeInsets.all(16),children:[Text('نوی پلور',style:Theme.of(c).textTheme.headlineSmall),DropdownButtonFormField<String>(value:productId,decoration:const InputDecoration(labelText:'محصول'),items:ps.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text('${x['name']} | ذخیره ${x['stock_quantity']}'))).toList(),onChanged:(v)=>setState(()=>productId=v)),DropdownButtonFormField<String>(value:customerId,decoration:const InputDecoration(labelText:'مشتری (اختیاري)'),items:cs.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:(v)=>setState(()=>customerId=v)),TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'مقدار')),TextField(controller:price,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'واحد قیمت')),TextField(controller:discount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'تخفیف')),TextField(controller:paid,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'ورکړل شوي')),const SizedBox(height:16),FilledButton.icon(onPressed:saving?null:save,icon:const Icon(Icons.save),label:Text(saving?'ثبتېږي...':'پلور ثبتول'))];});}

class PurchasePage extends StatefulWidget { const PurchasePage({super.key,required this.database,required this.businessId}); final AppDatabase database; final String businessId; @override State<PurchasePage> createState()=>_PurchasePageState(); }
class _PurchasePageState extends State<PurchasePage>{String? productId,supplierId;final q=TextEditingController(text:'1'),cost=TextEditingController(),discount=TextEditingController(text:'0'),paid=TextEditingController(text:'0');bool saving=false;Future<List<Map<String,dynamic>>> rows(String t)=>widget.database.db.query(t,where:'business_id = ? AND deleted_at IS NULL',whereArgs:[widget.businessId],orderBy:'name ASC');void msg(String x){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));}Future<void> save()async{if(productId==null||supplierId==null)return msg('محصول او عرضه کوونکی وټاکئ');final qty=int.tryParse(q.text)??0,c=int.tryParse(cost.text)??0,d=int.tryParse(discount.text)??0,pa=int.tryParse(paid.text)??0;if(qty<=0||c<0||d<0||pa<0)return msg('معلومات سم کړئ');final gross=qty*c;if(d>gross)return msg('تخفیف له ټول مبلغ زیات دی');final total=gross-d;if(pa>total)return msg('تادیه له ټول مبلغ زیاته ده');if(!mounted)return;setState(()=>saving=true);try{await PurchaseService(widget.database.db).createPurchase(businessId:widget.businessId,referenceNo:'PUR-${DateTime.now().millisecondsSinceEpoch}-${newId().substring(0, 8)}',supplierId:supplierId!,lines:[PurchaseLineInput(productId:productId!,quantity:qty,unitCost:c)],discount:d,paid:pa,paymentType:pa==0?'CREDIT':pa==((qty*c)-d)?'CASH':'PARTIAL');if(mounted)msg('پېرود ثبت شو');}catch(e){if(mounted)msg('ستونزه: $e');}finally{if(mounted)setState(()=>saving=false);}}@override void dispose(){q.dispose();cost.dispose();discount.dispose();paid.dispose();super.dispose();}@override Widget build(BuildContext c)=>FutureBuilder<List<dynamic>>(future:Future.wait([rows('products'),rows('suppliers')]),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final ps=s.data![0] as List<Map<String,dynamic>>,ss=s.data![1] as List<Map<String,dynamic>>;return ListView(padding:const EdgeInsets.all(16),children:[Text('نوی پېرود',style:Theme.of(c).textTheme.headlineSmall),DropdownButtonFormField<String>(value:productId,decoration:const InputDecoration(labelText:'محصول'),items:ps.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:(v)=>setState(()=>productId=v)),DropdownButtonFormField<String>(value:supplierId,decoration:const InputDecoration(labelText:'عرضه کوونکی'),items:ss.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:(v)=>setState(()=>supplierId=v)),TextField(controller:q,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'مقدار')),TextField(controller:cost,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'واحد قیمت')),TextField(controller:discount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'تخفیف')),TextField(controller:paid,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'ورکړل شوي')),const SizedBox(height:16),FilledButton.icon(onPressed:saving?null:save,icon:const Icon(Icons.save),label:Text(saving?'ثبتېږي...':'پېرود ثبتول'))];});}

class LoanAddPage extends StatefulWidget {
  const LoanAddPage({super.key, required this.database, required this.businessId});
  final AppDatabase database;
  final String businessId;
  @override State<LoanAddPage> createState() => _LoanAddPageState();
}

class _LoanAddPageState extends State<LoanAddPage> {
  String? customerId;
  final amount = TextEditingController();
  final note = TextEditingController();
  bool saving = false;

  Future<List<Map<String, dynamic>>> customers() => widget.database.db.query(
    'customers', where: 'business_id = ? AND deleted_at IS NULL',
    whereArgs: [widget.businessId], orderBy: 'name ASC');

  void msg(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> save() async {
    final value = int.tryParse(amount.text.trim()) ?? 0;
    if (customerId == null || value <= 0) return msg('مشتری او صحیح مبلغ وټاکئ');
    if (saving) return;
    if (!mounted) return;
    setState(() => saving = true);
    try {
      final now = DateTime.now().toUtc().toIso8601String();
      await widget.database.db.transaction((txn) async {
        final deviceId = await DeviceService.ensureDeviceInTransaction(txn, businessId: widget.businessId);
        final id = newId();
        final entry = <String, dynamic>{
          'id': id, 'business_id': widget.businessId, 'party_type': 'CUSTOMER',
          'party_id': customerId, 'entry_type': 'MANUAL_LOAN', 'debit': value, 'credit': 0,
          'reference_type': 'MANUAL_LOAN', 'reference_id': id, 'note': note.text.trim(), 'date': now, 'created_at': now,
        };
        await txn.insert('ledger_entries', entry);
        await SyncQueueService.enqueueInTransactionStatic(txn,
          businessId: widget.businessId, recordId: id, tableName: 'ledger_entries',
          operation: 'CREATE', deviceId: deviceId, version: 1, payload: entry);
        await txn.insert('audit_logs', {
          'id': newId(), 'business_id': widget.businessId, 'user_id': null,
          'action': 'CREATE', 'module': 'LEDGER', 'record_id': id, 'result': 'SUCCESS',
          'details': 'MANUAL_LOAN:$value:${note.text.trim()}', 'created_at': now,
        });
      });
      if (mounted) { amount.clear(); note.clear(); msg('قرض اضافه شو'); }
    } catch (e) {
      if (mounted) msg('ستونزه: $e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override void dispose() { amount.dispose(); note.dispose(); super.dispose(); }

  @override Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
    future: customers(), builder: (context, snapshot) {
      if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
      final list = snapshot.data!;
      return ListView(padding: const EdgeInsets.all(16), children: [
        Text('قرض اضافه', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: customerId, decoration: const InputDecoration(labelText: 'مشتری'),
          items: list.map((x) => DropdownMenuItem(value: x['id'] as String, child: Text(x['name'] as String))).toList(),
          onChanged: saving ? null : (v) => setState(() => customerId = v)),
        TextField(controller: amount, enabled: !saving, keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'د قرض مبلغ')),
        TextField(controller: note, enabled: !saving, decoration: const InputDecoration(labelText: 'یادښت (اختیاري)')),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.add),
          label: Text(saving ? 'ثبتېږي...' : 'قرض اضافه کول')),
      ]);
    });
}

class PaymentPage extends StatefulWidget { const PaymentPage({super.key,required this.database,required this.businessId}); final AppDatabase database; final String businessId; @override State<PaymentPage> createState()=>_PaymentPageState(); }
class _PaymentPageState extends State<PaymentPage>{String type='CUSTOMER';String? partyId;final amount=TextEditingController();final note=TextEditingController();bool saving=false;Future<List<Map<String,dynamic>>> rows(String t)=>widget.database.db.query(t,where:'business_id = ? AND deleted_at IS NULL',whereArgs:[widget.businessId],orderBy:'name ASC');void msg(String x){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));}Future<void> save()async{final a=int.tryParse(amount.text)??0;if(partyId==null||a<=0)return msg('شخص او مبلغ وټاکئ');if(saving)return;if(!mounted)return;setState(()=>saving=true);try{await PaymentService(widget.database.db).receiveOrPay(businessId:widget.businessId,referenceNo:'PAY-${DateTime.now().millisecondsSinceEpoch}-${newId().substring(0, 8)}',partyType:type,partyId:partyId!,amount:a,paymentType:'CASH',note:note.text.trim().isEmpty?null:note.text.trim());if(mounted){amount.clear();note.clear();msg('تادیه ثبت شوه');}}catch(e){if(mounted)msg('ستونزه: $e');}finally{if(mounted)setState(()=>saving=false);}}@override void dispose(){amount.dispose();note.dispose();super.dispose();}@override Widget build(BuildContext c)=>FutureBuilder<List<dynamic>>(future:Future.wait([rows('customers'),rows('suppliers')]),builder:(c,s){if(!s.hasData)return const Center(child:CircularProgressIndicator());final list=(type=='CUSTOMER'?s.data![0]:s.data![1]) as List<Map<String,dynamic>>;return ListView(padding:const EdgeInsets.all(16),children:[Text('رسید / تادیه',style:Theme.of(c).textTheme.headlineSmall),DropdownButtonFormField<String>(value:type,items:const[DropdownMenuItem(value:'CUSTOMER',child:Text('د مشتری رسید')),DropdownMenuItem(value:'SUPPLIER',child:Text('عرضه کوونکي ته تادیه'))],onChanged:saving?null:(v)=>setState((){type=v!;partyId=null;})),DropdownButtonFormField<String>(value:partyId,decoration:const InputDecoration(labelText:'شخص'),items:list.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:saving?null:(v)=>setState(()=>partyId=v)),TextField(controller:amount,enabled:!saving,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'مبلغ')),TextField(controller:note,enabled:!saving,decoration:const InputDecoration(labelText:'یادښت (اختیاري)')),const SizedBox(height:16),FilledButton(onPressed:saving?null:save,child:Text(saving?'ثبتېږي...':'ثبتول'))];});}



class ReturnsPage extends StatefulWidget {
  const ReturnsPage({super.key, required this.database, required this.businessId});
  final AppDatabase database; final String businessId;
  @override State<ReturnsPage> createState() => _ReturnsPageState();
}
class _ReturnsPageState extends State<ReturnsPage> {
  String type='SALE_RETURN'; String? originalRef, partyId, productId; bool saving=false;
  final qty=TextEditingController(text:'1'), price=TextEditingController(), refund=TextEditingController(text:'0');
  List<Map<String,dynamic>> originalItems=[];
  Map<String,dynamic>? selectedOriginal;
  int _selectionRequest = 0;

  Future<List<Map<String,dynamic>>> people(String table)=>widget.database.db.query(table,where:'business_id = ? AND deleted_at IS NULL',whereArgs:[widget.businessId],orderBy:'name ASC');
  Future<List<Map<String,dynamic>>> originals()=>widget.database.db.query(type=='SALE_RETURN'?'sales':'purchases',where:'business_id = ?',whereArgs:[widget.businessId],orderBy:'date DESC');

  Future<void> selectOriginal(String? ref) async {
    final request = ++_selectionRequest;
    if (ref == null) return;
    final rows=await widget.database.db.query(type=='SALE_RETURN'?'sales':'purchases',where:'business_id = ? AND reference_no = ?',whereArgs:[widget.businessId,ref],limit:1);
    if (rows.isEmpty || !mounted || request != _selectionRequest) return;
    final original=rows.first;
    final items=await widget.database.db.query(type=='SALE_RETURN'?'sale_items':'purchase_items',where:'${type=='SALE_RETURN'?'sale_id':'purchase_id'} = ?',whereArgs:[original['id']]);
    if (!mounted || request != _selectionRequest) return;
    setState(() {
      originalRef=ref; selectedOriginal=original; originalItems=items;
      partyId=(type=='SALE_RETURN'?original['customer_id']:original['supplier_id']) as String?;
      productId=null; price.clear();
    });
  }

  void selectProduct(String? id) {
    if (id == null) return;
    final row=originalItems.cast<Map<String,dynamic>>().firstWhere((x)=>x['product_id']==id,orElse:()=>{});
    final historical=(type=='SALE_RETURN'?row['unit_price']:row['unit_cost']);
    setState(() { productId=id; price.text='${(historical as num?)?.toInt()??0}'; });
  }

  Future<void> save() async {
    final q=int.tryParse(qty.text)??0, p=int.tryParse(price.text)??0, r=int.tryParse(refund.text)??0;
    if(originalRef==null||productId==null||q<=0||p<0||r<0){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('اصلي معامله، محصول او مقدار سم وټاکئ')));return;}
    if(saving)return;
    if(!mounted)return;
    setState(()=>saving=true);
    try {
      final ref='RET-${DateTime.now().millisecondsSinceEpoch}-${newId().substring(0, 8)}'; final svc=ReturnService(widget.database.db);
      final result=type=='SALE_RETURN'
        ? await svc.createSalesReturn(businessId:widget.businessId,referenceNo:ref,originalReference:originalRef!,lines:[ReturnLineInput(productId:productId!,quantity:q,unitPrice:p,costPrice:0)],refund:r,customerId:partyId)
        : await svc.createPurchaseReturn(businessId:widget.businessId,referenceNo:ref,originalReference:originalRef!,lines:[ReturnLineInput(productId:productId!,quantity:q,unitPrice:p,costPrice:0)],refund:r,supplierId:partyId);
      if(mounted){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('بېرته ستنول ثبت شو: ${result.total}')));}
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('ستونزه: $e')));}finally{if(mounted)setState(()=>saving=false);}
  }

  @override void dispose(){qty.dispose();price.dispose();refund.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>FutureBuilder<List<dynamic>>(future:Future.wait([originals(),people(type=='SALE_RETURN'?'customers':'suppliers')]),builder:(context,s){
    if(!s.hasData)return const Center(child:CircularProgressIndicator());
    final os=s.data![0] as List<Map<String,dynamic>>;
    final parties=s.data![1] as List<Map<String,dynamic>>;
    final productIds=originalItems.map((x)=>x['product_id'] as String).toSet();
    final productFuture=productIds.isEmpty?Future.value(<Map<String,dynamic>>[]):widget.database.db.query('products',where:'business_id = ? AND deleted_at IS NULL AND id IN (${List.filled(productIds.length,'?').join(',')})',whereArgs:[widget.businessId,...productIds]);
    return FutureBuilder<List<Map<String,dynamic>>>(future:productFuture,builder:(context,psnap){
      if(!psnap.hasData)return const Center(child:CircularProgressIndicator());
      final ps=psnap.data!;
      return ListView(padding:const EdgeInsets.all(16),children:[
        Text('بېرته ستنول',style:Theme.of(context).textTheme.headlineSmall),
        DropdownButtonFormField<String>(value:type,decoration:const InputDecoration(labelText:'ډول'),items:const[DropdownMenuItem(value:'SALE_RETURN',child:Text('د خرڅلاو بېرته ستنول')),DropdownMenuItem(value:'PURCHASE_RETURN',child:Text('د پېرود بېرته ستنول'))],onChanged:saving?null:(v){setState(() { type=v!; originalRef=null; partyId=null; productId=null; originalItems=[]; selectedOriginal=null; price.clear(); });}),
        DropdownButtonFormField<String>(value:originalRef,decoration:const InputDecoration(labelText:'اصلي معامله'),items:os.map((x)=>DropdownMenuItem(value:x['reference_no'] as String,child:Text('${x['reference_no']} — ${x['total']}'))).toList(),onChanged:saving?null:selectOriginal),
        DropdownButtonFormField<String>(value:partyId,decoration:const InputDecoration(labelText:'مشتری / عرضه کوونکی'),items:parties.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:null),
        DropdownButtonFormField<String>(value:productId,decoration:const InputDecoration(labelText:'د اصلي معاملې محصول'),items:ps.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:saving||originalItems.isEmpty?null:selectProduct),
        TextField(controller:qty,enabled:!saving,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'مقدار')),
        TextField(controller:price,enabled:false,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'د اصلي معاملې واحد قیمت')),
        TextField(controller:refund,enabled:!saving,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'نغدي بېرته ورکړه')),
        const SizedBox(height:16),
        FilledButton.icon(onPressed:saving||originalRef==null||productId==null?null:save,icon:const Icon(Icons.assignment_return),label:Text(saving?'ثبتېږي...':'بېرته ستنول ثبتول'))
      ]);
    });
  });
}
class StatementPage extends StatefulWidget {
  const StatementPage({super.key,required this.database,required this.businessId,required this.partyType,this.initialPartyId});
  final AppDatabase database; final String businessId; final String partyType; final String? initialPartyId;
  @override State<StatementPage> createState()=>_StatementPageState();
}
class _StatementViewData {
  const _StatementViewData(this.entries, this.periodOpening);
  final List<Map<String, Object?>> entries;
  final int periodOpening;
}

class _StatementPageState extends State<StatementPage>{String? partyId; Future<_StatementViewData>? _statementFuture; Future<List<Map<String,dynamic>>>? _partiesFuture; bool printingStatement=false; DateTime? fromDate, toDate;
  @override void initState(){super.initState(); partyId=widget.initialPartyId; _partiesFuture=_loadParties(); if(partyId!=null) _statementFuture=_loadStatement(partyId!);}

  Future<List<Map<String,dynamic>>> _loadParties() => widget.database.db.query(widget.partyType=='CUSTOMER'?'customers':'suppliers',where:'business_id = ? AND deleted_at IS NULL',whereArgs:[widget.businessId],orderBy:'name ASC');

  Future<_StatementViewData> _loadStatement(String selectedPartyId) async {
    final statementService=StatementService(widget.database.db);
    final entries=await statementService.partyStatement(businessId:widget.businessId,partyType:widget.partyType,partyId:selectedPartyId,fromDate:fromDate,toDate:toDate);
    final periodOpening=await statementService.openingBalanceAt(businessId:widget.businessId,partyType:widget.partyType,partyId:selectedPartyId,fromDate:fromDate);
    return _StatementViewData(entries,periodOpening);
  }
  Future<void> _printStatement(Map<String,dynamic> party, List<Map<String,Object?>> entries) async {
    if (printingStatement) return;
    setState(()=>printingStatement=true);
    try {
      // PDF must use the same period-opening semantics as the on-screen Statement.
      final statementService=StatementService(widget.database.db);
      final periodOpening=await statementService.openingBalanceAt(
        businessId:widget.businessId,
        partyType:widget.partyType,
        partyId:party['id'] as String,
        fromDate:fromDate,
      );
      var bal=periodOpening;
      final rows=<StatementPdfRow>[];
      for(final r in entries){
        final d=(r['debit'] as num?)?.toInt()??0, c=(r['credit'] as num?)?.toInt()??0;
        bal=widget.partyType=='CUSTOMER'?bal+d-c:bal+c-d;
        rows.add(StatementPdfRow(date:'${r['date']??''}',entryType:'${r['entry_type']??''}',note:((r['note'] as String?)?.trim() ?? ''),debit:d,credit:c,balance:bal));
      }
      final period = fromDate == null && toDate == null
          ? 'ټول حساب'
          : 'له ${fromDate?.toIso8601String().substring(0,10) ?? 'پیل'} تر ${toDate?.toIso8601String().substring(0,10) ?? 'اوس'}';
      final business=(await widget.database.db.query('businesses',columns:['name'],where:'id=?',whereArgs:[widget.businessId],limit:1));
      final bytes=await StatementPdfService().buildStatement(businessName:business.isEmpty?'آسان حساب':'${business.first['name']}',partyName:'${party['name']}',partyType:widget.partyType=='CUSTOMER'?'Customer':'Supplier',date:period,openingBalance:periodOpening,rows:rows,closingBalance:bal);
      await Printing.layoutPdf(onLayout:(_)=>bytes);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PDF جوړول یا چاپ کول ناکام شول، بیا هڅه وکړئ')));
      }
    } finally { if(mounted)setState(()=>printingStatement=false); }
  }

  @override Widget build(BuildContext context)=>FutureBuilder<List<Map<String,dynamic>>>(future:_partiesFuture,builder:(context,s){if(s.hasError)return Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.error_outline,size:48),const SizedBox(height:12),const Text('د حسابونو لیست لوډ نه شو'),const SizedBox(height:8),Text('${s.error}'),const SizedBox(height:12),OutlinedButton.icon(onPressed:()=>setState(()=>_partiesFuture=_loadParties()),icon:const Icon(Icons.refresh),label:const Text('بیا هڅه'))])));if(!s.hasData)return const Center(child:CircularProgressIndicator());final parties=s.data!;final selectedPartyId=parties.any((x)=>x['id']==partyId)?partyId:null;final effectivePartyId=selectedPartyId;return Column(children:[Padding(padding:const EdgeInsets.all(16),child:DropdownButtonFormField<String>(value:selectedPartyId,decoration:InputDecoration(labelText:widget.partyType=='CUSTOMER'?'مشتری':'عرضه کوونکی'),items:parties.map((x)=>DropdownMenuItem(value:x['id'] as String,child:Text(x['name'] as String))).toList(),onChanged:(v){setState((){partyId=v; _statementFuture=v==null?null:_loadStatement(v);});})),
if(partyId!=null) Padding(
  padding: const EdgeInsets.symmetric(horizontal:16, vertical:4),
  child: Wrap(spacing:8, runSpacing:8, children:[
    OutlinedButton.icon(
      onPressed: () async {
        final picked = await showDatePicker(context:context, initialDate:fromDate ?? DateTime.now(), firstDate:DateTime(2000), lastDate:DateTime(2100));
        if (!mounted) return;
        if (picked != null) {
          if (toDate != null && picked.isAfter(toDate!)) {
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('له نېټه باید د تر نېټې څخه مخکې یا هماغه ورځ وي')));
          } else {
            setState((){fromDate=picked; if(partyId!=null) _statementFuture=_loadStatement(partyId!);});
          }
        }
      },
      icon: const Icon(Icons.date_range), label: Text(fromDate == null ? 'له نېټې' : 'له ${fromDate!.toIso8601String().substring(0,10)}')),
    OutlinedButton.icon(
      onPressed: () async {
        final picked = await showDatePicker(context:context, initialDate:toDate ?? DateTime.now(), firstDate:DateTime(2000), lastDate:DateTime(2100));
        if (!mounted) return;
        if (picked != null) {
          if (fromDate != null && picked.isBefore(fromDate!)) {
            if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تر نېټه باید د له نېټې څخه وروسته یا هماغه ورځ وي')));
          } else {
            setState((){toDate=picked; if(partyId!=null) _statementFuture=_loadStatement(partyId!);});
          }
        }
      },
      icon: const Icon(Icons.event), label: Text(toDate == null ? 'تر نېټې' : 'تر ${toDate!.toIso8601String().substring(0,10)}')),
    if(fromDate != null || toDate != null) TextButton.icon(onPressed:()=>setState((){fromDate=null;toDate=null; if(partyId!=null) _statementFuture=_loadStatement(partyId!);}), icon:const Icon(Icons.clear), label:const Text('فلټر پاکول')),
  ]),
),
if(effectivePartyId!=null)Expanded(child:FutureBuilder<_StatementViewData>(future:_statementFuture,builder:(context,st){if(st.hasError)return Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.error_outline,size:48),const SizedBox(height:12),const Text('د حساب Statement لوډ نه شو'),const SizedBox(height:8),Text('${st.error}'),const SizedBox(height:12),OutlinedButton.icon(onPressed:()=>setState(()=>_statementFuture=_loadStatement(partyId!)),icon:const Icon(Icons.refresh),label:const Text('بیا هڅه'))])));if(!st.hasData)return const Center(child:CircularProgressIndicator());final party=parties.firstWhere((x)=>x['id']==effectivePartyId);final entries=st.data!.entries; final periodOpening=st.data!.periodOpening; final filteredClosing=entries.isEmpty?periodOpening:((entries.last['running_balance'] as num?)?.toInt()??periodOpening); final totalDebit=entries.fold<int>(0,(sum,r)=>sum+((r['debit'] as num?)?.toInt()??0)); final totalCredit=entries.fold<int>(0,(sum,r)=>sum+((r['credit'] as num?)?.toInt()??0));
return ListView(children:[Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('د حساب د فلټر پای بیلانس',style:Theme.of(context).textTheme.titleMedium),const SizedBox(height:4),Text('$filteredClosing',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:4),Text('د فلټر د پیل بیلانس: $periodOpening',style:Theme.of(context).textTheme.bodyMedium)])))),Padding(padding:const EdgeInsets.symmetric(horizontal:16),child:FilledButton.icon(onPressed:printingStatement?null:()=>_printStatement(party,entries),icon:const Icon(Icons.print),label:Text(printingStatement?'PDF چمتو کېږي...':'حساب PDF / چاپ'))),Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:4),child:Row(children:[Expanded(child:Text('ټول Debit: $totalDebit')),Expanded(child:Text('ټول Credit: $totalCredit')),Expanded(child:Text('خالص: ${filteredClosing-periodOpening}'))])),ListTile(title:const Text('د فلټر د پیل بیلانس'),trailing:Text('$periodOpening')),const Divider(),Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:4),child:Row(children:const[Expanded(child:Text('معامله')),SizedBox(width:70,child:Text('Debit')),SizedBox(width:70,child:Text('Credit')),SizedBox(width:80,child:Text('پاتې'))])), ...entries.map((r){final bal=(r['running_balance'] as num?)?.toInt()??0;final d=(r['debit'] as num?)?.toInt()??0;final cr=(r['credit'] as num?)?.toInt()??0;return ListTile(title:Text('${r['entry_type']}'),subtitle:Text('${r['date']}${(r['note'] as String?)?.trim().isNotEmpty == true ? ' — ${(r['note'] as String).trim()}' : ''}'),trailing:SizedBox(width:220,child:Row(mainAxisAlignment:MainAxisAlignment.end,children:[SizedBox(width:70,child:Text('$d',textAlign:TextAlign.right)),SizedBox(width:70,child:Text('$cr',textAlign:TextAlign.right)),SizedBox(width:80,child:Text('$bal',textAlign:TextAlign.right,style:const TextStyle(fontWeight:FontWeight.bold)))])));})]);}))]);}
}

class CustomerPage extends StatelessWidget {
  const CustomerPage({super.key, required this.database, required this.businessId});
  final AppDatabase database; final String businessId;
  @override Widget build(BuildContext context) => CrudListPage(database: database, businessId: businessId, type: CrudType.customers);
}


class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.database, required this.businessId});
  final AppDatabase database;
  final String businessId;
  @override State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final name = TextEditingController();
  final owner = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  final currency = TextEditingController(text: 'AFN');
  final prefix = TextEditingController(text: 'INV-');
  bool loading = true;
  bool saving = false;

  @override void initState() { super.initState(); load(); }
  @override void dispose() { for (final c in [name, owner, phone, address, currency, prefix]) c.dispose(); super.dispose(); }

  Future<void> load() async {
    final rows = await widget.database.db.query('businesses', where: 'id = ?', whereArgs: [widget.businessId], limit: 1);
    if (!mounted || rows.isEmpty) return;
    final r = rows.first;
    name.text = (r['name'] ?? '').toString();
    owner.text = (r['owner_name'] ?? '').toString();
    phone.text = (r['phone'] ?? '').toString();
    address.text = (r['address'] ?? '').toString();
    currency.text = (r['currency'] ?? 'AFN').toString();
    prefix.text = (r['invoice_prefix'] ?? 'INV-').toString();
    if (mounted) setState(() => loading = false);
  }

  Future<void> save() async {
    if (name.text.trim().isEmpty) return;
    if (!mounted) return;
    setState(() => saving = true);
    try {
      final now = DateTime.now().toUtc().toIso8601String();
      await widget.database.db.update('businesses', {
        'name': name.text.trim(), 'owner_name': _n(owner.text), 'phone': _n(phone.text),
        'address': _n(address.text), 'currency': currency.text.trim().isEmpty ? 'AFN' : currency.text.trim(),
        'invoice_prefix': prefix.text.trim().isEmpty ? 'INV-' : prefix.text.trim(), 'updated_at': now,
      }, where: 'id = ?', whereArgs: [widget.businessId]);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('د کاروبار معلومات تازه شول')));
    } finally { if (mounted) setState(() => saving = false); }
  }

  String? _n(String s) => s.trim().isEmpty ? null : s.trim();

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تنظیمات')),
    body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
      Text('د کاروبار پروفایل', style: Theme.of(context).textTheme.headlineSmall),
      TextField(controller: name, decoration: const InputDecoration(labelText: 'د کاروبار نوم *')),
      TextField(controller: owner, decoration: const InputDecoration(labelText: 'مالک نوم')),
      TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'ټیلیفون')),
      TextField(controller: address, decoration: const InputDecoration(labelText: 'پته')),
      TextField(controller: currency, decoration: const InputDecoration(labelText: 'کرنسي')),
      TextField(controller: prefix, decoration: const InputDecoration(labelText: 'Invoice Prefix')),
      const SizedBox(height: 20),
      FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.save), label: Text(saving ? 'ساتل کېږي...' : 'ساتل')),
      const SizedBox(height: 12),
      const Card(child: ListTile(leading: Icon(Icons.security), title: Text('PIN او کاروونکي'), subtitle: Text('د Owner/Manager/Cashier صلاحیتونه د Security Layer له لارې کنټرولېږي.'))),
      Card(child: ListTile(leading: const Icon(Icons.sync), title: const Text('دوه موبایل Sync'), subtitle: const Text('Offline Queue + HTTPS Sync؛ د سرور تنظیم دلته کېدای شي.'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SyncConfigPage(database: widget.database, businessId: widget.businessId)))),
    ]),
  );
}

class MorePage extends StatelessWidget {
  const MorePage({super.key, required this.database, required this.businessId, required this.role});
  final AppDatabase database; final String businessId; final UserRole role;
  bool can(Permission permission) => PermissionService().can(role, permission);
  void go(BuildContext c, Widget page) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => page));
  @override Widget build(BuildContext c) => ListView(children: [
    if (can(Permission.stock)) ListTile(leading: const Icon(Icons.inventory_2), title: const Text('ذخیره / محصولات'), onTap: () => go(c, CrudListPage(database: database, businessId: businessId, type: CrudType.products))),
    if (can(Permission.customers)) ListTile(leading: const Icon(Icons.people), title: const Text('مشتریان'), onTap: () => go(c, CrudListPage(database: database, businessId: businessId, type: CrudType.customers))),
    if (can(Permission.suppliers)) ListTile(leading: const Icon(Icons.business), title: const Text('عرضه کوونکي'), onTap: () => go(c, CrudListPage(database: database, businessId: businessId, type: CrudType.suppliers))),
    if (can(Permission.returns)) ListTile(leading: const Icon(Icons.assignment_return), title: const Text('بېرته ستنول'), onTap: () => go(c, ReturnsPage(database: database, businessId: businessId))),
    if (can(Permission.payments)) ListTile(leading: const Icon(Icons.payments), title: const Text('رسید / تادیه'), onTap: () => go(c, PaymentPage(database: database, businessId: businessId))),
    if (can(Permission.payments)) ListTile(leading: const Icon(Icons.add_card), title: const Text('قرض اضافه'), onTap: () => go(c, LoanAddPage(database: database, businessId: businessId))),
    if (can(Permission.expenses)) ListTile(leading: const Icon(Icons.money_off), title: const Text('مصارف'), onTap: () => go(c, ExpensePage(database: database, businessId: businessId))),
    if (can(Permission.reports)) ListTile(leading: const Icon(Icons.assessment), title: const Text('راپورونه'), onTap: () => go(c, ReportsPage(database: database, businessId: businessId))),
    ListTile(leading: const Icon(Icons.notifications_active), title: const Text('خبرتیاوې'), onTap: () => go(c, AlertsPage(database: database, businessId: businessId))),
    if (can(Permission.stock)) ListTile(leading: const Icon(Icons.file_upload), title: const Text('CSV Import'), onTap: () => go(c, CsvImportPage(database: database, businessId: businessId))),
    ListTile(leading: const Icon(Icons.calculate), title: const Text('ماشین حساب'), onTap: () => go(c, const CalculatorPage())),
    const Divider(),
    if (can(Permission.backup) || can(Permission.restore)) ListTile(leading: const Icon(Icons.backup), title: const Text('Backup / Restore'), onTap: () => go(c, BackupPage(database: database, businessId: businessId))),
    if (can(Permission.settings)) ListTile(leading: const Icon(Icons.sync), title: const Text('Sync'), onTap: () => go(c, SyncStatusPage(database: database, businessId: businessId))),
    if (can(Permission.settings)) ListTile(leading: const Icon(Icons.cloud_sync), title: const Text('د Sync سرور تنظیم'), onTap: () => go(c, SyncConfigPage(database: database, businessId: businessId))),
    if (can(Permission.settings)) ListTile(leading: const Icon(Icons.settings), title: const Text('تنظیمات'), onTap: () => go(c, SettingsPage(database: database, businessId: businessId))),
    ListTile(leading: const Icon(Icons.account_balance_wallet), title: const Text('د مشتری حساب'), onTap: () => go(c, StatementPage(database: database, businessId: businessId, partyType: 'CUSTOMER'))),
    ListTile(leading: const Icon(Icons.receipt_long), title: const Text('د عرضه کوونکي حساب'), onTap: () => go(c, StatementPage(database: database, businessId: businessId, partyType: 'SUPPLIER'))),
    if (can(Permission.userManagement)) ListTile(leading: const Icon(Icons.manage_accounts), title: const Text('کاروونکي او صلاحیتونه'), onTap: () => go(c, UserManagementPage(database: database, businessId: businessId))),
    const ListTile(leading: Icon(Icons.security), title: Text('امنیت او کاروونکي')),
  ]);
}


class AlertsPage extends StatefulWidget {
  const AlertsPage({super.key, required this.database, required this.businessId});
  final AppDatabase database;
  final String businessId;
  @override State<AlertsPage> createState() => _AlertsPageState();
}

class _AlertsPageState extends State<AlertsPage> {
  late Future<List<BusinessAlert>> future;
  String filter = 'ALL';

  @override void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    future = NotificationService(widget.database.db).loadAlerts(widget.businessId);
  }

  Future<void> _refresh() async {
    if (!mounted) return;
    final next = NotificationService(widget.database.db).loadAlerts(widget.businessId);
    setState(() => future = next);
    await next;
  }

  String _label(String type) => switch (type) {
    'LOW_STOCK' => 'کم سټاک',
    'CUSTOMER_DUE' => 'د مشتریانو قرض',
    'SUPPLIER_DUE' => 'د عرضه کوونکو قرض',
    _ => 'ټول',
  };

  IconData _icon(BusinessAlert a) => switch (a.type) {
    'LOW_STOCK' => a.severity >= 3 ? Icons.warning_amber_rounded : Icons.inventory_2_outlined,
    'CUSTOMER_DUE' => Icons.account_balance_wallet_outlined,
    'SUPPLIER_DUE' => Icons.payments_outlined,
    _ => Icons.notifications_outlined,
  };

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('خبرتیاوې'),
      actions: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh))],
    ),
    body: FutureBuilder<List<BusinessAlert>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snap.hasError) return Center(child: Text('ستونزه: ${snap.error}'));
        final all = snap.data ?? const <BusinessAlert>[];
        final filtered = filter == 'ALL' ? all : all.where((a) => a.type == filter).toList();
        final low = all.where((a) => a.type == 'LOW_STOCK').length;
        final customer = all.where((a) => a.type == 'CUSTOMER_DUE').length;
        final supplier = all.where((a) => a.type == 'SUPPLIER_DUE').length;
        final critical = all.where((a) => a.severity >= 3).length;
        return RefreshIndicator(
          onRefresh: _refresh,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(12),
            children: [
              Card(child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
                Expanded(child: _summary('کم سټاک', low, Icons.inventory_2)),
                Expanded(child: _summary('مشتریان', customer, Icons.people)),
                Expanded(child: _summary('عرضه کوونکي', supplier, Icons.business)),
                Expanded(child: _summary('بیړنۍ', critical, Icons.priority_high)),
              ]))),
              const SizedBox(height: 4),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(children: ['ALL','LOW_STOCK','CUSTOMER_DUE','SUPPLIER_DUE'].map((type) => Padding(
                  padding: const EdgeInsetsDirectional.only(end: 6),
                  child: ChoiceChip(label: Text(_label(type)), selected: filter == type, onSelected: (_) => setState(() => filter = type)),
                )).toList()),
              ),
              const SizedBox(height: 8),
              if (filtered.isEmpty)
                const Padding(padding: EdgeInsets.only(top: 140), child: Center(child: Text('د دې برخې لپاره کومه مهمه خبرتیا نشته.')))
              else
                ...filtered.map((a) => Card(child: ListTile(
                  leading: CircleAvatar(child: Icon(a.type == 'LOW_STOCK' ? Icons.inventory_2 : a.type == 'CUSTOMER_DUE' ? Icons.person : Icons.business)),
                  title: Text(a.title),
                  subtitle: Text(a.detail),
                  trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                    if (a.severity >= 3) const Text('بیړنی', style: TextStyle(fontWeight: FontWeight.bold)),
                    if (a.amount > 0) Text(a.amount.toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
                  ]),
                  onTap: a.partyId == null ? null : () {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => StatementPage(
                      database: widget.database,
                      businessId: widget.businessId,
                      partyType: a.type == 'CUSTOMER_DUE' ? 'CUSTOMER' : 'SUPPLIER',
                      partyId: a.partyId!,
                    )));
                  },
                ))),
            ],
          ),
        );
      },
    ),
  );

  Widget _summary(String label, int count, IconData icon) => Column(children: [
    Icon(icon, size: 22),
    const SizedBox(height: 3),
    Text('$count', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)),
  ]);
}


class BackupPage extends StatefulWidget {
  const BackupPage({super.key, required this.database, required this.businessId});
  final AppDatabase database;
  final String businessId;
  @override State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  bool busy = false;
  String? lastPath;

  Future<void> _loadLatestBackup() async {
    final dir = Directory(await getDatabasesPath());
    if (!await dir.exists()) return;
    final candidates = <File>[];
    await for (final entity in dir.list(followLinks: false)) {
      if (entity is File && p.basename(entity.path).startsWith('asan_hisab_backup_') && p.extension(entity.path) == '.db' && !await entity.isSymbolicLink()) {
        candidates.add(entity);
      }
    }
    if (candidates.isEmpty) return;
    candidates.sort((a, b) => b.path.compareTo(a.path));
    lastPath = candidates.first.path;
  }

  Future<void> backup() async {
    if (!mounted) return;
    setState(() => busy = true);
    try {
      final dir = await getDatabasesPath();
      final path = p.join(dir, 'asan_hisab_backup_${DateTime.now().millisecondsSinceEpoch}.db');
      final file = await BackupService(widget.database).createBackup(path);
      lastPath = file.path;
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backup په بریالیتوب جوړ شو')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Backup ستونزه: $e')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> restore() async {
    if (!mounted) return;
    await _loadLatestBackup();
    if (!mounted) return;
    if (lastPath == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لومړی په همدې موبایل کې Backup جوړ کړئ')));
      return;
    }
    setState(() => busy = true);
    try {
      await BackupService(widget.database).restoreBackup(lastPath!);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backup بېرته Restore شو')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Restore ستونزه: $e')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> verify() async {
    if (!mounted) return;
    setState(() => busy = true);
    try {
      final ok = await widget.database.integrityOk();
      final rows = await widget.database.db.rawQuery('PRAGMA user_version');
      final version = rows.isEmpty ? 0 : (rows.first.values.first as num?)?.toInt() ?? 0;
      if (!ok) throw StateError('SQLite integrity check failed');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Database سالم دی • Schema v$version')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Verification ستونزه: $e')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Backup / Restore')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Card(child: ListTile(leading: Icon(Icons.verified), title: Text('د معلوماتو خوندیتوب'), subtitle: Text('د Backup مخکې د SQLite integrity check، WAL checkpoint او د Schema Version تایید کېږي.'))),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: busy ? null : backup, icon: const Icon(Icons.backup), label: Text(busy ? 'کار روان دی...' : 'نوی Backup جوړول')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: busy ? null : restore, icon: const Icon(Icons.restore), label: const Text('وروستی Backup Restore کول')),
      const SizedBox(height: 8),
      TextButton.icon(onPressed: busy ? null : verify, icon: const Icon(Icons.fact_check_outlined), label: const Text('Database Verify کول')),
      if (lastPath != null) ...[const SizedBox(height: 16), const Text('وروستی Backup:'), SelectableText(lastPath!)],
      const SizedBox(height: 12),
      const Text('Restore د موجود Database safety copy جوړوي؛ که Restore ناکام شي، پخوانی Database بېرته ساتل کېږي.'),
      const SizedBox(height: 8),
      const Text('یادونه: د Cloud Sync لپاره authenticated HTTPS backend وکاروئ. اپ Offline هم کار کوي او د انټرنېټ په موجودېدو کې Sync په اتومات ډول بیا هڅه کوي.'),
    ]),
  );
}

class SyncConfigPage extends StatefulWidget {
  const SyncConfigPage({super.key, required this.database, required this.businessId});
  final AppDatabase database;
  final String businessId;
  @override State<SyncConfigPage> createState() => _SyncConfigPageState();
}

class _SyncConfigPageState extends State<SyncConfigPage> {
  final baseUrl = TextEditingController();
  final token = TextEditingController();
  bool loading = true;
  bool saving = false;
  bool testing = false;
  bool obscure = true;

  @override void initState() { super.initState(); _load(); }
  @override void dispose() { baseUrl.dispose(); token.dispose(); super.dispose(); }

  Future<void> _load() async {
    final cfg = SyncConfigService(widget.database);
    final url = await cfg.baseUrl() ?? '';
    final auth = await cfg.authToken() ?? '';
    if (!mounted) return;
    baseUrl.text = url;
    token.text = auth;
    setState(() => loading = false);
  }

  Future<void> _save() async {
    final url = baseUrl.text.trim();
    final t = token.text.trim();
    if (!url.startsWith('https://')) { _msg('Sync سرور باید HTTPS وي.'); return; }
    if (t.isEmpty) { _msg('Authentication token داخل کړئ.'); return; }
    setState(() => saving = true);
    try {
      await SyncConfigService(widget.database).save(baseUrl: url, authToken: t);
      _msg('د Sync تنظیمات خوندي شوې.');
    } finally { if (mounted) setState(() => saving = false); }
  }

  Future<void> _clear() async {
    await SyncConfigService(widget.database).clear();
    if (!mounted) return;
    baseUrl.clear(); token.clear();
    _msg('Sync تنظیمات پاکې شوې؛ اپ به Offline پاتې شي.');
  }

  Future<void> _test() async {
    if (!mounted) return;
    setState(() => testing = true);
    try {
      final cfg = SyncConfigService(widget.database);
      final url = await cfg.baseUrl(); final auth = await cfg.authToken();
      if (url == null || auth == null || url.isEmpty || auth.isEmpty) { _msg('لومړی Sync تنظیمات وساتئ.'); return; }
      final deviceId = await DeviceService(widget.database).ensureDevice(widget.businessId);
      final adapter = RestCloudSyncAdapter(baseUrl: url, authToken: auth);
      final cursor = await cfg.cursor(businessId: widget.businessId, deviceId: deviceId);
      final result = await adapter.pull(businessId: widget.businessId, deviceId: deviceId, cursor: cursor);
      // Connection test must never consume the sync cursor. Only the real
      // pull/apply flow advances the cursor after successful application.
      _msg('د Sync سرور اتصال بریالی شو؛ ${result.operations.length} عملیات موجود دي.');
    } catch (e) { _msg('د اتصال ستونزه: $e'); }
    finally { if (mounted) setState(() => testing = false); }
  }

  void _msg(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('د Sync سرور تنظیم')),
    body: loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(16), children: [
      const Card(child: ListTile(leading: Icon(Icons.cloud_sync), title: Text('دوه موبایل اتوماتیک Sync'), subtitle: Text('هر موبایل محلي ثبت کوي؛ انټرنېټ چې موجود وي، ثبتونه د خوندي HTTPS سرور له لارې Sync کېږي.'))),
      const SizedBox(height: 12),
      TextField(controller: baseUrl, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'HTTPS Sync Server URL', hintText: 'https://example.com')),
      TextField(controller: token, obscureText: obscure, decoration: InputDecoration(labelText: 'Authentication Token', suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility : Icons.visibility_off)))),
      const SizedBox(height: 16),
      FilledButton.icon(onPressed: saving ? null : _save, icon: const Icon(Icons.save), label: Text(saving ? 'ساتل کېږي...' : 'تنظیمات ساتل')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: testing ? null : _test, icon: const Icon(Icons.network_check), label: Text(testing ? 'ازمویل کېږي...' : 'اتصال وازمویه')),
      const SizedBox(height: 8),
      TextButton.icon(onPressed: _clear, icon: const Icon(Icons.delete_outline), label: const Text('Sync تنظیمات پاکول')),
      const SizedBox(height: 16),
      const Text('امنیت: Token په بشپړ ډول په UI کې نه ښکاره کېږي. یوازې HTTPS منل کېږي. د سرور خوا باید business isolation، device authentication، operationId idempotency او conflict rules عملي کړي.'),
    ]),
  );
}

class SyncStatusPage extends StatefulWidget {
  const SyncStatusPage({super.key, required this.database, required this.businessId});
  final AppDatabase database;
  final String businessId;
  @override State<SyncStatusPage> createState() => _SyncStatusPageState();
}

class _SyncStatusPageState extends State<SyncStatusPage> {
  late Future<List<Map<String, dynamic>>> future;
  bool busy = false;
  String statusText = 'Offline-first';

  void refresh() {
    if (!mounted) return;
    setState(() {
      future = widget.database.db.query('sync_queue', where: 'business_id = ?', whereArgs: [widget.businessId], orderBy: 'created_at DESC', limit: 100);
    });
  }

  Future<Map<String, int>> counts() async {
    final rows = await widget.database.db.rawQuery(
      'SELECT status, COUNT(*) AS c FROM sync_queue WHERE business_id = ? GROUP BY status',
      [widget.businessId],
    );
    return {for (final r in rows) r['status'].toString(): (r['c'] as num).toInt()};
  }

  @override void initState() { super.initState(); refresh(); }

  Future<void> retryFailed() async {
    if (!mounted) return;
    setState(() => busy = true);
    try {
      await SyncQueueService(widget.database).retryFailed(widget.businessId);
      if (!mounted) return;
      refresh();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Failed عملیات بیا Queue ته ولاړل')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> syncNow() async {
    if (!mounted) return;
    setState(() { busy = true; statusText = 'Sync روان دی...'; });
    try {
      final cfg = SyncConfigService(widget.database);
      final url = await cfg.baseUrl();
      final auth = await cfg.authToken();
      if (url == null || auth == null || url.isEmpty || auth.isEmpty) {
        throw StateError('لومړی د Sync سرور تنظیمات خوندي کړئ.');
      }
      final deviceId = await DeviceService(widget.database).ensureDevice(widget.businessId);
      final adapter = RestCloudSyncAdapter(baseUrl: url, authToken: auth);
      final worker = SyncWorker(widget.database, adapter);
      // SyncWorker already performs both Push and Pull in one atomic cycle.
      // Do not call pullAndApply a second time: that could re-read the same
      // cursor and duplicate work on the UI-triggered sync path.
      final result = await worker.run(widget.businessId);
      if (!mounted) return;
      final summary = 'Push: ${result.synced}، Conflict: ${result.conflicts}، Pull: ${result.pullApplied}';
      refresh();
      if (!mounted) return;
      setState(() => statusText = summary);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sync بشپړ شو • ${summary}')));
    } catch (e) {
      if (!mounted) return;
      setState(() => statusText = 'Sync ستونزه');
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sync ستونزه: $e')));
    } finally { if (mounted) setState(() => busy = false); }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Sync'), actions: [IconButton(onPressed: busy ? null : refresh, icon: const Icon(Icons.refresh))]),
    body: FutureBuilder<List<dynamic>>(
      future: Future.wait([future, counts()]),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final rows = snapshot.data![0] as List<Map<String,dynamic>>;
        final allCounts = snapshot.data![1] as Map<String, int>;
        final pending = (allCounts[SyncQueueStatus.pending] ?? 0) + (allCounts[SyncQueueStatus.retry] ?? 0);
        final synced = allCounts[SyncQueueStatus.synced] ?? 0;
        final failed = allCounts[SyncQueueStatus.failed] ?? 0;
        final conflicts = allCounts[SyncQueueStatus.conflict] ?? 0;
        return ListView(padding: const EdgeInsets.all(16), children: [
          Card(child: ListTile(leading: const Icon(Icons.cloud_sync), title: Text(statusText), subtitle: const Text('ثبتونه لومړی په موبایل کې خوندي کېږي؛ انټرنېټ موجود وي نو Push او Pull دواړه اجرا کېږي.'))),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: busy ? null : syncNow, icon: const Icon(Icons.sync), label: Text(busy ? 'Sync روان دی...' : 'اوس Sync کول'))),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: Card(child: ListTile(title: const Text('Pending'), trailing: Text('$pending')))),
            Expanded(child: Card(child: ListTile(title: const Text('Synced'), trailing: Text('$synced')))),
            Expanded(child: Card(child: ListTile(title: const Text('Failed'), trailing: Text('$failed')))),
          ]),
          Card(child: ListTile(title: const Text('Conflict'), trailing: Text('$conflicts'), leading: const Icon(Icons.warning_amber_outlined))),
          const SizedBox(height: 8),
          if (failed > 0) FilledButton.icon(onPressed: busy ? null : retryFailed, icon: const Icon(Icons.replay), label: const Text('Failed بیا Sync Queue ته ولېږه')),
          ...rows.map((r) => ListTile(leading: Icon(r['status'] == SyncQueueStatus.synced ? Icons.cloud_done : Icons.sync_problem), title: Text('${r['table_name']} • ${r['operation']}'), subtitle: Text('${r['record_id']}'), trailing: Text('${r['status']}'))),
        ]);
      },
    ),
  );
}


class UserManagementPage extends StatefulWidget {
  const UserManagementPage({super.key, required this.database, required this.businessId});
  final AppDatabase database;
  final String businessId;
  @override State<UserManagementPage> createState() => _UserManagementPageState();
}

class _UserManagementPageState extends State<UserManagementPage> {
  bool busy = false;
  Future<List<Map<String, Object?>>> _users() => widget.database.db.query(
    'users', where: 'business_id = ?', whereArgs: [widget.businessId], orderBy: 'created_at ASC');

  Future<void> _showUser({Map<String, Object?>? existing}) async {
    final name = TextEditingController(text: existing?['name']?.toString() ?? '');
    final username = TextEditingController(text: existing?['username']?.toString() ?? '');
    final pin = TextEditingController();
    UserRole role = switch (existing?['role']?.toString()) {
      'manager' => UserRole.manager,
      'cashier' => UserRole.cashier,
      _ => UserRole.owner,
    };
    bool active = (existing?['active'] as int? ?? 1) == 1;
    final formKey = GlobalKey<FormState>();
    await showDialog(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setLocal) => AlertDialog(
      title: Text(existing == null ? 'نوی کاروونکی' : 'کاروونکی سمول'),
      content: Form(key: formKey, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextFormField(controller: name, decoration: const InputDecoration(labelText: 'نوم'), validator: (v) => v!.trim().isEmpty ? 'نوم ولیکئ' : null),
        TextFormField(controller: username, decoration: const InputDecoration(labelText: 'Username'), validator: (v) => v!.trim().isEmpty ? 'Username ولیکئ' : null),
        TextFormField(controller: pin, obscureText: true, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: existing == null ? 'PIN (۴–۸ عدد)' : 'نوی PIN (اختیاري)'), validator: (v) {
          if (existing != null && v!.isEmpty) return null;
          return RegExp(r'^\d{4,8}$').hasMatch(v ?? '') ? null : 'PIN باید ۴–۸ عدد وي';
        }),
        DropdownButtonFormField<UserRole>(value: role, decoration: const InputDecoration(labelText: 'صلاحیت'), items: const [
          DropdownMenuItem(value: UserRole.owner, child: Text('Owner — بشپړ صلاحیت')),
          DropdownMenuItem(value: UserRole.manager, child: Text('Manager — مدیریتي صلاحیت')),
          DropdownMenuItem(value: UserRole.cashier, child: Text('Cashier — ورځني عملیات')),
        ], onChanged: (v) => setLocal(() => role = v ?? UserRole.cashier)),
        SwitchListTile(value: active, title: const Text('فعال'), onChanged: (v) => setLocal(() => active = v)),
      ]))),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('لغوه')), FilledButton(onPressed: () async {
        if (!formKey.currentState!.validate()) return;
        final now = DateTime.now().toUtc().toIso8601String();
        final values = <String, Object?>{'name': name.text.trim(), 'username': username.text.trim(), 'role': role.name, 'active': active ? 1 : 0, 'updated_at': now};
        if (existing == null) {
          values['id'] = newId(); values['business_id'] = widget.businessId; values['created_at'] = now;
          values['pin_hash'] = PinService().hashPin(pin.text.trim());
          await widget.database.db.insert('users', values);
          await AuditService(widget.database.db).log(businessId: widget.businessId, action: 'CREATE', module: 'USER', recordId: values['id'] as String, result: 'OK', details: 'User created');
        } else {
          if (pin.text.trim().isNotEmpty) values['pin_hash'] = PinService().hashPin(pin.text.trim());
          await widget.database.db.update('users', values, where: 'id = ? AND business_id = ?', whereArgs: [existing['id'], widget.businessId]);
          await AuditService(widget.database.db).log(businessId: widget.businessId, action: 'UPDATE', module: 'USER', recordId: existing['id']?.toString(), result: 'OK', details: 'User updated');
        }
        if (ctx.mounted) Navigator.pop(ctx);
        if (mounted) setState(() {});
      }, child: const Text('ساتل'))],
    )));
    name.dispose(); username.dispose(); pin.dispose();
  }

  Future<void> _toggle(Map<String, Object?> u) async {
    if (u['role']?.toString() == 'owner' && (u['active'] as int? ?? 1) == 1) {
      final owners = await widget.database.db.rawQuery('SELECT COUNT(*) c FROM users WHERE business_id = ? AND role = ? AND active = 1', [widget.businessId, 'owner']);
      if ((owners.first['c'] as num).toInt() <= 1) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لږ تر لږه یو فعال Owner باید موجود وي'))); return;
      }
    }
    await widget.database.db.update('users', {'active': (u['active'] as int? ?? 1) == 1 ? 0 : 1, 'updated_at': DateTime.now().toUtc().toIso8601String()}, where: 'id = ? AND business_id = ?', whereArgs: [u['id'], widget.businessId]);
    if (mounted) setState(() {});
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('کاروونکي او صلاحیتونه'), actions: [IconButton(onPressed: busy ? null : () => setState(() {}), icon: const Icon(Icons.refresh))]),
    floatingActionButton: FloatingActionButton.extended(onPressed: () => _showUser(), icon: const Icon(Icons.person_add), label: const Text('نوی کاروونکی')),
    body: FutureBuilder<List<Map<String, Object?>>>(future: _users(), builder: (c, s) {
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      if (s.data!.isEmpty) return const Center(child: Text('تر اوسه کاروونکی نشته'));
      return ListView.separated(padding: const EdgeInsets.all(12), itemCount: s.data!.length, separatorBuilder: (_, __) => const SizedBox(height: 6), itemBuilder: (_, i) {
        final u = s.data![i]; final role = u['role']?.toString() ?? 'cashier'; final active = (u['active'] as int? ?? 1) == 1;
        return Card(child: ListTile(leading: CircleAvatar(child: Icon(role == 'owner' ? Icons.admin_panel_settings : role == 'manager' ? Icons.manage_accounts : Icons.point_of_sale)), title: Text('${u['name']}  •  ${u['username']}'), subtitle: Text('${role.toUpperCase()}  •  ${active ? 'فعال' : 'غیرفعال'}'), trailing: Wrap(spacing: 0, children: [IconButton(tooltip: 'سمول', onPressed: () => _showUser(existing: u), icon: const Icon(Icons.edit)), IconButton(tooltip: active ? 'غیرفعالول' : 'فعالول', onPressed: () => _toggle(u), icon: Icon(active ? Icons.person_off : Icons.person_add_alt_1))])));
      });
    }),
  );
}
