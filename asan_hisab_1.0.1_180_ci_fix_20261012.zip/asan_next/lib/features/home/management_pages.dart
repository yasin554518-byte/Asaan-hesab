import 'package:flutter/material.dart';
import '../../core/database/app_database.dart';
import '../../core/utils/ids.dart';
import '../../shared/services/expense_service.dart';
import '../import_export/csv_import_service.dart';

class CrudListPage extends StatefulWidget {
  const CrudListPage({super.key, required this.database, required this.businessId, required this.type});
  final AppDatabase database;
  final String businessId;
  final CrudType type;
  @override State<CrudListPage> createState() => _CrudListPageState();
}

enum CrudType { products, customers, suppliers }

class _CrudListPageState extends State<CrudListPage> {
  final search = TextEditingController();
  bool loading = true;
  List<Map<String, dynamic>> rows = [];
  int _loadToken = 0;

  String get table => widget.type == CrudType.products ? 'products' : widget.type == CrudType.customers ? 'customers' : 'suppliers';
  String get title => widget.type == CrudType.products ? 'ذخیره / محصولات' : widget.type == CrudType.customers ? 'مشتریان' : 'عرضه کوونکي';
  String get addLabel => widget.type == CrudType.products ? 'محصول اضافه کول' : widget.type == CrudType.customers ? 'مشتری اضافه کول' : 'عرضه کوونکی اضافه کول';

  @override void initState() { super.initState(); load(); search.addListener(load); }
  @override void dispose() { search.dispose(); super.dispose(); }

  Future<void> load() async {
    final token = ++_loadToken;
    final q = search.text.trim();
    final data = await widget.database.db.query(table,
      where: 'business_id = ? AND deleted_at IS NULL${q.isEmpty ? '' : ' AND name LIKE ?'}',
      whereArgs: q.isEmpty ? [widget.businessId] : [widget.businessId, '%$q%'], orderBy: 'name COLLATE NOCASE ASC');
    if (!mounted || token != _loadToken) return;
    setState(() { rows = data; loading = false; });
  }

  Future<void> openEditor([Map<String, dynamic>? existing]) async {
    final name = TextEditingController(text: existing?['name'] as String? ?? '');
    final phone = TextEditingController(text: existing?['phone'] as String? ?? '');
    final address = TextEditingController(text: existing?['address'] as String? ?? '');
    final cost = TextEditingController(text: existing?['cost_price']?.toString() ?? '0');
    final sale = TextEditingController(text: existing?['sale_price']?.toString() ?? '0');
    final stock = TextEditingController(text: existing?['stock_quantity']?.toString() ?? '0');
    final minStock = TextEditingController(text: existing?['minimum_stock']?.toString() ?? '0');
    final barcode = TextEditingController(text: existing?['barcode'] as String? ?? '');
    final part = TextEditingController(text: existing?['part_number'] as String? ?? '');
    final sku = TextEditingController(text: existing?['sku'] as String? ?? '');
    final result = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: Text(existing == null ? addLabel : 'سمون'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'نوم *')),
        if (widget.type != CrudType.products) ...[
          TextField(controller: phone, decoration: const InputDecoration(labelText: 'ټیلیفون')),
          TextField(controller: address, decoration: const InputDecoration(labelText: 'پته')),
        ],
        if (widget.type == CrudType.products) ...[
          TextField(controller: barcode, decoration: const InputDecoration(labelText: 'بارکوډ')),
          TextField(controller: part, decoration: const InputDecoration(labelText: 'Part Number')),
          TextField(controller: sku, decoration: const InputDecoration(labelText: 'SKU')),
          TextField(controller: cost, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'د پېرود قیمت')),
          TextField(controller: sale, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'د پلور قیمت')),
          TextField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ابتدایي ذخیره')),
          TextField(controller: minStock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'د کمې ذخیرې حد')),
        ],
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('لغوه')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ساتل'))],
    ));
    if (!mounted) { for (final c in [name, phone, address, cost, sale, stock, minStock, barcode, part, sku]) { c.dispose(); } return; }
    if (result != true || name.text.trim().isEmpty) { for (final c in [name, phone, address, cost, sale, stock, minStock, barcode, part, sku]) { c.dispose(); } return; }
    if (widget.type == CrudType.products) {
      final numeric = <String, String>{
        'د پېرود قیمت': cost.text,
        'د پلور قیمت': sale.text,
        'ابتدایي ذخیره': stock.text,
        'د کمې ذخیرې حد': minStock.text,
      };
      for (final entry in numeric.entries) {
        final value = int.tryParse(entry.value.trim());
        if (value == null || value < 0) {
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${entry.key} باید صفر یا مثبت عدد وي')));
          return;
        }
      }
    }
    final now = DateTime.now().toIso8601String();
    try {
      if (existing == null) {
        final id = newId();
        final data = <String, dynamic>{'id': id, 'business_id': widget.businessId, 'name': name.text.trim(), 'created_at': now, 'updated_at': now, 'deleted_at': null};
        if (widget.type == CrudType.products) {
          data.addAll({'barcode': _nullable(barcode.text), 'part_number': _nullable(part.text), 'sku': _nullable(sku.text), 'cost_price': _int(cost.text), 'sale_price': _int(sale.text), 'stock_quantity': _int(stock.text), 'minimum_stock': _int(minStock.text), 'unit': 'pcs', 'average_cost': _int(cost.text)});
        } else {
          data.addAll({'phone': _nullable(phone.text), 'address': _nullable(address.text), 'opening_balance': 0});
        }
        await widget.database.db.transaction((txn) async {
          await txn.insert(table, data);
          if (widget.type == CrudType.products) {
            final openingQty = _int(stock.text);
            if (openingQty > 0) {
              await txn.insert('stock_movements', {
                'id': newId(), 'business_id': widget.businessId, 'product_id': id,
                'movement_type': 'OPENING', 'quantity': openingQty, 'reference_type': 'OPENING_STOCK',
                'reference_id': id, 'unit_cost': _int(cost.text), 'date': now, 'created_at': now,
              });
            }
            await txn.insert('audit_logs', {
              'id': newId(), 'business_id': widget.businessId, 'action': 'CREATE', 'module': 'PRODUCTS',
              'record_id': id, 'result': 'SUCCESS', 'details': 'OPENING_STOCK', 'created_at': now,
            });
          }
        });
      } else {
        final data = <String, dynamic>{'name': name.text.trim(), 'updated_at': now};
        if (widget.type == CrudType.products) {
          data.addAll({'barcode': _nullable(barcode.text), 'part_number': _nullable(part.text), 'sku': _nullable(sku.text), 'cost_price': _int(cost.text), 'sale_price': _int(sale.text), 'minimum_stock': _int(minStock.text)});
        } else {
          data.addAll({'phone': _nullable(phone.text), 'address': _nullable(address.text)});
        }
        await widget.database.db.update(table, data, where: 'id = ? AND business_id = ?', whereArgs: [existing['id'], widget.businessId]);
      }
      await load();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('معلومات ثبت/سمې شوې')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('ستونزه: $e')));
    }
    for (final c in [name, phone, address, cost, sale, stock, minStock, barcode, part, sku]) { c.dispose(); }
  }

  Future<void> remove(Map<String, dynamic> row) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(title: const Text('حذف؟'), content: const Text('معلومات به Soft Delete شي؛ مالي تاریخ نه پاکېږي.'), actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('لغوه')), FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('هو'))]));
    if (!mounted || ok != true) return;
    await widget.database.db.update(table, {'deleted_at': DateTime.now().toIso8601String(), 'updated_at': DateTime.now().toIso8601String()}, where: 'id = ? AND business_id = ?', whereArgs: [row['id'], widget.businessId]);
    await load();
  }

  int _int(String s) => int.tryParse(s.trim()) ?? 0;
  String? _nullable(String s) => s.trim().isEmpty ? null : s.trim();

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: loading ? const Center(child: CircularProgressIndicator()) : Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: TextField(controller: search, decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'لټون', border: OutlineInputBorder()))),
      Expanded(child: rows.isEmpty ? Center(child: Text('تر اوسه معلومات نشته')) : ListView.builder(itemCount: rows.length, itemBuilder: (_, i) {
        final r = rows[i];
        final subtitle = widget.type == CrudType.products ? 'ذخیره: ${r['stock_quantity']} | پلور: ${r['sale_price']}' : '${r['phone'] ?? ''} ${r['address'] ?? ''}';
        return ListTile(title: Text(r['name'] as String), subtitle: Text(subtitle), leading: CircleAvatar(child: Icon(widget.type == CrudType.products ? Icons.inventory_2 : Icons.person)), trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') openEditor(r); if (v == 'delete') remove(r); }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('سمون')), PopupMenuItem(value: 'delete', child: Text('حذف'))]));
      })),
    ]),
    floatingActionButton: FloatingActionButton.extended(onPressed: openEditor, icon: const Icon(Icons.add), label: Text(addLabel)),
  );
}

class ExpensePage extends StatefulWidget {
  const ExpensePage({super.key, required this.database, required this.businessId});
  final AppDatabase database; final String businessId;
  @override State<ExpensePage> createState() => _ExpensePageState();
}
class _ExpensePageState extends State<ExpensePage> {
  final category = TextEditingController(); final amount = TextEditingController(); final note = TextEditingController(); bool saving = false;
  Future<void> save() async { final a = int.tryParse(amount.text) ?? 0; if (category.text.trim().isEmpty || a <= 0) { _msg('کټګوري او مبلغ سم کړئ'); return; } if (!mounted) return; setState(() => saving = true); try { await ExpenseService(widget.database.db).createExpense(businessId: widget.businessId, category: category.text.trim(), amount: a, note: note.text.trim().isEmpty ? null : note.text.trim()); if (mounted) { category.clear(); amount.clear(); note.clear(); _msg('مصرف ثبت شو'); } } catch (e) { _msg('ستونزه: $e'); } finally { if (mounted) setState(() => saving = false); } }
  void _msg(String x) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(x))); }
  @override void dispose() { category.dispose(); amount.dispose(); note.dispose(); super.dispose(); }
  @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('مصارف')), body: ListView(padding: const EdgeInsets.all(16), children: [TextField(controller: category, decoration: const InputDecoration(labelText: 'کټګوري')), TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'مبلغ')), TextField(controller: note, decoration: const InputDecoration(labelText: 'یادښت')), const SizedBox(height: 16), FilledButton(onPressed: saving ? null : save, child: Text(saving ? 'ثبتېږي...' : 'مصرف ثبتول'))]));
}

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key, required this.database, required this.businessId});
  final AppDatabase database; final String businessId;

  Future<Map<String,int>> load() async {
    Future<int> q(String sql, [List<Object?> args = const []]) async {
      final r = await database.db.rawQuery(sql, args);
      return (r.first.values.first as num?)?.toInt() ?? 0;
    }
    final sales = await q('SELECT COALESCE(SUM(total),0) FROM sales WHERE business_id=?',[businessId]);
    final saleReturns = await q("SELECT COALESCE(SUM(total),0) FROM returns WHERE business_id=? AND return_type='SALE_RETURN'",[businessId]);
    final purchases = await q('SELECT COALESCE(SUM(total),0) FROM purchases WHERE business_id=?',[businessId]);
    final purchaseReturns = await q("SELECT COALESCE(SUM(total),0) FROM returns WHERE business_id=? AND return_type='PURCHASE_RETURN'",[businessId]);
    final cogs = await q('SELECT COALESCE(SUM(si.quantity*si.cost_price),0) FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.business_id=?',[businessId]) - await q("SELECT COALESCE(SUM(ri.quantity*ri.cost_price),0) FROM return_items ri JOIN returns r ON r.id=ri.return_id WHERE r.business_id=? AND r.return_type='SALE_RETURN'",[businessId]);
    final expenses = await q('SELECT COALESCE(SUM(amount),0) FROM expenses WHERE business_id=?',[businessId]);
    final cash = await q('SELECT COALESCE(SUM(amount),0) FROM cash_transactions WHERE business_id=?',[businessId]);
    final stock = await q('SELECT COALESCE(SUM(stock_quantity*average_cost),0) FROM products WHERE business_id=?',[businessId]);
    final customerDue = await q("SELECT COALESCE(SUM(c.opening_balance),0)+COALESCE((SELECT SUM(l.debit-l.credit) FROM ledger_entries l WHERE l.business_id=c.business_id AND l.party_type='CUSTOMER' AND l.party_id=c.id),0) FROM customers c WHERE c.business_id=? AND c.deleted_at IS NULL",[businessId]);
    final supplierDue = await q("SELECT COALESCE(SUM(s.opening_balance),0)+COALESCE((SELECT SUM(l.credit-l.debit) FROM ledger_entries l WHERE l.business_id=s.business_id AND l.party_type='SUPPLIER' AND l.party_id=s.id),0) FROM suppliers s WHERE s.business_id=?",[businessId]);
    final netSales=sales-saleReturns, grossProfit=netSales-cogs, netProfit=grossProfit-expenses;
    return {'sales':sales,'saleReturns':saleReturns,'netSales':netSales,'purchases':purchases,'purchaseReturns':purchaseReturns,'cogs':cogs,'expenses':expenses,'grossProfit':grossProfit,'netProfit':netProfit,'cash':cash,'stock':stock,'customerDue':customerDue,'supplierDue':supplierDue};
  }
  @override Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('راپورونه')),
    body: FutureBuilder<Map<String,int>>(future: load(), builder: (_, s) {
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      final d=s.data!;
      final rows=[('ټول پلور',d['sales']!),('د پلور بېرته ستنول',d['saleReturns']!),('خالص پلور',d['netSales']!),('ټول پېرود',d['purchases']!),('د پېرود بېرته ستنول',d['purchaseReturns']!),('COGS / د مال لګښت',d['cogs']!),('ناخالصه ګټه',d['grossProfit']!),('ټول مصارف',d['expenses']!),('خالصه ګټه',d['netProfit']!),('نغدې',d['cash']!),('د ذخیرې ارزښت',d['stock']!),('د مشتریانو قرض',d['customerDue']!),('د عرضه کوونکو قرض',d['supplierDue']!)];
      return ListView(padding: const EdgeInsets.all(12), children:[Text('مالي او سوداګریز راپور',style:Theme.of(c).textTheme.headlineSmall),const SizedBox(height:8),GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:rows.length,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:8,mainAxisSpacing:8,childAspectRatio:1.55),itemBuilder:(_,i)=>Card(child:Padding(padding:const EdgeInsets.all(10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(rows[i].$1),const Spacer(),Text('${rows[i].$2}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold))]))))]);
    }),
  );
}

class CsvImportPage extends StatefulWidget {
  const CsvImportPage({super.key, required this.database, required this.businessId});
  final AppDatabase database; final String businessId;
  @override State<CsvImportPage> createState()=>_CsvImportPageState();
}
class _CsvImportPageState extends State<CsvImportPage>{
  final csv=TextEditingController(); bool busy=false; bool importing=false; String result=''; CsvImportPreview? preview;
  @override void dispose(){csv.dispose();super.dispose();}
  Future<void> previewProducts() async {
    if(csv.text.trim().isEmpty){setState(()=>result='CSV متن داخل کړئ');return;}
    setState(()=>busy=true);
    try{
      final p=await CsvImportService(widget.database.db).previewProducts(businessId:widget.businessId,csv:csv.text);
      if (!mounted) return;
      setState(() {
        preview = p;
        result = p.canImport
            ? 'چمتو دی: ${p.validRows} ریکارډونه به اضافه شي.'
            : 'د Import لپاره ستونزې شته:\n${p.errors.join('\n')}';
      });
    }catch(e){if(mounted)setState(()=>result='ستونزه: $e');}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> confirmImport() async {
    final p=preview;
    if(p==null || !p.canImport) return;
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:const Text('Import تایید'),
      content:Text('ایا ${p.validRows} محصولات په بشپړ ډول ثبت کړو؟\nکه کومه ستونزه رامنځته شي، ټول Batch به Rollback شي.'),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('لغوه')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('تایید'))],
    )) ?? false;
    if(!ok)return;
    if (!mounted) return;
    setState(()=>importing=true);
    try{
      final r=await CsvImportService(widget.database.db).importProducts(businessId:widget.businessId,csv:csv.text);
      if (!mounted) return;
      setState(()=>result='ټول: ${r.total} | ثبت: ${r.inserted}${r.errors.isEmpty?'':'\n'+r.errors.join('\n')}');
      if(r.errors.isEmpty && mounted) setState(()=>preview=null);
    }catch(e){if(mounted)setState(()=>result='ستونزه: $e');}
    finally{if(mounted)setState(()=>importing=false);}
  }
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('CSV Import')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('لومړی Preview/Validation وکړئ؛ تر تایید مخکې Database ته هېڅ شی نه لیکل کېږي.'),
      const SizedBox(height:8),const SelectableText('name,barcode,part_number,sku,cost_price,sale_price,stock,minimum_stock,unit'),
      const SizedBox(height:10),TextField(controller:csv,minLines:8,maxLines:16,decoration:const InputDecoration(border:OutlineInputBorder(),hintText:'CSV دلته Paste کړئ')),
      const SizedBox(height:12),
      FilledButton.icon(onPressed:busy||importing?null:previewProducts,icon:const Icon(Icons.preview),label:Text(busy?'چک کېږي...':'Preview او Validation')),
      if(preview?.canImport==true) ...[
        const SizedBox(height:10),
        Card(child:ListTile(leading:const Icon(Icons.check_circle),title:Text('${preview!.validRows} ریکارډونه معتبر دي'),subtitle:const Text('اوس د Import لپاره تایید وکړئ.'),trailing:FilledButton(onPressed:importing?null:confirmImport,child:Text(importing?'ثبتېږي...':'Import تایید')))),
      ],
      if(result.isNotEmpty)...[const SizedBox(height:12),Card(child:Padding(padding:const EdgeInsets.all(12),child:SelectableText(result)))],
    ]));
}
class CalculatorPage extends StatefulWidget { const CalculatorPage({super.key}); @override State<CalculatorPage> createState()=>_CalculatorPageState(); }
class _CalculatorPageState extends State<CalculatorPage>{final input=TextEditingController();String result='0';void calc(){final m=RegExp(r'^\s*(\d+)\s*([+\-*/])\s*(\d+)\s*$').firstMatch(input.text);if(m==null){result=(int.tryParse(input.text.trim())??0).toString();}else{final a=int.parse(m.group(1)!),b=int.parse(m.group(3)!);switch(m.group(2)){case '+':result='${a+b}';break;case '-':result='${a-b}';break;case '*':result='${a*b}';break;case '/':result=b==0?'0':'${a~/b}';}}setState((){});} @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('ماشین حساب')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[Text(result,style:const TextStyle(fontSize:36,fontWeight:FontWeight.bold)),TextField(controller:input,keyboardType:TextInputType.text,decoration:const InputDecoration(labelText:'مثال: 1250 + 750')),const SizedBox(height:16),FilledButton(onPressed:calc,child:const Text('حساب'))]));}
