import 'package:sqflite/sqflite.dart';
import '../../core/utils/ids.dart';

class CsvImportResult {
  const CsvImportResult({required this.total, required this.inserted, required this.errors});
  final int total;
  final int inserted;
  final List<String> errors;
}

class CsvImportPreview {
  const CsvImportPreview({required this.total, required this.validRows, required this.errors});
  final int total;
  final int validRows;
  final List<String> errors;
  bool get canImport => total > 0 && errors.isEmpty && validRows == total;
}

/// Strict, atomic CSV importer. Preview performs all validation without writes;
/// import revalidates and commits the complete batch in one transaction.
class CsvImportService {
  final Database db;
  const CsvImportService(this.db);

  List<List<String>> _parse(String csv) {
    final rows = <List<String>>[];
    for (final raw in csv.replaceAll('\r\n', '\n').replaceAll('\r', '\n').split('\n')) {
      if (raw.trim().isEmpty) continue;
      final cells = <String>[];
      var cell = StringBuffer();
      var quoted = false;
      for (var i = 0; i < raw.length; i++) {
        final ch = raw[i];
        if (ch == '"') {
          if (quoted && i + 1 < raw.length && raw[i + 1] == '"') { cell.write('"'); i++; }
          else { quoted = !quoted; }
        } else if (ch == ',' && !quoted) {
          cells.add(cell.toString().trim()); cell = StringBuffer();
        } else { cell.write(ch); }
      }
      if (quoted) throw const FormatException('CSV quotation is not closed');
      cells.add(cell.toString().trim());
      rows.add(cells);
    }
    return rows;
  }

  int _money(String value, String field) {
    final v = int.tryParse(value.trim());
    if (v == null || v < 0) throw FormatException('$field must be a non-negative integer');
    return v;
  }

  Future<List<Map<String, dynamic>>> _prepare({required String businessId, required String csv}) async {
    if (csv.length > 5 * 1024 * 1024) {
      throw const FormatException('CSV file is too large (maximum 5 MB)');
    }
    final rows = _parse(csv);
    if (rows.isEmpty) return const [];
    final header = rows.first.map((e) => e.toLowerCase()).toList();
    const required = ['name','barcode','part_number','sku','cost_price','sale_price','stock','minimum_stock','unit'];
    if (header.length != required.length || !required.every((e) => header.contains(e))) {
      throw const FormatException('Product CSV header must be: name,barcode,part_number,sku,cost_price,sale_price,stock,minimum_stock,unit');
    }
    final idx = {for (var i = 0; i < header.length; i++) header[i]: i};
    final errors = <String>[];
    final prepared = <Map<String,dynamic>>[];
    final seenBarcodes = <String>{};
    final seenSkus = <String>{};
    for (var r = 1; r < rows.length; r++) {
      final row = rows[r];
      try {
        if (row.length != header.length) throw const FormatException('wrong column count');
        final name = row[idx['name']!];
        if (name.isEmpty) throw const FormatException('name is required');
        final barcode = row[idx['barcode']!].isEmpty ? null : row[idx['barcode']!];
        final sku = row[idx['sku']!].isEmpty ? null : row[idx['sku']!];
        final stock = int.tryParse(row[idx['stock']!]);
        final minimum = int.tryParse(row[idx['minimum_stock']!]);
        if (stock == null || stock < 0) throw const FormatException('stock must be a non-negative integer');
        if (minimum == null || minimum < 0) throw const FormatException('minimum_stock must be a non-negative integer');
        if (barcode != null && !seenBarcodes.add(barcode)) throw const FormatException('duplicate barcode inside CSV');
        if (sku != null && !seenSkus.add(sku)) throw const FormatException('duplicate SKU inside CSV');
        final now = DateTime.now().toIso8601String();
        prepared.add({
          'id': newId(), 'business_id': businessId, 'name': name,
          'barcode': barcode, 'part_number': row[idx['part_number']!].isEmpty ? null : row[idx['part_number']!],
          'sku': sku, 'cost_price': _money(row[idx['cost_price']!], 'cost_price'),
          'sale_price': _money(row[idx['sale_price']!], 'sale_price'), 'stock_quantity': stock,
          'minimum_stock': minimum, 'unit': row[idx['unit']!].isEmpty ? 'pcs' : row[idx['unit']!],
          'average_cost': _money(row[idx['cost_price']!], 'cost_price'), 'created_at': now, 'updated_at': now,
        });
      } catch (e) { errors.add('Row ${r + 1}: $e'); }
    }
    if (errors.isNotEmpty) throw FormatException(errors.join('\n'));
    for (final item in prepared) {
      final dup = await db.rawQuery(
        'SELECT id FROM products WHERE business_id=? AND ((barcode IS NOT NULL AND barcode=?) OR (sku IS NOT NULL AND sku=?)) LIMIT 1',
        [businessId, item['barcode'], item['sku']],
      );
      if (dup.isNotEmpty) throw StateError('Existing barcode/SKU conflict: ${item['barcode'] ?? item['sku']}');
    }
    return prepared;
  }

  Future<CsvImportPreview> previewProducts({required String businessId, required String csv}) async {
    var total = 0;
    try {
      final rows = _parse(csv);
      total = rows.isEmpty ? 0 : rows.length - 1;
      final prepared = await _prepare(businessId: businessId, csv: csv);
      return CsvImportPreview(total: total, validRows: prepared.length, errors: const []);
    } catch (e) {
      final errors = e is FormatException
          ? e.message.split('\n').where((x) => x.trim().isNotEmpty).toList()
          : [e.toString()];
      return CsvImportPreview(total: total, validRows: 0, errors: errors);
    }
  }

  Future<CsvImportResult> importProducts({required String businessId, required String csv}) async {
    List<Map<String,dynamic>> prepared;
    try {
      prepared = await _prepare(businessId: businessId, csv: csv);
    } catch (e) {
      final rows = _parse(csv);
      return CsvImportResult(total: rows.isEmpty ? 0 : rows.length - 1, inserted: 0, errors: e is FormatException ? e.message.split('\n') : [e.toString()]);
    }
    if (prepared.isEmpty) return const CsvImportResult(total: 0, inserted: 0, errors: []);
    try {
      await db.transaction((txn) async {
        for (final item in prepared) {
          await txn.insert('products', item);
          final qty = item['stock_quantity'] as int;
          if (qty > 0) {
            await txn.insert('stock_movements', {
              'id': newId(), 'business_id': businessId, 'product_id': item['id'], 'movement_type': 'OPENING',
              'quantity': qty, 'reference_type': 'CSV_IMPORT', 'reference_id': item['id'],
              'unit_cost': item['average_cost'], 'date': item['created_at'], 'created_at': item['created_at'],
            });
          }
        }
      });
    } catch (e) {
      return CsvImportResult(total: prepared.length, inserted: 0, errors: [e.toString()]);
    }
    return CsvImportResult(total: prepared.length, inserted: prepared.length, errors: const []);
  }
}
