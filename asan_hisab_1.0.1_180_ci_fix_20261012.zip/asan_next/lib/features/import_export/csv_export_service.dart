import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import '../../core/database/app_database.dart';

class CsvExportService {
  CsvExportService(this.database);
  final AppDatabase database;

  Future<File> exportTable({required String table, required String directory, String? businessId}) async {
    const allowed = {'products','customers','suppliers','sales','purchases','payments','expenses','returns'};
    if (!allowed.contains(table)) throw ArgumentError('Unsupported export table');
    final rows = await database.db.query(table,
        where: businessId == null ? null : 'business_id = ?',
        whereArgs: businessId == null ? null : [businessId]);
    final file = File(p.join(directory, '${table}_${DateTime.now().millisecondsSinceEpoch}.csv'));
    if (rows.isEmpty) {
      await file.writeAsString('');
      return file;
    }
    final keys = rows.first.keys.toList();
    final lines = <String>[keys.map(_escape).join(',')];
    for (final row in rows) {
      lines.add(keys.map((k) => _escape(row[k])).join(','));
    }
    await file.writeAsString(lines.join('\n'), encoding: utf8);
    return file;
  }

  String _escape(Object? value) {
    final s = value?.toString() ?? '';
    return '"${s.replaceAll('"', '""')}"';
  }
}
