import 'package:sqflite/sqflite.dart';
import '../../core/utils/ids.dart';

class ExpenseService {
  final Database db;
  const ExpenseService(this.db);

  Future<String> createExpense({required String businessId, required String category, required int amount, String? note, String? userId}) async {
    if (amount <= 0) throw ArgumentError('Expense must be positive');
    return db.transaction((txn) async {
      final now = DateTime.now().toIso8601String();
      final id = newId();
      await txn.insert('expenses', {'id': id, 'business_id': businessId, 'category': category, 'amount': amount, 'note': note, 'date': now, 'created_at': now});
      await txn.insert('cash_transactions', {
        'id': newId(), 'business_id': businessId, 'transaction_type': 'EXPENSE', 'amount': -amount,
        'reference_type': 'EXPENSE', 'reference_id': id, 'note': note, 'date': now, 'created_at': now,
      });
      await txn.insert('audit_logs', {'id': newId(), 'business_id': businessId, 'user_id': userId, 'action': 'CREATE', 'module': 'EXPENSES', 'record_id': id, 'result': 'SUCCESS', 'details': category, 'created_at': now});
      return id;
    });
  }
}
