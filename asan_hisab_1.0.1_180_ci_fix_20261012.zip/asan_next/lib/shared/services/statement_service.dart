import 'package:sqflite/sqflite.dart';
import '../../core/utils/ledger_balance.dart';

class StatementService {
  final Database db;
  const StatementService(this.db);

  Future<List<Map<String, Object?>>> partyStatement({
    required String businessId,
    required String partyType,
    required String partyId,
    DateTime? fromDate,
    DateTime? toDate,
  }) async {
    final type = partyType.toUpperCase();
    if (type != 'CUSTOMER' && type != 'SUPPLIER') throw ArgumentError('Invalid party type');
    final table = type == 'CUSTOMER' ? 'customers' : 'suppliers';
    final party = await db.query(
      table,
      columns: ['opening_balance'],
      where: 'id = ? AND business_id = ?',
      whereArgs: [partyId, businessId],
      limit: 1,
    );
    if (party.isEmpty) throw StateError('Party not found');

    final opening = (party.first['opening_balance'] as num?)?.toInt() ?? 0;
    final rows = await db.rawQuery('''
      SELECT id, date, created_at, entry_type, debit, credit, reference_type, reference_id, note
      FROM ledger_entries
      WHERE business_id = ? AND party_type = ? AND party_id = ?
      ORDER BY date ASC, created_at ASC, id ASC
    ''', [businessId, type, partyId]);

    String? isoStart(DateTime? value) => value?.toUtc().toIso8601String();
    final from = isoStart(fromDate);
    final to = toDate == null ? null : DateTime(toDate.year, toDate.month, toDate.day, 23, 59, 59, 999).toUtc().toIso8601String();
    var running = opening;
    final result = <Map<String, Object?>>[];
    for (final row in rows) {
      final date = DateTime.tryParse('${row['date'] ?? ''}');
      final debit = (row['debit'] as num?)?.toInt() ?? 0;
      final credit = (row['credit'] as num?)?.toInt() ?? 0;
      running = LedgerBalance.apply(
        partyType: type,
        balance: running,
        debit: debit,
        credit: credit,
      );
      if ((from == null || (date != null && !date.toUtc().isBefore(DateTime.parse(from)))) &&
          (to == null || (date != null && !date.toUtc().isAfter(DateTime.parse(to))))) {
        result.add(<String, Object?>{...row, 'running_balance': running});
      }
    }
    return result;
  }

  Future<int> openingBalanceAt({required String businessId, required String partyType, required String partyId, DateTime? fromDate}) async {
    final type = partyType.toUpperCase();
    final table = type == 'CUSTOMER' ? 'customers' : type == 'SUPPLIER' ? 'suppliers' : null;
    if (table == null) throw ArgumentError('Invalid party type');
    final party = await db.query(table, columns: ['opening_balance'], where: 'id = ? AND business_id = ?', whereArgs: [partyId, businessId], limit: 1);
    if (party.isEmpty) throw StateError('Party not found');
    final opening = (party.first['opening_balance'] as num?)?.toInt() ?? 0;
    if (fromDate == null) return opening;
    final cutoff = DateTime(fromDate.year, fromDate.month, fromDate.day).toUtc().toIso8601String();
    final rows = await db.rawQuery('''
      SELECT debit, credit FROM ledger_entries
      WHERE business_id = ? AND party_type = ? AND party_id = ? AND date < ?
      ORDER BY date ASC, created_at ASC, id ASC
    ''', [businessId, type, partyId, cutoff]);
    var running = opening;
    for (final row in rows) {
      running = LedgerBalance.apply(
        partyType: type,
        balance: running,
        debit: (row['debit'] as num?)?.toInt() ?? 0,
        credit: (row['credit'] as num?)?.toInt() ?? 0,
      );
    }
    return running;
  }

  Future<int> balance({required String businessId, required String partyType, required String partyId}) async {
    final type = partyType.toUpperCase();
    final table = type == 'CUSTOMER' ? 'customers' : type == 'SUPPLIER' ? 'suppliers' : null;
    if (table == null) throw ArgumentError('Invalid party type');
    final party = await db.query(table, columns: ['opening_balance'], where: 'id = ? AND business_id = ?', whereArgs: [partyId, businessId], limit: 1);
    if (party.isEmpty) throw StateError('Party not found');
    final row = (await db.rawQuery('SELECT COALESCE(SUM(debit),0) debit, COALESCE(SUM(credit),0) credit FROM ledger_entries WHERE business_id = ? AND party_type = ? AND party_id = ?', [businessId, type, partyId])).first;
    final opening = (party.first['opening_balance'] as num?)?.toInt() ?? 0;
    final debit = (row['debit'] as num).toInt();
    final credit = (row['credit'] as num).toInt();
    return LedgerBalance.fromTotals(
      partyType: type,
      balance: opening,
      debit: debit,
      credit: credit,
    );
  }
}
