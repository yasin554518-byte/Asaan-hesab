import 'package:sqflite/sqflite.dart';

class DashboardSummary {
  final int todaySales;
  final int todayPurchases;
  final int todayExpenses;
  final int cashBalance;
  final int customerDue;
  final int supplierDue;
  final int stockValue;
  final int netProfit;
  const DashboardSummary({required this.todaySales, required this.todayPurchases, required this.todayExpenses, required this.cashBalance, required this.customerDue, required this.supplierDue, required this.stockValue, required this.netProfit});
}

class DashboardService {
  final Database db;
  const DashboardService(this.db);

  Future<DashboardSummary> load(String businessId) async {
    final day = DateTime.now().toIso8601String().substring(0, 10);
    final sales = await db.rawQuery("SELECT COALESCE(SUM(total),0) v FROM sales WHERE business_id = ? AND substr(date,1,10)=?", [businessId, day]);
    final purchases = await db.rawQuery("SELECT COALESCE(SUM(total),0) v FROM purchases WHERE business_id = ? AND substr(date,1,10)=?", [businessId, day]);
    final expenses = await db.rawQuery("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE business_id = ? AND substr(date,1,10)=?", [businessId, day]);
    final cash = await db.rawQuery("SELECT COALESCE(SUM(amount),0) v FROM cash_transactions WHERE business_id = ?", [businessId]);
    final customers = await db.rawQuery("SELECT COALESCE(SUM(opening_balance),0) + COALESCE((SELECT SUM(debit-credit) FROM ledger_entries l WHERE l.business_id=c.business_id AND l.party_type='CUSTOMER' AND l.party_id=c.id),0) v FROM customers c WHERE c.business_id=? AND c.deleted_at IS NULL", [businessId]);
    final suppliers = await db.rawQuery("SELECT COALESCE(SUM(opening_balance),0) + COALESCE((SELECT SUM(credit-debit) FROM ledger_entries l WHERE l.business_id=s.business_id AND l.party_type='SUPPLIER' AND l.party_id=s.id),0) v FROM suppliers s WHERE s.business_id=? AND s.deleted_at IS NULL", [businessId]);
    final stock = await db.rawQuery("SELECT COALESCE(SUM(stock_quantity * average_cost),0) v FROM products WHERE business_id=? AND deleted_at IS NULL", [businessId]);
    final netSales = await db.rawQuery("SELECT COALESCE((SELECT SUM(total) FROM sales WHERE business_id=?),0) - COALESCE((SELECT SUM(total) FROM returns WHERE business_id=? AND return_type='SALE_RETURN'),0) v", [businessId, businessId]);
    final cogs = await db.rawQuery("SELECT COALESCE((SELECT SUM(si.quantity * si.cost_price) FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.business_id=?),0) - COALESCE((SELECT SUM(ri.quantity * ri.cost_price) FROM return_items ri JOIN returns r ON r.id=ri.return_id WHERE r.business_id=? AND r.return_type='SALE_RETURN'),0) v", [businessId, businessId]);
    final expenseAll = await db.rawQuery("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE business_id=?", [businessId]);
    int v(List<Map<String,Object?>> r) => (r.first['v'] as num).toInt();
    final grossProfit = v(netSales) - v(cogs);
    return DashboardSummary(todaySales: v(sales), todayPurchases: v(purchases), todayExpenses: v(expenses), cashBalance: v(cash), customerDue: v(customers), supplierDue: v(suppliers), stockValue: v(stock), netProfit: grossProfit - v(expenseAll));
  }
}
