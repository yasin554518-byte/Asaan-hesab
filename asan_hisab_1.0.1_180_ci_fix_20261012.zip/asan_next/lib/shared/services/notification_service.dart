import 'package:sqflite/sqflite.dart';

class BusinessAlert {
  final String type;
  final String title;
  final String detail;
  final int amount;
  final String? partyId;
  final int severity;
  const BusinessAlert({required this.type, required this.title, required this.detail, this.amount = 0, this.partyId, this.severity = 1});
}

/// Offline-first in-app alerts. This deliberately avoids claiming OS push
/// notifications until a real notification adapter is configured.
class NotificationService {
  final Database db;
  const NotificationService(this.db);

  Future<List<BusinessAlert>> loadAlerts(String businessId) async {
    final alerts = <BusinessAlert>[];
    final low = await db.rawQuery('''
      SELECT name, stock_quantity, minimum_stock FROM products
      WHERE business_id=? AND deleted_at IS NULL AND minimum_stock > 0
        AND stock_quantity <= minimum_stock
      ORDER BY stock_quantity ASC, name ASC LIMIT 50
    ''', [businessId]);
    for (final r in low) {
      alerts.add(BusinessAlert(
        type: 'LOW_STOCK',
        title: 'د ذخیرې خبرتیا',
        detail: '${r['name']} — موجودي: ${r['stock_quantity']}، حد: ${r['minimum_stock']}',
        severity: (r['stock_quantity'] as num? ?? 0) <= 0 ? 3 : 2,
      ));
    }

    final customers = await db.rawQuery('''
      SELECT c.name, c.id,
        COALESCE(c.opening_balance,0) + COALESCE((
          SELECT SUM(debit-credit) FROM ledger_entries l
          WHERE l.business_id=c.business_id AND l.party_type='CUSTOMER' AND l.party_id=c.id
        ),0) AS balance
      FROM customers c
      WHERE c.business_id=? AND c.deleted_at IS NULL
      ORDER BY balance DESC LIMIT 100
    ''', [businessId]);
    for (final r in customers) {
      final balance = (r['balance'] as num?)?.toInt() ?? 0;
      if (balance > 0) {
        alerts.add(BusinessAlert(
          type: 'CUSTOMER_DUE',
          title: 'د مشتری قرض',
          detail: '${r['name']} — پاتې قرض: $balance',
          amount: balance,
          partyId: r['id'] as String?,
          severity: balance >= 100000 ? 3 : 2,
        ));
      }
    }

    final suppliers = await db.rawQuery('''
      SELECT s.name, s.id,
        COALESCE(s.opening_balance,0) + COALESCE((
          SELECT SUM(credit-debit) FROM ledger_entries l
          WHERE l.business_id=s.business_id AND l.party_type='SUPPLIER' AND l.party_id=s.id
        ),0) AS balance
      FROM suppliers s
      WHERE s.business_id=? AND s.deleted_at IS NULL
      ORDER BY balance DESC LIMIT 100
    ''', [businessId]);
    for (final r in suppliers) {
      final balance = (r['balance'] as num?)?.toInt() ?? 0;
      if (balance > 0) {
        alerts.add(BusinessAlert(
          type: 'SUPPLIER_DUE',
          title: 'د عرضه کوونکي قرض',
          detail: '${r['name']} — پاتې قرض: $balance',
          amount: balance,
          partyId: r['id'] as String?,
          severity: balance >= 100000 ? 3 : 2,
        ));
      }
    }
    // Stable de-duplication plus severity ordering keeps the most urgent
    // business risks visible first without generating duplicate rows.
    final seen = <String>{};
    final unique = alerts.where((a) => seen.add('${a.type}|${a.partyId ?? a.detail}')).toList();
    unique.sort((a, b) {
      final bySeverity = b.severity.compareTo(a.severity);
      if (bySeverity != 0) return bySeverity;
      final byAmount = b.amount.compareTo(a.amount);
      if (byAmount != 0) return byAmount;
      return a.detail.compareTo(b.detail);
    });
    return unique;
  }
}
