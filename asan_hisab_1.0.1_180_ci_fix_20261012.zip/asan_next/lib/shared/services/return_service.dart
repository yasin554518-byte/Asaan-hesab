import 'package:sqflite/sqflite.dart';
import '../../core/utils/ids.dart';
import '../../core/device/device_service.dart';
import '../../core/sync/sync_queue_service.dart';
import '../models/return_models.dart';

class ReturnService {
  final Database db;
  const ReturnService(this.db);

  Future<ReturnResult> createSalesReturn({
    required String businessId,
    required String referenceNo,
    required String originalReference,
    required List<ReturnLineInput> lines,
    required int refund,
    String? customerId,
    String? userId,
  }) async {
    return _create(
      businessId: businessId,
      referenceNo: referenceNo,
      originalReference: originalReference,
      returnType: 'SALE_RETURN',
      lines: lines,
      refund: refund,
      partyId: customerId,
      userId: userId,
    );
  }

  Future<ReturnResult> createPurchaseReturn({
    required String businessId,
    required String referenceNo,
    required String originalReference,
    required List<ReturnLineInput> lines,
    required int refund,
    String? supplierId,
    String? userId,
  }) async {
    return _create(
      businessId: businessId,
      referenceNo: referenceNo,
      originalReference: originalReference,
      returnType: 'PURCHASE_RETURN',
      lines: lines,
      refund: refund,
      partyId: supplierId,
      userId: userId,
    );
  }

  Future<ReturnResult> _create({
    required String businessId,
    required String referenceNo,
    required String originalReference,
    required String returnType,
    required List<ReturnLineInput> lines,
    required int refund,
    String? partyId,
    String? userId,
  }) async {
    if (lines.isEmpty) throw ArgumentError('Return must contain at least one item');
    if (refund < 0) throw ArgumentError('Refund cannot be negative');

    return db.transaction((txn) async {
      final deviceId = await DeviceService.ensureDeviceInTransaction(txn, businessId: businessId);
      final duplicate = await txn.query('returns', where: 'business_id = ? AND reference_no = ?', whereArgs: [businessId, referenceNo], limit: 1);
      if (duplicate.isNotEmpty) throw StateError('Duplicate return reference: $referenceNo');

      final originals = returnType == 'SALE_RETURN'
          ? await txn.query('sales', where: 'business_id = ? AND reference_no = ?', whereArgs: [businessId, originalReference], limit: 1)
          : await txn.query('purchases', where: 'business_id = ? AND reference_no = ?', whereArgs: [businessId, originalReference], limit: 1);
      if (originals.isEmpty) throw StateError('Original transaction not found');
      final original = originals.first;
      final originalId = original['id'] as String;

      if (partyId != null) {
        final expected = returnType == 'SALE_RETURN' ? original['customer_id'] : original['supplier_id'];
        if (expected != partyId) throw StateError('Party does not match original transaction');
      }

      // Normalize duplicate product lines before validating returnable quantity.
      // Without this aggregation, two lines for the same product could each pass
      // the historical-quantity check and together return more than was sold/purchased.
      final normalized = <String, ReturnLineInput>{};
      for (final line in lines) {
        if (line.quantity <= 0 || line.unitPrice < 0 || line.costPrice < 0) throw ArgumentError('Invalid return line');
        final existing = normalized[line.productId];
        if (existing == null) {
          normalized[line.productId] = line;
        } else {
          normalized[line.productId] = ReturnLineInput(
            productId: line.productId,
            quantity: existing.quantity + line.quantity,
            unitPrice: existing.unitPrice,
            costPrice: existing.costPrice,
          );
        }
      }

      var total = 0;
      final prepared = <Map<String, dynamic>>[];
      for (final line in normalized.values) {
        final itemRows = await txn.query(
          returnType == 'SALE_RETURN' ? 'sale_items' : 'purchase_items',
          where: '${returnType == 'SALE_RETURN' ? 'sale_id' : 'purchase_id'} = ? AND product_id = ?',
          whereArgs: [originalId, line.productId],
        );
        if (itemRows.isEmpty) throw StateError('Product was not part of original transaction');
        final item = itemRows.first;
        final soldQty = (item['quantity'] as int?) ?? 0;
        // Returns must use the original transaction price. A caller must not
        // be able to change the historical receivable/payable by submitting a
        // different unit price from the UI or a remote sync payload.
        final historicalUnitPrice = returnType == 'SALE_RETURN'
            ? ((item['unit_price'] as int?) ?? 0)
            : ((item['unit_cost'] as int?) ?? 0);
        final priorRows = await txn.rawQuery(
          'SELECT COALESCE(SUM(ri.quantity),0) AS qty FROM return_items ri JOIN returns r ON r.id = ri.return_id WHERE r.business_id = ? AND r.original_reference = ? AND r.return_type = ? AND ri.product_id = ?',
          [businessId, originalReference, returnType, line.productId],
        );
        final prior = (priorRows.first['qty'] as num).toInt();
        if (prior + line.quantity > soldQty) throw StateError('Return quantity exceeds returnable quantity');

        final lineTotal = line.quantity * historicalUnitPrice;
        total += lineTotal;
        prepared.add({'line': line, 'total': lineTotal, 'historicalUnitPrice': historicalUnitPrice});
      }
      if (refund > total) throw ArgumentError('Refund exceeds return total');

      // Cash refund cannot exceed the amount actually paid on the original
      // transaction, less cash refunds already issued for prior returns.
      // Otherwise a fully-credit sale/purchase could incorrectly create a
      // cash outflow/inflow even though no cash was originally exchanged.
      final originalPaid = (original['paid'] as num?)?.toInt() ?? 0;
      final priorRefundRows = await txn.rawQuery(
        'SELECT COALESCE(SUM(refund),0) AS amount FROM returns WHERE business_id = ? AND original_reference = ? AND return_type = ?',
        [businessId, originalReference, returnType],
      );
      final priorRefund = (priorRefundRows.first['amount'] as num?)?.toInt() ?? 0;
      final refundableCash = originalPaid > priorRefund ? originalPaid - priorRefund : 0;
      if (refund > refundableCash) {
        throw ArgumentError('Refund exceeds refundable cash paid on original transaction');
      }

      final now = DateTime.now().toIso8601String();
      final returnId = newId();
      await txn.insert('returns', {
        'id': returnId, 'business_id': businessId, 'reference_no': referenceNo,
        'return_type': returnType, 'original_reference': originalReference,
        'party_id': partyId, 'total': total, 'refund': refund, 'date': now, 'created_at': now,
      });

      for (final item in prepared) {
        final line = item['line'] as ReturnLineInput;
        final originalItemRows = await txn.query(
          returnType == 'SALE_RETURN' ? 'sale_items' : 'purchase_items',
          where: '${returnType == 'SALE_RETURN' ? 'sale_id' : 'purchase_id'} = ? AND product_id = ?',
          whereArgs: [originalId, line.productId], limit: 1,
        );
        final originalItem = originalItemRows.first;
        // Returns must use the historical transaction cost, not a caller-supplied
        // value. Purchase-item total already includes its allocated discount.
        final cost = returnType == 'SALE_RETURN'
            ? (originalItem['cost_price'] as int?) ?? line.costPrice
            : (originalItem['unit_cost'] as int?) ?? line.costPrice;

        final historicalUnitPrice = (item['historicalUnitPrice'] as int?) ?? line.unitPrice;
        final returnItemId = newId();
        await txn.insert('return_items', {
          'id': returnItemId, 'return_id': returnId, 'product_id': line.productId,
          'quantity': line.quantity, 'unit_price': historicalUnitPrice,
          'cost_price': cost, 'total': item['total'],
        });

        final productRows = await txn.query('products', where: 'id = ? AND business_id = ?', whereArgs: [line.productId, businessId], limit: 1);
        if (productRows.isEmpty) throw StateError('Product not found');
        final product = productRows.first;
        final oldQty = (product['stock_quantity'] as int?) ?? 0;
        if (returnType == 'SALE_RETURN') {
          final newQty = oldQty + line.quantity;
          await txn.rawUpdate('UPDATE products SET stock_quantity = ?, updated_at = ? WHERE id = ? AND business_id = ?', [newQty, now, line.productId, businessId]);
          await txn.insert('stock_movements', {'id': newId(), 'business_id': businessId, 'product_id': line.productId, 'movement_type': 'SALE_RETURN_IN', 'quantity': line.quantity, 'reference_type': 'RETURN', 'reference_id': returnId, 'unit_cost': cost, 'date': now, 'created_at': now});
        } else {
          if (oldQty < line.quantity) throw StateError('Insufficient stock for purchase return');
          final newQty = oldQty - line.quantity;
          // Remove the historical weighted cost of the returned purchase
          // quantity so stock valuation remains consistent after a purchase return.
          final oldAvg = (product['average_cost'] as int?) ?? 0;
          final returnedValue = line.quantity * cost;
          final remainingValue = (oldQty * oldAvg) - returnedValue;
          final newAvg = newQty == 0 ? 0 : (remainingValue < 0 ? 0 : remainingValue ~/ newQty);
          await txn.rawUpdate('UPDATE products SET stock_quantity = ?, average_cost = ?, cost_price = ?, updated_at = ? WHERE id = ? AND business_id = ?', [newQty, newAvg, newAvg, now, line.productId, businessId]);
          await txn.insert('stock_movements', {'id': newId(), 'business_id': businessId, 'product_id': line.productId, 'movement_type': 'PURCHASE_RETURN_OUT', 'quantity': line.quantity, 'reference_type': 'RETURN', 'reference_id': returnId, 'unit_cost': cost, 'date': now, 'created_at': now});
        }
      }

      // A return reverses the full original receivable/payable, regardless of
      // whether the refund is cash or remains as a credit against the party.
      // The cash refund is recorded separately below.
      if (partyId != null && total > 0) {
        if (returnType == 'SALE_RETURN') {
          // A sales return reduces the customer's receivable. If cash is
          // refunded, that cash refund is the opposite ledger direction so
          // the net customer-balance change is -(total - refund).
          await txn.insert('ledger_entries', {'id': newId(), 'business_id': businessId, 'party_type': 'CUSTOMER', 'party_id': partyId, 'entry_type': 'SALES_RETURN', 'debit': 0, 'credit': total, 'reference_type': 'RETURN', 'reference_id': returnId, 'date': now, 'created_at': now});
          if (refund > 0) {
            await txn.insert('ledger_entries', {'id': newId(), 'business_id': businessId, 'party_type': 'CUSTOMER', 'party_id': partyId, 'entry_type': 'SALES_RETURN_REFUND', 'debit': refund, 'credit': 0, 'reference_type': 'RETURN', 'reference_id': returnId, 'date': now, 'created_at': now});
          }
        } else {
          // A purchase return reduces the supplier payable. If the supplier
          // refunds cash, the cash receipt is the opposite ledger direction
          // so the net payable change is -(total - refund).
          await txn.insert('ledger_entries', {'id': newId(), 'business_id': businessId, 'party_type': 'SUPPLIER', 'party_id': partyId, 'entry_type': 'PURCHASE_RETURN', 'debit': total, 'credit': 0, 'reference_type': 'RETURN', 'reference_id': returnId, 'date': now, 'created_at': now});
          if (refund > 0) {
            await txn.insert('ledger_entries', {'id': newId(), 'business_id': businessId, 'party_type': 'SUPPLIER', 'party_id': partyId, 'entry_type': 'PURCHASE_RETURN_REFUND', 'debit': 0, 'credit': refund, 'reference_type': 'RETURN', 'reference_id': returnId, 'date': now, 'created_at': now});
          }
        }
      }
      if (refund > 0) {
        await txn.insert('cash_transactions', {'id': newId(), 'business_id': businessId, 'transaction_type': returnType == 'SALE_RETURN' ? 'SALES_RETURN_REFUND' : 'PURCHASE_RETURN_REFUND', 'amount': returnType == 'SALE_RETURN' ? -refund : refund, 'reference_type': 'RETURN', 'reference_id': returnId, 'note': null, 'date': now, 'created_at': now});
      }
      // Every return-related financial/stock row must have a durable sync envelope
      // in the same SQLite transaction. This prevents a successful local return
      // from disappearing on the second device after a crash/offline period.
      Future<void> enqueueRows(String table, List<Map<String, Object?>> rows) async {
        for (final row in rows) {
          final id = row['id']?.toString();
          if (id == null || id.isEmpty) throw StateError('Sync row has no id: $table');
          await SyncQueueService.enqueueInTransactionStatic(
            txn, businessId: businessId, recordId: id, tableName: table,
            operation: 'CREATE', deviceId: deviceId, version: 1,
            payload: Map<String, dynamic>.from(row),
          );
        }
      }
      await enqueueRows('returns', await txn.query('returns', where: 'id = ?', whereArgs: [returnId], limit: 1));
      await enqueueRows('return_items', await txn.query('return_items', where: 'return_id = ?', whereArgs: [returnId]));
      await enqueueRows('stock_movements', await txn.query('stock_movements', where: 'reference_type = ? AND reference_id = ?', whereArgs: ['RETURN', returnId]));
      await enqueueRows('ledger_entries', await txn.query('ledger_entries', where: 'reference_type = ? AND reference_id = ?', whereArgs: ['RETURN', returnId]));
      await enqueueRows('cash_transactions', await txn.query('cash_transactions', where: 'reference_type = ? AND reference_id = ?', whereArgs: ['RETURN', returnId]));

      await txn.insert('audit_logs', {'id': newId(), 'business_id': businessId, 'user_id': userId, 'action': 'RETURN', 'module': 'RETURNS', 'record_id': returnId, 'result': 'SUCCESS', 'details': referenceNo, 'created_at': now});
      return ReturnResult(returnId: returnId, referenceNo: referenceNo, total: total, refund: refund);
    });
  }
}
