import 'package:sqflite/sqflite.dart';
import '../../core/utils/ids.dart';
import '../../core/sync/device_service.dart';
import '../../core/sync/sync_queue_service.dart';
import '../models/payment_models.dart';

class PaymentService {
  final Database db;
  const PaymentService(this.db);

  Future<PaymentResult> receiveOrPay({
    required String businessId,
    required String referenceNo,
    required String partyType,
    required String partyId,
    required int amount,
    required String paymentType,
    String? note,
    String? userId,
  }) async {
    if (amount <= 0) throw ArgumentError('Amount must be positive');
    final normalized = partyType.toUpperCase();
    if (normalized != 'CUSTOMER' && normalized != 'SUPPLIER') throw ArgumentError('Invalid party type');
    return db.transaction((txn) async {
      final deviceId = await DeviceService.ensureDeviceInTransaction(txn, businessId: businessId);
      final duplicate = await txn.query('payments', where: 'business_id = ? AND reference_no = ?', whereArgs: [businessId, referenceNo], limit: 1);
      if (duplicate.isNotEmpty) throw StateError('Duplicate payment reference: $referenceNo');
      final table = normalized == 'CUSTOMER' ? 'customers' : 'suppliers';
      final party = await txn.query(table, where: 'id = ? AND business_id = ? AND deleted_at IS NULL', whereArgs: [partyId, businessId], limit: 1);
      if (party.isEmpty) throw StateError('$normalized not found');

      final now = DateTime.now().toIso8601String();
      final paymentId = newId();
      final entries = await txn.rawQuery(
        'SELECT COALESCE(SUM(debit),0) AS debit, COALESCE(SUM(credit),0) AS credit FROM ledger_entries WHERE business_id = ? AND party_type = ? AND party_id = ?',
        [businessId, normalized, partyId],
      );
      final row = entries.first;
      final debit = (row['debit'] as num).toInt();
      final credit = (row['credit'] as num).toInt();
      final opening = (party.first['opening_balance'] as num?)?.toInt() ?? 0;
      final currentBalance = normalized == 'CUSTOMER' ? opening + debit - credit : opening + credit - debit;
      if (currentBalance <= 0) throw StateError('No outstanding balance for $normalized');
      if (amount > currentBalance) throw StateError('Payment exceeds outstanding balance');
      final resulting = currentBalance - amount;

      await txn.insert('payments', {
        'id': paymentId, 'business_id': businessId, 'reference_no': referenceNo, 'party_type': normalized,
        'party_id': partyId, 'amount': amount, 'payment_type': paymentType, 'note': note, 'date': now, 'created_at': now,
      });
      await txn.insert('ledger_entries', {
        'id': newId(), 'business_id': businessId, 'party_type': normalized, 'party_id': partyId,
        'entry_type': 'PAYMENT',
        'debit': normalized == 'SUPPLIER' ? amount : 0,
        'credit': normalized == 'CUSTOMER' ? amount : 0,
        'reference_type': 'PAYMENT', 'reference_id': paymentId, 'note': note, 'date': now, 'created_at': now,
      });
      await txn.insert('cash_transactions', {
        'id': newId(), 'business_id': businessId,
        'transaction_type': normalized == 'CUSTOMER' ? 'CUSTOMER_PAYMENT' : 'SUPPLIER_PAYMENT',
        'amount': amount * (normalized == 'CUSTOMER' ? 1 : -1),
        'reference_type': 'PAYMENT', 'reference_id': paymentId, 'note': note, 'date': now, 'created_at': now,
      });

      await SyncQueueService.enqueueInTransactionStatic(txn, businessId: businessId, recordId: paymentId, tableName: 'payments', operation: 'CREATE', deviceId: deviceId, version: 1, payload: {
        'id': paymentId, 'business_id': businessId, 'reference_no': referenceNo, 'party_type': normalized, 'party_id': partyId, 'amount': amount, 'payment_type': paymentType, 'note': note, 'date': now, 'created_at': now,
      });
      final ledgerRows = await txn.query('ledger_entries', where: 'reference_id = ? AND reference_type = ?', whereArgs: [paymentId, 'PAYMENT']);
      final ledger = ledgerRows.last;
      await SyncQueueService.enqueueInTransactionStatic(txn, businessId: businessId, recordId: ledger['id'] as String, tableName: 'ledger_entries', operation: 'CREATE', deviceId: deviceId, version: 1, payload: ledger.cast<String, dynamic>());
      final cashRows = await txn.query('cash_transactions', where: 'reference_id = ? AND reference_type = ?', whereArgs: [paymentId, 'PAYMENT']);
      final cash = cashRows.last;
      await SyncQueueService.enqueueInTransactionStatic(txn, businessId: businessId, recordId: cash['id'] as String, tableName: 'cash_transactions', operation: 'CREATE', deviceId: deviceId, version: 1, payload: cash.cast<String, dynamic>());

      await txn.insert('audit_logs', {
        'id': newId(), 'business_id': businessId, 'user_id': userId, 'action': 'PAYMENT', 'module': 'PAYMENTS',
        'record_id': paymentId, 'result': 'SUCCESS', 'details': referenceNo, 'created_at': now,
      });
      return PaymentResult(paymentId: paymentId, referenceNo: referenceNo, amount: amount, resultingBalance: resulting);
    });
  }
}
