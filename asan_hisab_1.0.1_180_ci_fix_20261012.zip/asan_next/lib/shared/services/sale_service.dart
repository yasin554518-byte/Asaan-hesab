import 'package:sqflite/sqflite.dart';
import '../../core/utils/ids.dart';
import '../../core/utils/money.dart';
import '../../shared/models/sale_models.dart';

class SaleService {
  final Database db;
  const SaleService(this.db);

  Future<SaleResult> createSale({
    required String businessId,
    required String referenceNo,
    String? customerId,
    required List<SaleLineInput> lines,
    required int paid,
    required String paymentType,
    String? userId,
  }) async {
    if (lines.isEmpty) throw ArgumentError('Sale must contain at least one item');
    if (paid < 0) throw ArgumentError('Paid cannot be negative');

    return db.transaction((txn) async {
      final duplicate = await txn.query('sales', where: 'business_id = ? AND reference_no = ?', whereArgs: [businessId, referenceNo], limit: 1);
      if (duplicate.isNotEmpty) throw StateError('Duplicate sale reference: $referenceNo');
      if (customerId != null) {
        final customer = await txn.query('customers', where: 'id = ? AND business_id = ? AND deleted_at IS NULL', whereArgs: [customerId, businessId], limit: 1);
        if (customer.isEmpty) throw StateError('Customer not found');
      }

      var subtotal = 0;
      var discount = 0;
      var cogs = 0;
      final prepared = <Map<String, dynamic>>[];

      // Consolidate duplicate product lines before checking stock. Otherwise
      // two lines for the same product could each pass against the same
      // starting stock and together make stock negative.
      final normalized = <String, SaleLineInput>{};
      for (final line in lines) {
        if (line.quantity <= 0 || line.unitPrice < 0 || line.discount < 0) {
          throw ArgumentError('Invalid sale line');
        }
        final existing = normalized[line.productId];
        if (existing == null) {
          normalized[line.productId] = line;
        } else {
          if (existing.unitPrice != line.unitPrice) {
            throw ArgumentError('Duplicate product lines must use the same unit price');
          }
          normalized[line.productId] = SaleLineInput(
            productId: line.productId,
            quantity: existing.quantity + line.quantity,
            unitPrice: existing.unitPrice,
            discount: existing.discount + line.discount,
          );
        }
      }

      for (final line in normalized.values) {
        if (line.quantity <= 0 || line.unitPrice < 0 || line.discount < 0) throw ArgumentError('Invalid sale line');
        final lineGross = line.quantity * line.unitPrice;
        if (line.discount > lineGross) throw ArgumentError('Line discount exceeds line total');
        final rows = await txn.query('products', where: 'id = ? AND business_id = ? AND deleted_at IS NULL', whereArgs: [line.productId, businessId], limit: 1);
        if (rows.isEmpty) throw StateError('Product not found: ${line.productId}');
        final product = rows.first;
        final stock = (product['stock_quantity'] as int?) ?? 0;
        if (stock < line.quantity) throw StateError('Insufficient stock for ${product['name']}');
        final cost = (product['average_cost'] as int?) ?? 0;
        final lineTotal = lineGross - line.discount;
        subtotal += lineGross;
        discount += line.discount;
        cogs += line.quantity * cost;
        prepared.add({'line': line, 'cost': cost, 'total': lineTotal});
      }

      final total = Money.afterDiscount(subtotal: subtotal, discount: discount);
      final remaining = Money.remaining(total: total, paid: paid);
      final now = DateTime.now().toIso8601String();
      final saleId = newId();

      await txn.insert('sales', {
        'id': saleId, 'business_id': businessId, 'reference_no': referenceNo, 'customer_id': customerId,
        'subtotal': subtotal, 'discount': discount, 'total': total, 'paid': paid, 'remaining': remaining,
        'payment_type': paymentType, 'date': now, 'created_at': now,
      });

      for (final item in prepared) {
        final line = item['line'] as SaleLineInput;
        final cost = item['cost'] as int;
        await txn.insert('sale_items', {
          'id': newId(), 'sale_id': saleId, 'product_id': line.productId, 'quantity': line.quantity,
          'unit_price': line.unitPrice, 'cost_price': cost, 'discount': line.discount, 'total': item['total'],
        });
        await txn.rawUpdate('UPDATE products SET stock_quantity = stock_quantity - ?, updated_at = ? WHERE id = ? AND business_id = ?', [line.quantity, now, line.productId, businessId]);
        await txn.insert('stock_movements', {
          'id': newId(), 'business_id': businessId, 'product_id': line.productId, 'movement_type': 'SALE_OUT',
          'quantity': line.quantity, 'reference_type': 'SALE', 'reference_id': saleId, 'unit_cost': cost, 'date': now, 'created_at': now,
        });
      }

      if (customerId != null) {
        await txn.insert('ledger_entries', {
          'id': newId(), 'business_id': businessId, 'party_type': 'CUSTOMER', 'party_id': customerId,
          'entry_type': 'SALE', 'debit': total, 'credit': 0, 'reference_type': 'SALE', 'reference_id': saleId, 'date': now, 'created_at': now,
        });
        if (paid > 0) {
          await txn.insert('ledger_entries', {
            'id': newId(), 'business_id': businessId, 'party_type': 'CUSTOMER', 'party_id': customerId,
            'entry_type': 'SALE_PAYMENT', 'debit': 0, 'credit': paid, 'reference_type': 'SALE', 'reference_id': saleId, 'date': now, 'created_at': now,
          });
        }
      }
      if (paid > 0) {
        await txn.insert('cash_transactions', {
          'id': newId(), 'business_id': businessId, 'transaction_type': 'SALE', 'amount': paid,
          'reference_type': 'SALE', 'reference_id': saleId, 'note': null, 'date': now, 'created_at': now,
        });
      }
      await txn.insert('audit_logs', {
        'id': newId(), 'business_id': businessId, 'user_id': userId, 'action': 'CREATE', 'module': 'SALES',
        'record_id': saleId, 'result': 'SUCCESS', 'details': referenceNo, 'created_at': now,
      });
      return SaleResult(saleId: saleId, referenceNo: referenceNo, total: total, paid: paid, remaining: remaining, cogs: cogs);
    });
  }
}
