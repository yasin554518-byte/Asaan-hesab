import 'package:sqflite/sqflite.dart';
import '../../core/utils/ids.dart';
import '../../core/utils/money.dart';
import '../models/purchase_models.dart';

class PurchaseService {
  final Database db;
  const PurchaseService(this.db);

  Future<PurchaseResult> createPurchase({
    required String businessId,
    required String referenceNo,
    String? supplierId,
    required List<PurchaseLineInput> lines,
    required int discount,
    required int paid,
    required String paymentType,
    String? userId,
  }) async {
    if (lines.isEmpty) throw ArgumentError('Purchase must contain at least one item');
    if (discount < 0 || paid < 0) throw ArgumentError('Invalid discount/payment');
    return db.transaction((txn) async {
      final duplicate = await txn.query('purchases', where: 'business_id = ? AND reference_no = ?', whereArgs: [businessId, referenceNo], limit: 1);
      if (duplicate.isNotEmpty) throw StateError('Duplicate purchase reference: $referenceNo');
      if (supplierId != null) {
        final supplier = await txn.query('suppliers', where: 'id = ? AND business_id = ? AND deleted_at IS NULL', whereArgs: [supplierId, businessId], limit: 1);
        if (supplier.isEmpty) throw StateError('Supplier not found');
      }

      var subtotal = 0;
      final normalized = <String, PurchaseLineInput>{};
      for (final line in lines) {
        if (line.quantity <= 0 || line.unitCost < 0) throw ArgumentError('Invalid purchase line');
        final existing = normalized[line.productId];
        if (existing == null) {
          normalized[line.productId] = line;
        } else {
          if (existing.unitCost != line.unitCost) {
            throw ArgumentError('Duplicate product lines must use the same unit cost');
          }
          normalized[line.productId] = PurchaseLineInput(
            productId: line.productId,
            quantity: existing.quantity + line.quantity,
            unitCost: existing.unitCost,
          );
        }
      }
      final prepared = <Map<String, dynamic>>[];
      for (final line in normalized.values) {
        final rows = await txn.query('products', where: 'id = ? AND business_id = ? AND deleted_at IS NULL', whereArgs: [line.productId, businessId], limit: 1);
        if (rows.isEmpty) throw StateError('Product not found: ${line.productId}');
        final gross = line.quantity * line.unitCost;
        subtotal += gross;
        prepared.add({'line': line, 'gross': gross});
      }
      final total = Money.afterDiscount(subtotal: subtotal, discount: discount);
      final remaining = Money.remaining(total: total, paid: paid);
      final now = DateTime.now().toIso8601String();
      final purchaseId = newId();

      await txn.insert('purchases', {
        'id': purchaseId, 'business_id': businessId, 'reference_no': referenceNo, 'supplier_id': supplierId,
        'subtotal': subtotal, 'discount': discount, 'total': total, 'paid': paid, 'remaining': remaining,
        'payment_type': paymentType, 'date': now, 'created_at': now,
      });

      var allocatedDiscountTotal = 0;
      for (var i = 0; i < prepared.length; i++) {
        final item = prepared[i];
        final line = item['line'] as PurchaseLineInput;
        final gross = item['gross'] as int;
        // Allocate the full integer discount without losing remainder cents
        // (minor units). The final line receives the remaining units.
        final allocatedDiscount = subtotal == 0
            ? 0
            : (i == prepared.length - 1
                ? discount - allocatedDiscountTotal
                : (discount * gross) ~/ subtotal);
        allocatedDiscountTotal += allocatedDiscount;
        final effectiveCostTotal = gross - allocatedDiscount;
        final rows = await txn.query('products', where: 'id = ? AND business_id = ?', whereArgs: [line.productId, businessId], limit: 1);
        final product = rows.single;
        final oldQty = (product['stock_quantity'] as int?) ?? 0;
        final oldAvg = (product['average_cost'] as int?) ?? 0;
        final newQty = oldQty + line.quantity;
        final newAvg = newQty == 0 ? 0 : ((oldQty * oldAvg) + effectiveCostTotal) ~/ newQty;

        await txn.insert('purchase_items', {
          'id': newId(), 'purchase_id': purchaseId, 'product_id': line.productId,
          'quantity': line.quantity, 'unit_cost': line.unitCost, 'total': effectiveCostTotal,
        });
        await txn.rawUpdate('UPDATE products SET stock_quantity = ?, average_cost = ?, cost_price = ?, updated_at = ? WHERE id = ? AND business_id = ?',
            [newQty, newAvg, newAvg, now, line.productId, businessId]);
        final effectiveUnitCost = line.quantity == 0 ? 0 : effectiveCostTotal ~/ line.quantity;
        await txn.insert('stock_movements', {
          'id': newId(), 'business_id': businessId, 'product_id': line.productId, 'movement_type': 'PURCHASE_IN',
          'quantity': line.quantity, 'reference_type': 'PURCHASE', 'reference_id': purchaseId, 'unit_cost': effectiveUnitCost, 'date': now, 'created_at': now,
        });
      }

      if (supplierId != null) {
        await txn.insert('ledger_entries', {
          'id': newId(), 'business_id': businessId, 'party_type': 'SUPPLIER', 'party_id': supplierId,
          'entry_type': 'PURCHASE', 'debit': 0, 'credit': total, 'reference_type': 'PURCHASE', 'reference_id': purchaseId, 'date': now, 'created_at': now,
        });
        if (paid > 0) {
          await txn.insert('ledger_entries', {
            'id': newId(), 'business_id': businessId, 'party_type': 'SUPPLIER', 'party_id': supplierId,
            'entry_type': 'PURCHASE_PAYMENT', 'debit': paid, 'credit': 0, 'reference_type': 'PURCHASE', 'reference_id': purchaseId, 'date': now, 'created_at': now,
          });
        }
      }
      if (paid > 0) {
        await txn.insert('cash_transactions', {
          'id': newId(), 'business_id': businessId, 'transaction_type': 'PURCHASE', 'amount': paid,
          'reference_type': 'PURCHASE', 'reference_id': purchaseId, 'note': null, 'date': now, 'created_at': now,
        });
      }
      await txn.insert('audit_logs', {
        'id': newId(), 'business_id': businessId, 'user_id': userId, 'action': 'CREATE', 'module': 'PURCHASES',
        'record_id': purchaseId, 'result': 'SUCCESS', 'details': referenceNo, 'created_at': now,
      });
      return PurchaseResult(purchaseId: purchaseId, referenceNo: referenceNo, total: total, paid: paid, remaining: remaining);
    });
  }
}
