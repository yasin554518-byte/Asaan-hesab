class PaymentResult {
  final String paymentId;
  final String referenceNo;
  final int amount;
  final int resultingBalance;
  const PaymentResult({required this.paymentId, required this.referenceNo, required this.amount, required this.resultingBalance});
}
