class SaleLineInput {
  final String productId;
  final int quantity;
  final int unitPrice;
  final int discount;
  const SaleLineInput({required this.productId, required this.quantity, required this.unitPrice, this.discount = 0});
}

class SaleResult {
  final String saleId;
  final String referenceNo;
  final int total;
  final int paid;
  final int remaining;
  final int cogs;
  const SaleResult({required this.saleId, required this.referenceNo, required this.total, required this.paid, required this.remaining, required this.cogs});
}
