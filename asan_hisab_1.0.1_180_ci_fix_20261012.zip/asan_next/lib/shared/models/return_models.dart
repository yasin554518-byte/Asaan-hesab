class ReturnLineInput {
  final String productId;
  final int quantity;
  final int unitPrice;
  final int costPrice;
  const ReturnLineInput({required this.productId, required this.quantity, required this.unitPrice, required this.costPrice});
}

class ReturnResult {
  final String returnId;
  final String referenceNo;
  final int total;
  final int refund;
  const ReturnResult({required this.returnId, required this.referenceNo, required this.total, required this.refund});
}
