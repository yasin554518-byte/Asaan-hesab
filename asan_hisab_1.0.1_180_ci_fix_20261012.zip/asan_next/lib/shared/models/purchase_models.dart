class PurchaseLineInput {
  final String productId;
  final int quantity;
  final int unitCost;
  const PurchaseLineInput({required this.productId, required this.quantity, required this.unitCost});
}

class PurchaseResult {
  final String purchaseId;
  final String referenceNo;
  final int total;
  final int paid;
  final int remaining;
  const PurchaseResult({required this.purchaseId, required this.referenceNo, required this.total, required this.paid, required this.remaining});
}
