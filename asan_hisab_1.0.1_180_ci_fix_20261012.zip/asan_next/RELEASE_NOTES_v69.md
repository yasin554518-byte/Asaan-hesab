# Asan Hisab v69

## CI Workflow Structure Integrity Gate

- Version: 1.0.1+56
- Removed duplicated `with:` / `persist-credentials` mappings from all checkout steps.
- Added a CI workflow structure contract that detects duplicate checkout-step keys and duplicate security-gate invocations.
- Existing release, provenance, sync, backup/restore, signing, and production security gates remain enabled.
