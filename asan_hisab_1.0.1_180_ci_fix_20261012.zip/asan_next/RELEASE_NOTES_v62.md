# Release Notes v62 — CI Secret Handling Gate

- Version: 1.0.1+48.
- Added a CI contract that rejects shell tracing (`set -x`) in the release workflow.
- Added checks preventing direct GitHub secret interpolation into workflow `run` commands.
- Added checks preventing release/production secret variables from being printed.
- Required release and production secrets remain injected through workflow `env` blocks.
- No production credentials or signing material are stored in source.
