# Release Notes v61 — CI Least-Privilege Permissions Gate

- Version: 1.0.1+47.
- GitHub Actions now declares a top-level `contents: read` permission.
- A contract test rejects unsafe top-level `contents`, `actions`, or `packages` write permissions.
- The gate runs with the existing source/security/release contract suite.
- No production credential or signing material is added.
