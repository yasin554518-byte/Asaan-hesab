# Asan Hisab v1.0.1+180 — Final Release Gates

Completed locally:
- Source smoke checks
- Release static invariants
- Android application-id gate (`com.asanhisab.app`)
- Release candidate checks
- Python compile
- Backend contract tests
- Release archive hygiene (no `__pycache__`, no private signing keys)

Still requiring an external/real environment:
- Flutter SDK: `flutter pub get`, `dart analyze`, `flutter test`
- Release AAB build and signing
- Production HTTPS deployment and certificate validation
- Two physical Android devices with live sync
- Real-device RTL, PDF/printing, storage and notification QA
- Production backup/restore drill
- Play Console upload and store listing review

No production credentials or private signing keys belong in this source package.

Additional hardening in v1.0.1+17:
- Sync auth token moved out of SQLite into OS secure storage (`flutter_secure_storage`).
- Sync HTTP requests have a 20-second timeout.
- Pashto/Arabic Noto Naskh Arabic font is declared and applied as the app theme font.
- CI Flutter version updated to 3.41.0.

- Backend configured-token bootstrap now preserves revoked-token state; regression test added.

- Tagged-release production HTTPS smoke gate added; it requires CI-only deployment secrets and validates health/authenticated pull against the real endpoint.


Additional hardening in v58:
- Production environment files are required to be owner-only at deployment preflight; group/other-readable secret files are rejected.


Additional hardening in v58:
- Production container security profile uses a read-only root filesystem, drops all capabilities, and does not publish the API port directly.

Additional hardening in v62:
- GitHub Actions workflow declares only top-level `contents: read` and includes a contract gate rejecting unsafe top-level write permissions.
