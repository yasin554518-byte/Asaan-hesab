# Asan Hisab v115

Version: 1.0.1+102

## Sync reliability
- Manual retry now immediately re-queues failed sync operations as `pending`.
- Manual retry resets `retry_count` and `last_attempt_at`, preventing an old automatic backoff window from delaying an explicit user retry.
- Added `tool/sync_manual_retry_contract_test.sh` regression coverage.

## Verification
- Sync manual-retry contract: PASS
- Existing sync scheduler/push-failure contract gates: to be run by final preflight
- Android AAB: SKIP when Flutter/Android SDK is unavailable
- Production deployment: SKIP when production secrets/environment are unavailable
