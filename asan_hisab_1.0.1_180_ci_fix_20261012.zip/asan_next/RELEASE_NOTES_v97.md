# Asan Hisab v97

- Version: 1.0.1+83
- Tightened release provenance identity validation: release refs must be exact semantic version tag refs.
- Release tag must exactly match `v` + `app_version`.
- Added regression contract covering valid identity and mismatched release tag/version rejection.
