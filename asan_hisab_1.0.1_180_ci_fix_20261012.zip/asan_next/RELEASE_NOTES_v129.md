# Asan Hisab v129

Version: 1.0.1+115

- Fixed the SyncScheduler Flutter test structure so lifecycle pause/resume regression tests execute inside the test suite.
- Preserved the v128 race-safe/idempotent sync queue behavior.
- Added deterministic pause/resume timer coverage without changing production sync behavior.
