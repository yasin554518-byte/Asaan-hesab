# Asan Hisab v109

Version 1.0.1+95.

## Release hardening
- Release bundle manifest now verifies that `artifact_size_bytes` exactly matches the current release AAB size.
- Added regression contract coverage for the artifact-size/AAB consistency gate.
