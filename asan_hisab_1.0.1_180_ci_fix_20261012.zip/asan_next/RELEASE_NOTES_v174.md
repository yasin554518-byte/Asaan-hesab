# v175 — 1.0.1+159

- Release candidate gate now executes Python purchase/lifecycle and sale/purchase validation contracts explicitly.
- Prevents Python regression tests from being silently skipped by shell-only release runners.
- Version advanced to 1.0.1+159.
