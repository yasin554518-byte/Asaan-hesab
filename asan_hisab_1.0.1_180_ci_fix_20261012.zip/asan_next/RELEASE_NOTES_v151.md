# Asan Hisab v151 — 1.0.1+137

- Added a StatementService openingBalanceAt contract for date-filtered statements.
- The period opening balance is computed from ledger entries strictly before the selected start date using the centralized LedgerBalance rules.
- Added a regression contract for the period-opening calculation.
