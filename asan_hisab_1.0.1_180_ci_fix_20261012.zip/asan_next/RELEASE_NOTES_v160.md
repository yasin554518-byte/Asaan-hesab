# Asan Hisab v160 — 1.0.1+147

## Change
- Clarified the Statement PDF opening-balance label: filtered date-range statements now show `د فلټر د پیل بیلانس`, while the unfiltered full account keeps `د پیل بیلانس`.

## Validation
- Added `test/statement_pdf_period_opening_label_contract_test.dart`.
- Existing release, sync, backup, checksum, manifest, and statement contracts were re-run.
