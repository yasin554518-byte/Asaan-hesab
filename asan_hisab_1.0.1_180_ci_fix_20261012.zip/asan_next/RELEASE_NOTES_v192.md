# Asan Hisab v192

Version: 1.0.1+175

## Change
Business Settings async load now checks `mounted` immediately after the database query and before writing loaded values into text controllers. This prevents post-dispose controller updates when the page closes while loading.

## Validation
Added `test/business_settings_load_lifecycle_contract_test.py`.
