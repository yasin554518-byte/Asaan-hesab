# Asan Hisab Sync Backend

This server implements the REST contract already used by the Flutter app:

- `POST /v1/sync/push`
- `GET /v1/sync/pull?businessId=...&deviceId=...&cursor=...`
- `GET /health`

## Authentication

Use an HTTPS reverse proxy in production. Tokens are supplied through
`ASAN_SYNC_TOKENS` as JSON and only their SHA-256 hashes are stored locally.
Example:

```json
[{"token":"REPLACE_WITH_RANDOM_TOKEN","businessId":"BUSINESS_ID","deviceId":"DEVICE_ID"}]
```

The token is bound to exactly one business and device. A push is rejected if
the business or device does not match the authenticated token.

## Data guarantees

- `operationId` is idempotent.
- Cross-business access is rejected.
- Financial records cannot be updated/deleted through sync.
- A second operation against the same financial record is treated as a conflict.
- Master-data versions must increase for UPDATE/DELETE.
- Pull uses a monotonic server sequence cursor.
- SQLite WAL is enabled for the included single-node deployment.

For production at scale, place the API behind TLS and migrate the operation
store to PostgreSQL; keep the same HTTP contract.
