import hashlib
import json
import os
import sqlite3
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

DB_PATH = os.getenv('ASAN_SYNC_DB', '/data/asan_sync.sqlite3')
MAX_BODY = 2 * 1024 * 1024
MAX_OPERATIONS = 500
MAX_OPERATION_PAYLOAD = 256 * 1024
MAX_IDENTIFIER_LENGTH = 128
SAFE_TABLES = {
    'businesses','products','customers','suppliers','sales','sale_items',
    'purchases','purchase_items','payments','expenses','stock_movements',
    'ledger_entries','returns','return_items','cash_transactions'
}
FINANCIAL_TABLES = {
    'sales','sale_items','purchases','purchase_items','payments','expenses',
    'stock_movements','ledger_entries','returns','return_items','cash_transactions'
}
MASTER_TABLES = {'products','customers','suppliers'}


def db():
    os.makedirs(os.path.dirname(DB_PATH) or '.', exist_ok=True)
    c = sqlite3.connect(DB_PATH, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA foreign_keys=ON')
    c.executescript('''
    CREATE TABLE IF NOT EXISTS auth_devices (
      token_hash TEXT PRIMARY KEY,
      business_id TEXT NOT NULL,
      device_id TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS operations (
      seq INTEGER PRIMARY KEY AUTOINCREMENT,
      operation_id TEXT NOT NULL UNIQUE,
      business_id TEXT NOT NULL,
      record_id TEXT NOT NULL,
      table_name TEXT NOT NULL,
      operation TEXT NOT NULL,
      device_id TEXT NOT NULL,
      version INTEGER NOT NULL,
      payload_json TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(business_id, record_id, table_name, version, operation_id)
    );
    CREATE INDEX IF NOT EXISTS ix_ops_business_seq ON operations(business_id, seq);
    CREATE INDEX IF NOT EXISTS ix_ops_record ON operations(business_id, table_name, record_id, version);
    ''')
    return c


def bootstrap_tokens(c):
    raw = os.getenv('ASAN_SYNC_TOKENS', '')
    if not raw:
        return
    # JSON array: [{"token":"...","businessId":"...","deviceId":"..."}]
    try:
        items = json.loads(raw)
        for item in items:
            token = str(item['token']).strip()
            business = str(item['businessId']).strip()
            device = str(item['deviceId']).strip()
            if len(token) < 32:
                raise ValueError('sync tokens must be at least 32 characters')
            if not business or not device:
                raise ValueError('token businessId/deviceId must be non-empty')
            # Bootstrap only new tokens. Replacing an existing row on every request
            # would silently reactivate tokens that an operator had revoked.
            c.execute('INSERT OR IGNORE INTO auth_devices(token_hash,business_id,device_id,active) VALUES(?,?,?,1)',
                      (hash_token(token), business, device))
        c.commit()
    except Exception as exc:
        raise RuntimeError('Invalid ASAN_SYNC_TOKENS JSON') from exc


def hash_token(token):
    return hashlib.sha256(token.encode('utf-8')).hexdigest()


def json_response(h, status, obj):
    body = json.dumps(obj, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    h.send_response(status)
    h.send_header('Content-Type', 'application/json; charset=utf-8')
    h.send_header('Content-Length', str(len(body)))
    h.send_header('Cache-Control', 'no-store')
    h.send_header('X-Content-Type-Options', 'nosniff')
    h.send_header('X-Frame-Options', 'DENY')
    h.send_header('Referrer-Policy', 'no-referrer')
    h.send_header('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'; base-uri 'none'")
    h.send_header('Permissions-Policy', 'camera=(), microphone=(), geolocation=()')
    h.send_header('Cross-Origin-Resource-Policy', 'same-origin')
    h.send_header('X-Download-Options', 'noopen')
    # The API is normally behind the TLS reverse proxy. Emit HSTS only when
    # the proxy explicitly confirms the external request used HTTPS.
    if h.headers.get('X-Forwarded-Proto', '').strip().lower() == 'https':
        h.send_header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
    h.end_headers()
    h.wfile.write(body)


def read_json(h):
    try:
        n = int(h.headers.get('Content-Length', '0'))
    except ValueError:
        raise ValueError('invalid content length')
    if n <= 0 or n > MAX_BODY:
        raise ValueError('invalid request size')
    return json.loads(h.rfile.read(n).decode('utf-8'))


def validate_envelope(e):
    required = ['operationId','recordId','tableName','operation','deviceId','version','payload']
    if any(k not in e for k in required):
        raise ValueError('missing envelope field')
    if not all(isinstance(e[k], str) and e[k].strip() for k in ['operationId','recordId','tableName','operation','deviceId']):
        raise ValueError('invalid envelope identifiers')
    if any(len(e[k]) > MAX_IDENTIFIER_LENGTH for k in ['operationId','recordId','tableName','operation','deviceId']):
        raise ValueError('envelope identifier too long')
    if e['tableName'] not in SAFE_TABLES:
        raise ValueError('table not allowed')
    if e['operation'].upper() not in {'CREATE','UPDATE','DELETE'}:
        raise ValueError('operation not allowed')
    if not isinstance(e['version'], int) or e['version'] < 0:
        raise ValueError('invalid version')
    if not isinstance(e['payload'], dict):
        raise ValueError('payload must be an object')
    payload_json = json.dumps(e['payload'], ensure_ascii=False, separators=(',', ':'))
    if len(payload_json.encode('utf-8')) > MAX_OPERATION_PAYLOAD:
        raise ValueError('operation payload too large')
    if str(e['payload'].get('id', e['recordId'])) != e['recordId']:
        raise ValueError('record id mismatch')
    return e


class Handler(BaseHTTPRequestHandler):
    server_version = 'AsanHisabSync/1.0'

    def log_message(self, fmt, *args):
        print('%s - %s' % (self.address_string(), fmt % args))

    def auth(self, c):
        header = self.headers.get('Authorization', '')
        if not header.startswith('Bearer '):
            return None
        token = header[7:].strip()
        if not token:
            return None
        return c.execute('SELECT business_id,device_id FROM auth_devices WHERE token_hash=? AND active=1',
                         (hash_token(token),)).fetchone()

    def do_GET(self):
        c = db()
        try:
            bootstrap_tokens(c)
            path = urlparse(self.path)
            if path.path == '/health':
                json_response(self, HTTPStatus.OK, {'ok': True, 'service': 'asan-hisab-sync'})
                return
            if path.path != '/v1/sync/pull':
                json_response(self, HTTPStatus.NOT_FOUND, {'error':'not_found'}); return
            auth = self.auth(c)
            if not auth:
                json_response(self, HTTPStatus.UNAUTHORIZED, {'error':'unauthorized'}); return
            q = parse_qs(path.query)
            business = q.get('businessId', [''])[0]
            device = q.get('deviceId', [''])[0]
            cursor_s = q.get('cursor', ['0'])[0]
            try: cursor = max(0, int(cursor_s or '0'))
            except ValueError:
                json_response(self, HTTPStatus.BAD_REQUEST, {'error':'invalid_cursor'}); return
            if business != auth['business_id'] or device != auth['device_id']:
                json_response(self, HTTPStatus.FORBIDDEN, {'error':'business_or_device_mismatch'}); return
            rows = c.execute('''SELECT seq,operation_id,record_id,table_name,operation,device_id,version,payload_json
                                FROM operations WHERE business_id=? AND seq>? ORDER BY seq ASC LIMIT 500''',
                             (business, cursor)).fetchall()
            ops = []
            next_cursor = cursor
            for r in rows:
                next_cursor = r['seq']
                ops.append({
                    'operationId':r['operation_id'],'recordId':r['record_id'],
                    'tableName':r['table_name'],'operation':r['operation'],
                    'deviceId':r['device_id'],'version':r['version'],
                    'payload':json.loads(r['payload_json'])
                })
            json_response(self, HTTPStatus.OK, {'operations':ops,'nextCursor':str(next_cursor)})
        finally:
            c.close()

    def do_POST(self):
        c = db()
        try:
            bootstrap_tokens(c)
            if urlparse(self.path).path != '/v1/sync/push':
                json_response(self, HTTPStatus.NOT_FOUND, {'error':'not_found'}); return
            auth = self.auth(c)
            if not auth:
                json_response(self, HTTPStatus.UNAUTHORIZED, {'error':'unauthorized'}); return
            content_type = self.headers.get('Content-Type', '').split(';', 1)[0].strip().lower()
            if content_type != 'application/json':
                json_response(self, HTTPStatus.UNSUPPORTED_MEDIA_TYPE, {'error':'content_type_must_be_application_json'}); return
            try: body = read_json(self)
            except Exception as exc:
                json_response(self, HTTPStatus.BAD_REQUEST, {'error':str(exc)}); return
            business = str(body.get('businessId',''))
            operations = body.get('operations')
            if business != auth['business_id'] or not isinstance(operations, list) or len(operations) > MAX_OPERATIONS:
                json_response(self, HTTPStatus.BAD_REQUEST, {'error':'invalid_request'}); return
            synced, conflicts = [], []
            try:
                c.execute('BEGIN IMMEDIATE')
                for raw in operations:
                    try: e = validate_envelope(raw)
                    except Exception:
                        if isinstance(raw, dict) and raw.get('operationId'): conflicts.append(str(raw['operationId']))
                        continue
                    if e['deviceId'] != auth['device_id']:
                        conflicts.append(e['operationId']); continue
                    existing = c.execute('SELECT * FROM operations WHERE operation_id=?', (e['operationId'],)).fetchone()
                    if existing:
                        if existing['business_id'] == business and existing['device_id'] == e['deviceId']:
                            synced.append(e['operationId'])
                        else:
                            conflicts.append(e['operationId'])
                        continue
                    prior = c.execute('''SELECT operation_id,operation,version FROM operations
                                        WHERE business_id=? AND table_name=? AND record_id=?
                                        ORDER BY version DESC, seq DESC LIMIT 1''',
                                      (business,e['tableName'],e['recordId'])).fetchone()
                    if prior:
                        if e['tableName'] in FINANCIAL_TABLES:
                            conflicts.append(e['operationId']); continue
                        if e['version'] <= prior['version']:
                            conflicts.append(e['operationId']); continue
                    if e['operation'].upper() != 'CREATE' and e['tableName'] not in MASTER_TABLES:
                        conflicts.append(e['operationId']); continue
                    c.execute('''INSERT INTO operations(operation_id,business_id,record_id,table_name,operation,device_id,version,payload_json)
                                 VALUES(?,?,?,?,?,?,?,?)''',
                              (e['operationId'],business,e['recordId'],e['tableName'],e['operation'].upper(),
                               e['deviceId'],e['version'],json.dumps(e['payload'],ensure_ascii=False,separators=(',',':'))))
                    synced.append(e['operationId'])
                c.commit()
            except Exception:
                c.rollback(); raise
            json_response(self, HTTPStatus.OK, {'syncedOperationIds':synced,'conflictOperationIds':conflicts})
        except Exception as exc:
            json_response(self, HTTPStatus.INTERNAL_SERVER_ERROR, {'error':'server_error'})
        finally:
            c.close()


def main():
    host = os.getenv('HOST', '0.0.0.0')
    port = int(os.getenv('PORT', '8080'))
    c = db(); bootstrap_tokens(c); c.close()
    server = ThreadingHTTPServer((host, port), Handler)
    print(f'Asan Hisab Sync listening on {host}:{port}')
    server.serve_forever()

if __name__ == '__main__':
    main()
