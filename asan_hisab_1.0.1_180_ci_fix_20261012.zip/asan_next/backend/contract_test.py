#!/usr/bin/env python3
import json, os, tempfile, threading, urllib.request, urllib.error
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import app


def req(url, method='GET', payload=None, token=None):
    data = None if payload is None else json.dumps(payload).encode()
    r = urllib.request.Request(url, data=data, method=method, headers={'Content-Type':'application/json'})
    if token: r.add_header('Authorization', 'Bearer ' + token)
    with urllib.request.urlopen(r, timeout=5) as x:
        return x.status, json.loads(x.read().decode())


def main():
    with tempfile.TemporaryDirectory() as td:
        app.DB_PATH = os.path.join(td, 'sync.sqlite3')
        token1 = 'test-token-device-1-7f2d9c4a81b63e55c0a9d7f2e4b8c1aa'
        token2 = 'test-token-device-2-3a9e6c1f74b52d88e0c4a7b1d5f9e2cc'
        os.environ['ASAN_SYNC_TOKENS'] = json.dumps([{'token': 'too-short', 'businessId': 'biz-a', 'deviceId': 'dev-a'}])
        try:
            with app.db() as c:
                app.bootstrap_tokens(c)
            raise AssertionError('short auth token unexpectedly accepted')
        except RuntimeError:
            pass

        os.environ['ASAN_SYNC_TOKENS'] = json.dumps([
            {'token': token1, 'businessId': 'biz-a', 'deviceId': 'dev-a'},
            {'token': token2, 'businessId': 'biz-a', 'deviceId': 'dev-b'},
        ])
        server = app.ThreadingHTTPServer(('127.0.0.1', 0), app.Handler)
        # Contract-test request handlers must not keep the process alive after shutdown.
        server.daemon_threads = True
        server.block_on_close = False
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        base = f'http://127.0.0.1:{server.server_address[1]}'
        try:
            s, h = req(base + '/health')
            assert s == 200 and h['ok'] is True
            with urllib.request.urlopen(base + '/health', timeout=5) as x:
                assert x.headers.get('X-Content-Type-Options') == 'nosniff'
                assert x.headers.get('X-Frame-Options') == 'DENY'
                assert x.headers.get('Referrer-Policy') == 'no-referrer'
                assert x.headers.get('Content-Security-Policy') == "default-src 'none'; frame-ancestors 'none'; base-uri 'none'"
                assert x.headers.get('Permissions-Policy') == 'camera=(), microphone=(), geolocation=()'
                assert x.headers.get('Cross-Origin-Resource-Policy') == 'same-origin'
                assert x.headers.get('X-Download-Options') == 'noopen'
                assert x.headers.get('Strict-Transport-Security') is None
                https_probe = urllib.request.Request(base + '/health', headers={'X-Forwarded-Proto':'https'})
                with urllib.request.urlopen(https_probe, timeout=5) as y:
                    assert y.headers.get('Strict-Transport-Security') == 'max-age=31536000; includeSubDomains'
            try:
                req(base + '/v1/sync/pull?businessId=biz-a&deviceId=dev-a&cursor=0')
                raise AssertionError('unauthorized pull unexpectedly accepted')
            except urllib.error.HTTPError as e:
                assert e.code == 401
            bad_req = urllib.request.Request(base + '/v1/sync/push', data=b'{}', method='POST', headers={'Content-Type':'text/plain', 'Authorization':'Bearer ' + token1})
            try:
                urllib.request.urlopen(bad_req, timeout=5)
                raise AssertionError('unsupported content type unexpectedly accepted')
            except urllib.error.HTTPError as e:
                assert e.code == 415
            op = {'operationId':'op-1','recordId':'cust-1','tableName':'customers','operation':'CREATE','deviceId':'dev-a','version':1,'payload':{'id':'cust-1','name':'Test'}}
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId':'biz-a','operations':[op]}, token1)
            assert out['syncedOperationIds'] == ['op-1'] and not out['conflictOperationIds']
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId':'biz-a','operations':[op]}, token1)
            assert out['syncedOperationIds'] == ['op-1']
            s, out = req(base + '/v1/sync/pull?businessId=biz-a&deviceId=dev-b&cursor=0', token=token2)
            assert len(out['operations']) == 1 and out['nextCursor'] == '1'

            fin1 = {'operationId':'fin-1','recordId':'sale-1','tableName':'sales','operation':'CREATE','deviceId':'dev-a','version':1,'payload':{'id':'sale-1','total':100}}
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId':'biz-a','operations':[fin1]}, token1)
            assert out['syncedOperationIds'] == ['fin-1']
            fin2 = dict(fin1); fin2['operationId']='fin-2'; fin2['version']=2
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId':'biz-a','operations':[fin2]}, token1)
            assert out['conflictOperationIds'] == ['fin-2']
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId':'biz-b','operations':[op]}, token1)
            raise AssertionError('business isolation unexpectedly accepted')
        except urllib.error.HTTPError as e:
            if e.code != 400: raise
            # Continue with explicit unauthorized isolation checks.
            try:
                req(base + '/v1/sync/pull?businessId=biz-b&deviceId=dev-b&cursor=0', token=token2)
                raise AssertionError('cross-business pull unexpectedly accepted')
            except urllib.error.HTTPError as x:
                assert x.code == 403

            # Revocation must survive per-request environment-token bootstrapping.
            with app.db() as c:
                c.execute('UPDATE auth_devices SET active=0 WHERE token_hash=?', (app.hash_token(token1),))
                c.commit()
            try:
                req(base + '/v1/sync/pull?businessId=biz-a&deviceId=dev-a&cursor=0', token=token1)
                raise AssertionError('revoked token unexpectedly accepted')
            except urllib.error.HTTPError as e:
                assert e.code == 401
            s, out = req(base + '/v1/sync/pull?businessId=biz-a&deviceId=dev-b&cursor=0', token=token2)
            assert s == 200

            # A revoked token must remain rejected even if the auth-token environment
            # is still present; another device in the same business must remain usable.
            s, out = req(base + '/v1/sync/pull?businessId=biz-a&deviceId=dev-b&cursor=1', token=token2)
            assert s == 200 and int(out['nextCursor']) >= 1

            # Concurrent duplicate delivery must stay idempotent: the same operation
            # cannot create multiple sync log rows.
            op2 = {'operationId':'op-concurrent','recordId':'cust-2','tableName':'customers','operation':'CREATE','deviceId':'dev-b','version':1,'payload':{'id':'cust-2','name':'Concurrent'}}
            results = []
            def push_once():
                try:
                    results.append(req(base + '/v1/sync/push', 'POST', {'businessId':'biz-a','operations':[op2]}, token2)[1])
                except Exception as exc:
                    results.append(exc)
            workers = [threading.Thread(target=push_once) for _ in range(4)]
            for w in workers: w.start()
            for w in workers: w.join()
            assert len(results) == 4 and all(isinstance(x, dict) for x in results)
            assert all(x['syncedOperationIds'] == ['op-concurrent'] for x in results)
            with app.db() as c:
                count = c.execute('SELECT COUNT(*) FROM operations WHERE operation_id=?', ('op-concurrent',)).fetchone()[0]
                assert count == 1
        finally:
            server.shutdown(); server.server_close()
    print('PASS: backend contract tests')

if __name__ == '__main__': main()
