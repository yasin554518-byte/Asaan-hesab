# Asan Hisab v103

Version: 1.0.1+90

- Unified release provenance workflow/event identity maximum length with the release bundle manifest contract at 128 characters.
- Added a regression contract proving a 129-character workflow identity is rejected.
- Preserved the existing safe-character allowlist and provenance identity checks.
