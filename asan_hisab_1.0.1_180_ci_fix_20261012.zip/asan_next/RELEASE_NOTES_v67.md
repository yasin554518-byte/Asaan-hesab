# Asan Hisab v67

## CI Workflow Contract Alignment

- Added a CI workflow contract test covering required release/build/security gates.
- Verified release AAB and provenance artifact paths remain present.
- Verified production smoke is tag-gated and depends on Flutter/backend jobs.
- Verified the release build and artifact upload steps remain wired into the workflow.
- Bumped application version to `1.0.1+53`.
