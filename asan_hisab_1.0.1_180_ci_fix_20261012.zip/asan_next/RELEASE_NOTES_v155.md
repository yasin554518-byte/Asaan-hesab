# Asan Hisab v156

Version: 1.0.1+142

## Change
Statement PDF generation now uses the same `openingBalanceAt()` period-opening semantics as the on-screen Statement and advances PDF row balances from that period opening. This removes the filtered-period mismatch that could occur when printing a date-filtered statement.

## Validation
Source-level Statement PDF period consistency contract added.
