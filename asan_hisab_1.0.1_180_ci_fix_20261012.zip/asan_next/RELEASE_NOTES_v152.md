# Asan Hisab v152

Version: 1.0.1+138

- Fixed empty date-filter Statement closing balance to use period opening balance instead of party opening balance.
- Added regression contract for empty filtered periods.
- Flutter/Dart/AAB/device gates remain environment-limited where SDK/device are unavailable.
