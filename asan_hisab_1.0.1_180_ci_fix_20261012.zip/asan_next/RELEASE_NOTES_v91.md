# Asan Hisab v91

- Version: 1.0.1+77
- Release bundle inputs are now required to be regular files, not symlinks, before provenance/checksum binding.
- Added a regression contract test proving a symlinked AAB is rejected.
- Automated release preflight and backend contract tests are expected to remain unchanged; Android/Flutter build and production deployment remain environment-dependent gates.
