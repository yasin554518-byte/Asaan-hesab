# Asan Hisab v142

Version: 1.0.1+129

- Centralized customer/supplier ledger balance arithmetic in `LedgerBalance`.
- Statement running balance and aggregate balance now share the same validation and direction rules.
- Rejects negative ledger amounts and two-sided debit/credit entries at the balance boundary.
- Added ledger balance unit/contract coverage.
