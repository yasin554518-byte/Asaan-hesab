# Asan Hisab v134

Version: 1.0.1+120

- Added explicit financial composition invariants for discount, paid, total, and remaining values.
- Added exact-boundary tests for full discount and full payment.
- Kept the existing centralized Money validation as the single source for these invariants.
