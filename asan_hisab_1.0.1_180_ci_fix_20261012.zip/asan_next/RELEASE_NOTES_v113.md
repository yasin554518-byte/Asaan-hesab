# Asan Hisab v113 — sync failure propagation

- Fixed automatic sync error handling so transport/server failures reach `SyncScheduler` instead of being swallowed inside the session callback.
- This makes the bounded exponential backoff introduced in v112 effective for real auto-sync failures.
- Added a regression contract test to prevent reintroducing swallowed auto-sync errors.
- Version: 1.0.1+100.
