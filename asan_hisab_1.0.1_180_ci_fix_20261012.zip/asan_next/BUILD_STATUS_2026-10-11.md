# Asan Hisab Build Status — 2026-10-11

Version: `1.0.1+180`
Application ID target: `com.asanhisab.app`

## Checks executed in this review

Passed (20): QA APK workflow contract, Android prepare contract, Android signing contract, release bundle manifest identity, release artifact provenance, release provenance, release bundle integrity, release bundle manifest, checksum generation, release static checks, CI workflow structure, CI artifact retention, CI artifact uniqueness, secret-material checks, production token entropy, sync queue idempotency, manual sync retry, sync worker push failure, latest-backup discovery, and API security headers.

The release candidate check initially failed because running Python tests created `__pycache__` in the source tree. Generated Python cache files were removed, then `tool/release_candidate_check.sh` was rerun and passed, including application-ID configuration, source smoke checks, static invariants, purchase lifecycle, sale/purchase validation, and release candidate checks.

## Important limitations

- Flutter, Dart, Android SDK, ADB, and Gradle are not installed in the current build environment.
- The network DNS lookup needed to fetch Flutter dependencies is unavailable here.
- Therefore no APK/AAB was built in this environment, and no physical-device installation or two-device sync test has been completed.
- `.github/workflows/qa-apk.yml` defines a GitHub Actions QA APK build, but its execution on GitHub has not been verified from this environment.

## Next required release steps

1. Push this project to an accessible GitHub repository.
2. Run the `QA Android APK` workflow and inspect its logs/artifact.
3. Run Flutter analyze and test results, then produce the release AAB in a Flutter-enabled CI environment.
4. Install the APK on Android hardware; verify ledger calculations, backup/restore, and sync across two devices.
5. Only mark release-ready after successful build and device checks.
