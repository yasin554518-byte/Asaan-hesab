# Release Notes v100

Version: 1.0.1+87

- Tightened release bundle artifact identity validation.
- The manifest now requires the artifact name to be the canonical `app-release.aab`.
- Added a regression assertion for canonical artifact identity.
- Android AAB build remains pending until a Flutter/Android SDK environment is available.
- Production deployment remains pending until production secrets/environment are available.
