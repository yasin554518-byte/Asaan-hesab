# Asan Hisab v183

Version: 1.0.1+167

- Hardened CSV import confirmation against post-await dispose: the preview state is cleared only while the page remains mounted.
- Added a regression contract for this exact guard.
