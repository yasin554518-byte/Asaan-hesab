# Asan Hisab v146

Version: 1.0.1+132

- Added the ledger `note` column to the canonical schema.
- Added schema migration v5 so existing v4 databases gain the column safely.
- This fixes the manual-loan/payment/statement note path on existing installations.
- Updated schema smoke gate to require version 5.
