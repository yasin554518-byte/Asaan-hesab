# Asan Hisab build handoff — 2026-10-11

## Confirmed local checks

The following 25 checks passed in the available environment:

- Version consistency check
- Smoke check
- Release static check
- CI workflow contract
- CI checkout security contract
- CI workflow structure contract
- CI permissions contract
- CI secret-handling contract
- CI trigger contract
- CI release-trigger safety contract
- CI artifact-upload contract
- CI artifact-completeness contract
- CI artifact-uniqueness contract
- CI artifact-retention contract
- Android prepare contract
- Android signing contract
- Release bundle manifest identity contract
- Release artifact provenance contract
- Release provenance contract
- Release bundle integrity contract
- Release bundle manifest contract
- Release checksum generation contract
- Purchase lifecycle contract
- Sale/purchase validation and lifecycle contract
- Backend contract tests

## Confirmed blocker

`tool/prepare_android.sh` was actually attempted and exited with:
`ERROR: Flutter SDK is required to generate Android platform files.`

Flutter, Dart, Gradle, Android SDK tools, and ADB are unavailable in this environment. Network DNS resolution was previously unavailable as well. Therefore no APK/AAB was produced here, `dart analyze` and `flutter test` could not run, and no installation or two-physical-device sync test has been performed.

## Next required release steps

1. Run this project in a machine/CI runner with Flutter stable 3.41.0, Java/Android SDK, and network access.
2. Run `./tool/prepare_android.sh`, `flutter pub get`, `dart analyze`, `flutter test`, and `flutter build appbundle --release`.
3. Configure signing secrets only in the trusted CI secret store for a tagged release.
4. Install and test the build on Android; validate backup restore and sync between two physical devices.
5. Only publish after the actual artifact and device checks pass.

Version in source: `1.0.1+180`. This archive is source code and build handoff, not an APK.
