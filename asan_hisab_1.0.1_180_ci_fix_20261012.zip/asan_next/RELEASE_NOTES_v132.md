# Asan Hisab v132 — Financial Ledger Invariant Contract

Version: 1.0.1+119

## Changes
- Added a release contract covering sale, purchase, payment, and manual-loan ledger directions.
- Added checks for remaining-balance arithmetic and cash transaction signs.
- Added checks that financial transaction tables are treated as immutable records in statement/report paths.
- Kept the change static/contract-only so it cannot alter runtime financial behavior.

## Validation
- Financial ledger invariant contract: PASS
- Version consistency: PASS
- Release static check: PASS
- Release candidate check: PASS
- Two-device sync contract: PASS
- Sync payload safety contract: PASS
- Backup verification/recovery contracts: PASS
- Backend compile: PASS
