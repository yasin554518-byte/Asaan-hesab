#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
EXPECTED_APP_ID="com.asanhisab.app"
MANIFEST="$ROOT/RELEASE_MANIFEST.md"
PUBSPEC="$ROOT/pubspec.yaml"

version="$(sed -n "s/^version: //p" "$PUBSPEC" | head -n1)"
grep -Fq "Application ID: $EXPECTED_APP_ID" "$MANIFEST" || { echo "ERROR: release manifest application id mismatch"; exit 1; }

AAB="$ROOT/build/app/outputs/bundle/release/app-release.aab"
if [[ -f "$AAB" ]]; then
  [[ -s "$AAB" ]] || { echo "ERROR: AAB exists but is empty"; exit 1; }
  (cd "$(dirname "$AAB")" && sha256sum "$(basename "$AAB")") > "$AAB.sha256"
  echo "AAB artifact: PASS"
  echo "Checksum: $(cut -d' ' -f1 "$AAB.sha256")"
else
  echo "AAB artifact: NOT BUILT LOCALLY (CI/build environment required)"
fi

echo "Release artifact gate: PASS"
