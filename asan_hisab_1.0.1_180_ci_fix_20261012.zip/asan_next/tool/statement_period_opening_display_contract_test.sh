#!/usr/bin/env bash
set -euo pipefail
f='lib/features/home/home_shell.dart'
grep -F "ListTile(title:const Text('د فلټر د پیل بیلانس'),trailing:Text('\$periodOpening'))" "$f" >/dev/null
default="ListTile(title:const Text('د پیل بیلانس'),trailing:Text('\$opening'))"
if grep -F "$default" "$f" >/dev/null; then
  echo 'FAIL: Statement UI still displays unfiltered party opening balance' >&2
  exit 1
fi
echo 'PASS: Statement UI displays period opening balance'
