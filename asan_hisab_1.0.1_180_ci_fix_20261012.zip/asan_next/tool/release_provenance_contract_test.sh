#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -q 'app_version' tool/release_provenance.sh || fail 'app version field missing'
grep -q 'git_commit_sha' tool/release_provenance.sh || fail 'commit field missing'
grep -q 'aab_sha256' tool/release_provenance.sh || fail 'AAB checksum field missing'
grep -q 'release_ref' tool/release_provenance.sh || fail 'release ref field missing'
grep -q 'keystore\|private_key\|secret\|token' tool/release_provenance.sh || fail 'secret exclusion gate missing'
grep -q 'release-provenance.json' .github/workflows/ci.yml || fail 'CI provenance artifact missing'
echo 'PASS: release provenance contract'
