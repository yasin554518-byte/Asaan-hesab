#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail(){ echo "FAIL: $1" >&2; exit 1; }
req=(
  "$ROOT/pubspec.yaml"
  "$ROOT/lib/core/database/schema.dart"
  "$ROOT/lib/core/database/app_database.dart"
  "$ROOT/lib/core/database/backup_service.dart"
  "$ROOT/lib/core/security/pin_service.dart"
  "$ROOT/lib/core/security/permission_service.dart"
  "$ROOT/lib/core/sync/sync_queue_service.dart"
  "$ROOT/lib/shared/services/sale_service.dart"
  "$ROOT/lib/shared/services/purchase_service.dart"
  "$ROOT/lib/shared/services/payment_service.dart"
  "$ROOT/lib/shared/services/return_service.dart"
  "$ROOT/lib/shared/services/expense_service.dart"
  "$ROOT/lib/shared/services/notification_service.dart"
  "$ROOT/features 2>/dev/null"
)
for f in "${req[@]:0:${#req[@]}-1}"; do [[ -f "$f" ]] || fail "missing $f"; done
[[ -d "$ROOT/lib/features" ]] || fail "missing lib/features"
grep -q 'const schemaVersion = 5' "$ROOT/lib/core/database/schema.dart" || fail 'schema version is not 5'
grep -q 'foreign_keys' "$ROOT/lib/core/database/app_database.dart" || fail 'foreign key pragma missing'
grep -q 'hashPin' "$ROOT/lib/core/security/pin_service.dart" || fail 'PIN hashing missing'
if grep -RniE "pin[[:space:]_]*(=|:)[[:space:]]*['\"]?[0-9]{4,8}" "$ROOT/lib" --exclude='*.md'; then fail 'possible plaintext PIN found'; fi
for s in 'cash_transactions' 'ledger_entries' 'sync_queue' 'audit_logs'; do grep -Rqi "$s" "$ROOT/lib" || fail "missing accounting/sync table reference: $s"; done
echo "PASS: Asan Hisab source smoke checks completed."
