#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1"; exit 1; }
grep -Fq '(cd "$(dirname "$AAB")" && sha256sum "$(basename "$AAB")") > "$AAB.sha256"' tool/release_artifact_check.sh || fail 'release artifact checksum generation is not canonical'
grep -Fq '(cd build/app/outputs/bundle/release && sha256sum app-release.aab) > build/app-release.aab.sha256' .github/workflows/ci.yml || fail 'CI checksum generation is not canonical'
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/build/app/outputs/bundle/release"
printf 'fixture-aab' > "$tmp/build/app/outputs/bundle/release/app-release.aab"
AAB="$tmp/build/app/outputs/bundle/release/app-release.aab"
(cd "$(dirname "$AAB")" && sha256sum "$(basename "$AAB")") > "$AAB.sha256"
expected="app-release.aab"
actual="$(awk '{print $2}' "$AAB.sha256")"
[[ "$actual" == "$expected" ]] || fail "generated checksum references '$actual' instead of '$expected'"
echo 'PASS: release checksum generation contract'
