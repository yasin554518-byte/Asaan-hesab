#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
base='{"app_version":"1.0.1+88","git_commit_sha":"0123456789012345678901234567890123456789","release_ref":"refs/tags/v1.0.1+88","release_tag":"v1.0.1+88","aab_sha256":"0123456789012345678901234567890123456789012345678901234567890123","workflow_run_id":"1","workflow_run_attempt":"1","workflow_name":"CI","event_name":"push","artifact_name":"app-release.aab","published_artifact_name":"asan-hisab-release-v1.0.1+88-1-1"}'
printf '%s\n' "$base" > "$tmp/good.json"
PROVENANCE_PATH="$tmp/good.json" bash "$ROOT/tool/release_provenance_schema_check.sh" >/dev/null
python3 - "$tmp/good.json" <<'PY'
import json,sys
p=sys.argv[1]; o=json.load(open(p)); o['workflow_name']='A'*129; json.dump(o,open(p,'w'))
PY
if PROVENANCE_PATH="$tmp/good.json" bash "$ROOT/tool/release_provenance_schema_check.sh" >/dev/null 2>&1; then
  echo 'FAIL: 129-character workflow_name was accepted'; exit 1
fi
echo 'PASS: release provenance identity length contract'
