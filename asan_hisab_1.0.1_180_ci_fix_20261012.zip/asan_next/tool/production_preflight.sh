#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ENV_FILE="${1:-$ROOT/backend/.env}"
fail(){ echo "FAIL: $*" >&2; exit 1; }
[ -f "$ENV_FILE" ] || fail "production env file not found: $ENV_FILE"

# Production environment files contain live device tokens; never allow group/other access.
python - "$ENV_FILE" <<'PYMODE'
import os, stat, sys
p=sys.argv[1]
mode=stat.S_IMODE(os.stat(p).st_mode)
if mode & 0o077:
    raise SystemExit(f"FAIL: production env file is accessible by group/other users (mode {mode:04o}); require owner-only permissions")
print(f"PASS: production env file permissions are owner-only ({mode:04o})")
PYMODE
python - "$ENV_FILE" <<'PY'
import json,sys
from pathlib import Path
p=Path(sys.argv[1]); vals={}
for raw in p.read_text().splitlines():
    raw=raw.strip()
    if not raw or raw.startswith('#') or '=' not in raw: continue
    k,v=raw.split('=',1); vals[k.strip()]=v.strip()
raw=vals.get('ASAN_SYNC_TOKENS','')
if not raw: raise SystemExit('FAIL: ASAN_SYNC_TOKENS is missing')
try: items=json.loads(raw)
except Exception as e: raise SystemExit(f'FAIL: ASAN_SYNC_TOKENS is not valid JSON: {e}')
if not isinstance(items,list) or not items: raise SystemExit('FAIL: ASAN_SYNC_TOKENS must be a non-empty JSON array')
base_url=vals.get('ASAN_SYNC_BASE_URL','').strip()
if base_url:
    from urllib.parse import urlparse
    u=urlparse(base_url)
    if u.scheme != 'https' or not u.netloc: raise SystemExit('FAIL: ASAN_SYNC_BASE_URL must be a valid HTTPS URL')
    if u.username or u.password: raise SystemExit('FAIL: ASAN_SYNC_BASE_URL must not contain embedded credentials')
    if u.query or u.fragment: raise SystemExit('FAIL: ASAN_SYNC_BASE_URL must not contain query or fragment')
    host=(u.hostname or '').lower()
    if host in {'localhost','127.0.0.1','::1'}: raise SystemExit('FAIL: ASAN_SYNC_BASE_URL must not point to loopback')
tokens=[]; pairs=set()
for i,x in enumerate(items):
    if not isinstance(x,dict): raise SystemExit(f'FAIL: token entry {i} is not an object')
    for k in ('token','businessId','deviceId'):
        if not str(x.get(k,'')).strip(): raise SystemExit(f'FAIL: token entry {i} missing {k}')
    token=str(x['token'])
    if token.startswith('REPLACE_') or len(token)<32: raise SystemExit(f'FAIL: token entry {i} is a placeholder or too short (minimum 32 chars)')
    if len(set(token)) < 8: raise SystemExit(f'FAIL: token entry {i} has insufficient character diversity')
    classes=sum((any(c.islower() for c in token), any(c.isupper() for c in token), any(c.isdigit() for c in token)))
    if classes < 3: raise SystemExit(f'FAIL: token entry {i} must contain lowercase, uppercase, and digit characters')
    if len(set(token)) == 1: raise SystemExit(f'FAIL: token entry {i} is trivially repetitive')
    if token in tokens: raise SystemExit('FAIL: duplicate device token')
    pair=(str(x['businessId']),str(x['deviceId']))
    if pair in pairs: raise SystemExit('FAIL: duplicate businessId/deviceId pair')
    tokens.append(token); pairs.add(pair)
print(f'PASS: production env contains {len(items)} device token(s) with unique business/device bindings')
PY
if grep -nEi 'REPLACE_|BEGIN (RSA|OPENSSH|EC|PRIVATE) KEY|PRIVATE KEY' "$ENV_FILE" >/dev/null 2>&1; then
  fail "placeholder or private-key material detected in production environment file"
fi
if grep -RniE 'BEGIN (RSA|OPENSSH|EC|PRIVATE) KEY' "$ROOT/deploy" >/dev/null 2>&1; then
  fail "private-key material detected in deployment configuration"
fi
if grep -nE '^\s*listen\s+80\b' "$ROOT/deploy/nginx/asan-hisab-sync.conf.example" >/dev/null; then
  fail "nginx example must not expose plaintext HTTP"
fi
printf 'PASS: production preflight checks completed\n'
