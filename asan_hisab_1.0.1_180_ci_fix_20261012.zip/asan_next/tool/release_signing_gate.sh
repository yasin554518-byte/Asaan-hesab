#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
AAB="$ROOT/build/app/outputs/bundle/release/app-release.aab"
ANDROID="$ROOT/android"

[[ -f "$AAB" ]] || { echo "FAIL: release AAB not found: $AAB" >&2; exit 1; }

# Normal CI/PR builds may remain unsigned so source/test validation can run.
# Version/tagged release builds must be signed before they are treated as releasable.
IS_RELEASE_TAG=0
if [[ "${GITHUB_REF:-}" == refs/tags/v* ]]; then IS_RELEASE_TAG=1; fi
if [[ "${ASAN_HISAB_REQUIRE_SIGNING:-0}" == "1" ]]; then IS_RELEASE_TAG=1; fi

if [[ "$IS_RELEASE_TAG" != "1" ]]; then
  echo "INFO: signing verification is advisory for non-release builds."
  exit 0
fi

[[ -f "$ANDROID/key.properties" ]] || { echo "FAIL: release signing is required but android/key.properties is missing." >&2; exit 1; }
[[ -f "$ANDROID/upload-keystore.jks" ]] || { echo "FAIL: release signing is required but upload-keystore.jks is missing." >&2; exit 1; }
command -v jarsigner >/dev/null 2>&1 || { echo "FAIL: jarsigner is required for release signing verification." >&2; exit 1; }

ALIAS="$(sed -n 's/^keyAlias=//p' "$ANDROID/key.properties" | head -n1)"
STORE_PASSWORD="$(sed -n 's/^storePassword=//p' "$ANDROID/key.properties" | head -n1)"
[[ -n "$ALIAS" ]] || { echo "FAIL: key.properties has no keyAlias." >&2; exit 1; }
[[ -n "$STORE_PASSWORD" ]] || { echo "FAIL: key.properties has no storePassword." >&2; exit 1; }

# Verify the keystore is readable and the produced AAB contains a valid signature.
keytool -list -keystore "$ANDROID/upload-keystore.jks" -storepass "$STORE_PASSWORD" -alias "$ALIAS" >/dev/null
jarsigner -verify -verbose "$AAB" >/tmp/asan_hisab_jarsigner.txt 2>&1 || {
  cat /tmp/asan_hisab_jarsigner.txt >&2
  echo "FAIL: release AAB signature verification failed." >&2
  exit 1
}

grep -q '^jar verified\.' /tmp/asan_hisab_jarsigner.txt || {
  cat /tmp/asan_hisab_jarsigner.txt >&2
  echo "FAIL: jarsigner did not report a verified archive." >&2
  exit 1
}

echo "PASS: release AAB signature verified for alias '$ALIAS'."
