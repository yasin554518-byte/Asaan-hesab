#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
s='lib/core/sync/sync_scheduler.dart'
python3 - "$s" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
checks=[
("DateTime? _lastAttemptAt;", "attempt timestamp field missing"),
("DateTime? _lastSuccessAt;", "success timestamp field missing"),
("DateTime? _lastFailureAt;", "failure timestamp field missing"),
("DateTime? get lastAttemptAt => _lastAttemptAt;", "attempt diagnostic getter missing"),
("DateTime? get lastSuccessAt => _lastSuccessAt;", "success diagnostic getter missing"),
("DateTime? get lastFailureAt => _lastFailureAt;", "failure diagnostic getter missing"),
("_lastAttemptAt = DateTime.now().toUtc();", "attempt timestamp not recorded"),
("_lastSuccessAt = DateTime.now().toUtc();", "success timestamp not recorded"),
("_lastFailureAt = DateTime.now().toUtc();", "failure timestamp not recorded"),
]
for needle,msg in checks:
    if needle not in s: raise SystemExit('FAIL: '+msg)
print('PASS: sync scheduler diagnostics contract')
PY
