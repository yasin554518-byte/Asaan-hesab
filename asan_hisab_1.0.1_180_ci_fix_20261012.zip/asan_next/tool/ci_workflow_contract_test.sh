#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
fail(){ echo "FAIL: $1" >&2; exit 1; }
[[ -f "$CI" ]] || fail 'CI workflow missing'
python3 - "$CI" <<'PY'
from pathlib import Path
import re, sys
p=Path(sys.argv[1]).read_text(encoding='utf-8')
required = [
    'permissions:\n  contents: read',
    'concurrency:',
    'flutter:',
    'backend:',
    'production-smoke:',
    './tool/version_consistency_check.sh',
    './tool/ci_workflow_contract_test.sh',
    './tool/release_artifact_provenance_contract_test.sh',
    './tool/release_provenance_schema_check.sh',
    'flutter build appbundle --release',
    'actions/upload-artifact@v4',
]
for needle in required:
    if needle not in p:
        raise SystemExit(f'FAIL: required CI workflow contract missing: {needle}')
if not re.search(r'production-smoke:\n\s+if: startsWith\(github\.ref, .refs/tags/v.\)', p):
    raise SystemExit('FAIL: production smoke must be tag-gated')
if not re.search(r'production-smoke:\n(?:.|\n)*?needs: \[flutter, backend\]', p):
    raise SystemExit('FAIL: production smoke dependency gate missing')
if 'build/app/outputs/bundle/release/app-release.aab' not in p:
    raise SystemExit('FAIL: AAB artifact path missing')
if 'build/release-provenance.json' not in p:
    raise SystemExit('FAIL: provenance artifact path missing')
print('PASS: CI workflow contract')
PY
