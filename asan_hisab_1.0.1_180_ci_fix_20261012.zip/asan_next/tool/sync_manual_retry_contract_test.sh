#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILE="$ROOT/lib/core/sync/sync_queue_service.dart"
python3 - "$FILE" <<'PY'
from pathlib import Path
import sys
text = Path(sys.argv[1]).read_text()
start = text.index('  Future<void> retryFailed(String businessId) async {')
end = text.index('\n  Future<void> markRetry', start)
body = text[start:end]
required = [
    "'status': SyncQueueStatus.pending",
    "'retry_count': 0",
    "'last_attempt_at': null",
    "status = ?",
    "SyncQueueStatus.failed",
]
for item in required:
    if item not in body:
        raise SystemExit(f'FAIL: manual retry missing {item}')
print('PASS: manual retry resets backoff and makes failed items immediately eligible')
PY
