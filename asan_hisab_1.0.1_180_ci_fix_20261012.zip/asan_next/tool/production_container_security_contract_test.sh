#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail(){ echo "FAIL: $*" >&2; exit 1; }
DF="$ROOT/backend/Dockerfile"
CF="$ROOT/backend/docker-compose.production.yml"
NG="$ROOT/deploy/nginx/asan-hisab-sync.conf.example"

grep -Eq '^USER[[:space:]]+app$' "$DF" || fail 'Docker image must run as non-root app user'
grep -Eq '^HEALTHCHECK[[:space:]]' "$DF" || fail 'Docker image must define a healthcheck'
grep -Eq 'PYTHONDONTWRITEBYTECODE' "$CF" || fail 'production compose must disable Python bytecode writes'
grep -Eq '^    read_only:[[:space:]]+true$' "$CF" || fail 'production compose must use a read-only root filesystem'
grep -Eq 'no-new-privileges:true' "$CF" || fail 'production compose must enable no-new-privileges'
grep -Eq '^      - ALL$' "$CF" || fail 'production compose must drop all Linux capabilities'
grep -Eq '^    expose:$' "$CF" || fail 'production compose must expose the API only to the internal network'
if grep -Eq '^    ports:' "$CF"; then fail 'production compose must not publish the API port directly'; fi
grep -Eq '^    tmpfs:' "$CF" || fail 'production compose must define a constrained tmpfs'
grep -Eq '^    read_only:[[:space:]]+true$' "$CF" || fail 'read-only root filesystem gate missing'
grep -Eq '^    listen 443 ssl http2;$' "$NG" || fail 'nginx must terminate TLS on 443'
if grep -Eq '^[[:space:]]*listen[[:space:]]+80\b' "$NG"; then fail 'nginx example must not expose plaintext HTTP'; fi
grep -Eq 'proxy_set_header X-Forwarded-Proto https;' "$NG" || fail 'nginx must forward HTTPS state'
printf '%s\n' 'PASS: production container security contract test'
