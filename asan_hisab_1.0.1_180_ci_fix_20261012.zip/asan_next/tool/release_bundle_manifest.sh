#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
OUT="${RELEASE_BUNDLE_MANIFEST_PATH:-$ROOT/build/release-bundle-manifest.txt}"
AAB="${AAB_PATH:-$ROOT/build/app/outputs/bundle/release/app-release.aab}"
PROV="${PROVENANCE_PATH:-$ROOT/build/release-provenance.json}"
CHECKSUM="${CHECKSUM_PATH:-$ROOT/build/app-release.aab.sha256}"
for f in "$AAB" "$PROV" "$CHECKSUM"; do [[ -f "$f" ]] || { echo "FAIL: missing release bundle file: $f"; exit 1; }; [[ ! -L "$f" ]] || { echo "FAIL: release bundle file must not be a symlink: $f"; exit 1; }; done
mkdir -p "$(dirname "$OUT")"
{
  printf 'manifest_version=3\n'
  printf 'app_version=%s\n' "$(sed -n 's/^version: //p' pubspec.yaml | head -1)"
  printf 'artifact_name=%s\n' "$(basename "$AAB")"
  printf 'artifact_relative_path=build/app/outputs/bundle/release/app-release.aab\n'
  printf 'checksum_relative_path=build/app-release.aab.sha256\n'
  if [[ "${GITHUB_REF:-}" == refs/tags/v* && -n "${GITHUB_RUN_ID:-}" && -n "${GITHUB_RUN_ATTEMPT:-}" ]]; then
    printf 'published_artifact_name=%s\n' "asan-hisab-release-${GITHUB_REF_NAME}-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}"
  else
    printf 'published_artifact_name=%s\n' local
  fi
  printf 'release_ref=%s\n' "${GITHUB_REF:-local}"
  printf 'workflow_run_id=%s\n' "${GITHUB_RUN_ID:-local}"
  printf 'workflow_run_attempt=%s\n' "${GITHUB_RUN_ATTEMPT:-local}"
  printf 'workflow_name=%s\n' "${GITHUB_WORKFLOW:-local}"
  printf 'event_name=%s\n' "${GITHUB_EVENT_NAME:-local}"
  printf 'commit_sha=%s\n' "${GITHUB_SHA:-local}"
  printf 'artifact_size_bytes=%s\n' "$(stat -c '%s' "$AAB")"
  printf 'artifact_sha256=%s\n' "$(sha256sum "$AAB" | awk '{print $1}')"
  printf 'provenance_sha256=%s\n' "$(sha256sum "$PROV" | awk '{print $1}')"
  printf 'checksum_file_sha256=%s\n' "$(sha256sum "$CHECKSUM" | awk '{print $1}')"
} > "$OUT"
python3 - "$OUT" <<'PY'
from pathlib import Path
p=Path(__import__('sys').argv[1])
required={'manifest_version','app_version','artifact_name','artifact_relative_path','checksum_relative_path','published_artifact_name','release_ref','workflow_run_id','workflow_run_attempt','workflow_name','event_name','commit_sha','artifact_size_bytes','artifact_sha256','provenance_sha256','checksum_file_sha256'}
lines=p.read_text().splitlines()
if any(line and '=' not in line for line in lines):
    raise SystemExit('FAIL: malformed manifest line')
entries=[line.split('=',1) for line in lines if '=' in line]
keys=[k for k,_ in entries]
if len(keys) != len(set(keys)):
    raise SystemExit('FAIL: duplicate manifest keys')
vals=dict(entries)
missing=required-set(vals)
if missing: raise SystemExit(f'FAIL: manifest missing keys: {sorted(missing)}')
if vals['manifest_version'] != '3': raise SystemExit('FAIL: unsupported manifest version')
import re
for key, value in vals.items():
    if not key or any(ord(ch) < 32 or ord(ch) == 127 for ch in value):
        raise SystemExit(f'FAIL: manifest value contains control characters: {key}')
if len(vals['artifact_sha256']) != 64 or len(vals['provenance_sha256']) != 64 or len(vals['checksum_file_sha256']) != 64:
    raise SystemExit('FAIL: invalid SHA-256 length in manifest')
if vals['commit_sha'] != 'local' and not re.fullmatch(r'[0-9a-f]{40}', vals['commit_sha']):
    raise SystemExit('FAIL: invalid commit SHA in manifest')
if vals['workflow_run_id'] != 'local' and not re.fullmatch(r'[1-9][0-9]*', vals['workflow_run_id']):
    raise SystemExit('FAIL: invalid workflow run ID in manifest')
if vals['workflow_run_attempt'] != 'local' and not re.fullmatch(r'[1-9][0-9]*', vals['workflow_run_attempt']):
    raise SystemExit('FAIL: invalid workflow run attempt in manifest')
if not re.fullmatch(r'local|refs/tags/v\d+\.\d+\.\d+\+\d+', vals['release_ref']):
    raise SystemExit('FAIL: invalid release ref in manifest')
if vals['release_ref'] != 'local' and vals['release_ref'].split('/')[-1] != 'v' + vals['app_version']:
    raise SystemExit('FAIL: release ref must match app version in manifest')
if not re.fullmatch(r'\d+\.\d+\.\d+\+\d+', vals['app_version']):
    raise SystemExit('FAIL: invalid app version in manifest')
if vals['workflow_name'] != 'local' and len(vals['workflow_name']) > 128:
    raise SystemExit('FAIL: workflow name exceeds safe length')
if vals['workflow_name'] != 'local' and not re.fullmatch(r'[A-Za-z0-9._+/@:-]+', vals['workflow_name']):
    raise SystemExit('FAIL: workflow name contains unsupported characters')
if vals['event_name'] != 'local' and len(vals['event_name']) > 128:
    raise SystemExit('FAIL: event name exceeds safe length')
if vals['event_name'] != 'local' and not re.fullmatch(r'[A-Za-z0-9._+/@:-]+', vals['event_name']):
    raise SystemExit('FAIL: event name contains unsupported characters')
if vals['artifact_name'] != 'app-release.aab':
    raise SystemExit('FAIL: artifact name must be canonical release AAB filename')
if vals['artifact_relative_path'] != 'build/app/outputs/bundle/release/app-release.aab':
    raise SystemExit('FAIL: artifact relative path must be canonical release AAB path')
if vals['checksum_relative_path'] != 'build/app-release.aab.sha256':
    raise SystemExit('FAIL: checksum relative path must be canonical release checksum path')
if vals['published_artifact_name'] != 'local':
    if len(vals['published_artifact_name']) > 128 or not re.fullmatch(r'asan-hisab-release-v\d+\.\d+\.\d+\+\d+-[0-9]+-[0-9]+', vals['published_artifact_name']):
        raise SystemExit('FAIL: invalid published artifact name format')
    expected=f"asan-hisab-release-{vals['release_ref'].split('/')[-1]}-{vals['workflow_run_id']}-{vals['workflow_run_attempt']}"
    if vals['published_artifact_name'] != expected:
        raise SystemExit('FAIL: published artifact name does not match release identity')
if not re.fullmatch(r'[1-9][0-9]*', vals['artifact_size_bytes']): raise SystemExit('FAIL: artifact size must be a positive decimal integer')
if int(vals['artifact_size_bytes']) != Path(__import__('os').environ.get('AAB_PATH', 'build/app/outputs/bundle/release/app-release.aab')).stat().st_size:
    raise SystemExit('FAIL: manifest artifact size does not match the release AAB')
# Validate that the published checksum file actually names this AAB and matches it.
checksum_file=Path(__import__('os').environ.get('CHECKSUM_PATH', str(p.parent/'app-release.aab.sha256')))
if not checksum_file.is_file():
    # The script's default checksum location is relative to the repository root.
    checksum_file=Path('build/app-release.aab.sha256')
aab=Path(__import__('os').environ.get('AAB_PATH', 'build/app/outputs/bundle/release/app-release.aab'))
actual_artifact_sha256=__import__('hashlib').sha256(aab.read_bytes()).hexdigest()
if vals['artifact_sha256'] != actual_artifact_sha256:
    raise SystemExit('FAIL: manifest artifact SHA-256 does not match the release AAB')
raw_checksum=checksum_file.read_text()
line=[ln.strip() for ln in raw_checksum.splitlines() if ln.strip()]
if len(line) != 1:
    raise SystemExit('FAIL: checksum file must contain exactly one non-empty line')
parts=line[0].split()
if len(parts) != 2 or parts[0] != vals['artifact_sha256']:
    raise SystemExit('FAIL: checksum file must contain exactly one SHA-256 and one artifact path')
import re
if not re.fullmatch(r'[0-9a-fA-F]{64}', parts[0]):
    raise SystemExit('FAIL: checksum file contains an invalid SHA-256 value')
checksum_ref=parts[1]
if checksum_ref != aab.name:
    raise SystemExit('FAIL: checksum file must reference the release AAB by canonical filename only')
if checksum_ref.startswith('/') or checksum_ref in {'.', '..'} or '/' in checksum_ref or '\\' in checksum_ref or checksum_ref != Path(checksum_ref).name:
    raise SystemExit('FAIL: checksum file contains a non-canonical or path-traversing artifact reference')
# Cross-check the manifest against the release provenance so metadata cannot drift.
prov=Path(__import__('os').environ.get('PROVENANCE_PATH', 'build/release-provenance.json'))
import json
try:
    pobj=json.loads(prov.read_text())
except Exception as exc:
    raise SystemExit(f'FAIL: invalid release provenance JSON: {exc}')
checks={
    'app_version':'app_version', 'release_ref':'release_ref',
    'workflow_run_id':'workflow_run_id', 'workflow_run_attempt':'workflow_run_attempt',
    'workflow_name':'workflow_name', 'event_name':'event_name',
    'artifact_name':'artifact_name', 'published_artifact_name':'published_artifact_name',
    'commit_sha':'git_commit_sha', 'artifact_sha256':'aab_sha256'
}
for mk,pk in checks.items():
    if str(pobj.get(pk)) != vals[mk]:
        raise SystemExit(f'FAIL: manifest/provenance mismatch for {mk}')
print('PASS: release bundle manifest')
PY
