#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
grep -Fq "Backup destination must not be a symlink" lib/core/database/backup_service.dart || fail 'destination symlink guard missing'
grep -Fq "Backup destination must differ from live database" lib/core/database/backup_service.dart || fail 'same-file guard missing'
grep -Fq "Backup file must not be a symlink" lib/core/database/backup_service.dart || fail 'restore symlink guard missing'
printf 'PASS: backup symlink and destination safety contract\n'
