#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
grep -Fq "import 'package:path/path.dart' as p;" lib/core/database/backup_service.dart || fail 'backup service path import missing'
grep -Fq "Backup file must differ from live database" lib/core/database/backup_service.dart || fail 'restore same-live-path guard missing'
printf 'PASS: backup restore live-database path safety contract\n'
