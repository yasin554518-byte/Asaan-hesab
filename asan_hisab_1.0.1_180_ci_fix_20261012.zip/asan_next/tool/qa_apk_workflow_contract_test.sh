#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WF="$ROOT/.github/workflows/qa-apk.yml"
fail(){ echo "FAIL: $1" >&2; exit 1; }
[[ -f "$WF" ]] || fail 'QA APK workflow missing'
grep -Fq 'workflow_dispatch:' "$WF" || fail 'manual workflow_dispatch trigger missing'
grep -Fq 'flutter-version: "3.41.0"' "$WF" || fail 'pinned Flutter version missing'
grep -Fq 'run: ./tool/prepare_android.sh' "$WF" || fail 'Android preparation step missing'
grep -Fq 'run: dart analyze' "$WF" || fail 'Dart analyze step missing'
grep -Fq 'run: flutter test' "$WF" || fail 'Flutter test step missing'
grep -Fq 'run: flutter build apk --debug' "$WF" || fail 'debug APK build step missing'
grep -Fq 'build/app/outputs/flutter-apk/app-debug.apk' "$WF" || fail 'APK artifact path missing'
grep -Fq 'if-no-files-found: error' "$WF" || fail 'missing artifact must fail workflow'
grep -Fq 'persist-credentials: false' "$WF" || fail 'checkout credentials must not persist'
echo 'PASS: QA APK workflow contract'
