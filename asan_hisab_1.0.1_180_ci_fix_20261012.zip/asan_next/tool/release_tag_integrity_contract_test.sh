#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
CI="$ROOT/.github/workflows/ci.yml"
VERSION="$(sed -n 's/^version: //p' pubspec.yaml | head -1)"
[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+\+[0-9]+$ ]] || fail "pubspec version is not release-formatted"
grep -Fq 'tags: ["v*"]' "$CI" || fail 'version-tag trigger missing'
grep -Fq 'startsWith(github.ref, '\''refs/tags/v'\'')' "$CI" || fail 'tag condition missing'
grep -Fq './tool/version_consistency_check.sh' "$CI" || fail 'version consistency gate missing'
grep -Fq 'release_ref' tool/release_provenance.sh || fail 'provenance release_ref missing'
grep -Fq 'release_tag' tool/release_provenance.sh || fail 'provenance release_tag missing'
# The tag-driven release must derive provenance from GITHUB_REF/GITHUB_SHA rather than a hard-coded tag.
grep -Fq 'GITHUB_REF' tool/release_provenance.sh || fail 'provenance must use GITHUB_REF'
grep -Fq 'GITHUB_SHA' tool/release_provenance.sh || fail 'provenance must support GITHUB_SHA'
# No static release tag should be embedded in workflow or provenance helper.
if grep -RInE 'v1\.0\.1\+([0-9]+)|refs/tags/v1\.0\.1\+' .github/workflows/ci.yml tool/release_provenance.sh >/dev/null; then
  fail 'hard-coded release tag/version found in release automation'
fi
echo "PASS: release tag integrity contract ($VERSION)"
