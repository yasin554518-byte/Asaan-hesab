#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
python3 - "$CI" <<'PY'
from pathlib import Path
import re, sys
p=Path(sys.argv[1]).read_text(encoding='utf-8')
blocks=re.findall(r'uses:\s*actions/upload-artifact@v4\n(?P<body>(?:\s+.*\n)+?)(?=\n\S|\Z)', p)
if len(blocks)!=1:
    raise SystemExit('FAIL: expected exactly one upload-artifact block')
body=blocks[0]
m=re.search(r'^\s*retention-days:\s*(\d+)\s*$', body, re.M)
if not m:
    raise SystemExit('FAIL: release artifact retention-days is required')
days=int(m.group(1))
if not 1 <= days <= 30:
    raise SystemExit(f'FAIL: retention-days must be 1..30, got {days}')
print(f'PASS: CI artifact retention contract ({days} days)')
PY
