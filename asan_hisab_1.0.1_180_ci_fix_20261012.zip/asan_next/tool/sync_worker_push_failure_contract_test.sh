#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1"; exit 1; }
APP="lib/core/sync/sync_worker.dart"
[[ -f "$APP" ]] || fail "sync worker source missing"
python3 - <<'PY'
from pathlib import Path
text = Path("lib/core/sync/sync_worker.dart").read_text()
needle = "Error.throwWithStackTrace(error, stackTrace);"
if needle not in text:
    raise SystemExit("FAIL: sync push failure is not propagated to scheduler")
start = text.index("try {\n        result = await adapter.push")
end = text.index("      }\n      // Only count/mark", start)
block = text[start:end]
if "await queue.markRetry(id);" not in block:
    raise SystemExit("FAIL: failed push does not move attempted operations to retry")
if "result = const SyncPushResult" in block:
    raise SystemExit("FAIL: failed push is converted into a fake successful result")
print("PASS: sync worker propagates push failures after marking retry")
PY
