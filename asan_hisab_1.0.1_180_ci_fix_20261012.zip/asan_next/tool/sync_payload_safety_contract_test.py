#!/usr/bin/env python3
"""Contract test for sync request/envelope size limits and identifier safety."""
import json
import os
import tempfile
import threading
import urllib.error
import urllib.request
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'backend'))
import app


def req(url, method='GET', payload=None, token=None):
    data = None if payload is None else json.dumps(payload).encode()
    headers = {}
    if payload is not None:
        headers['Content-Type'] = 'application/json'
    if token:
        headers['Authorization'] = 'Bearer ' + token
    r = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(r, timeout=5) as x:
            return x.status, json.loads(x.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode())


def op(op_id, record_id, device, version, payload):
    return {
        'operationId': op_id,
        'recordId': record_id,
        'tableName': 'customers',
        'operation': 'CREATE',
        'deviceId': device,
        'version': version,
        'payload': payload,
    }


def main():
    with tempfile.TemporaryDirectory() as td:
        app.DB_PATH = os.path.join(td, 'sync.sqlite3')
        token = 'device-a-token-0123456789abcdef0123456789abcdef'
        os.environ['ASAN_SYNC_TOKENS'] = json.dumps([
            {'token': token, 'businessId': 'biz-a', 'deviceId': 'dev-a'},
        ])
        server = app.ThreadingHTTPServer(('127.0.0.1', 0), app.Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f'http://127.0.0.1:{server.server_address[1]}'
        try:
            oversized = 'x' * (app.MAX_OPERATION_PAYLOAD + 1)
            s, out = req(base + '/v1/sync/push', 'POST', {
                'businessId': 'biz-a',
                'operations': [op('too-big', 'cust-big', 'dev-a', 1, {'id': 'cust-big', 'blob': oversized})],
            }, token)
            assert s == 200 and out['conflictOperationIds'] == ['too-big'] and out['syncedOperationIds'] == []

            long_id = 'i' * (app.MAX_IDENTIFIER_LENGTH + 1)
            s, out = req(base + '/v1/sync/push', 'POST', {
                'businessId': 'biz-a',
                'operations': [op(long_id, 'cust-long', 'dev-a', 1, {'id': 'cust-long'})],
            }, token)
            assert s == 200 and out['conflictOperationIds'] == [long_id] and out['syncedOperationIds'] == []

            valid = op('safe-1', 'cust-safe', 'dev-a', 1, {'id': 'cust-safe', 'name': 'Safe'})
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId': 'biz-a', 'operations': [valid]}, token)
            assert s == 200 and out['syncedOperationIds'] == ['safe-1'] and not out['conflictOperationIds']
        finally:
            server.shutdown()
            server.server_close()
    print('PASS: sync payload safety contract test')


if __name__ == '__main__':
    main()
