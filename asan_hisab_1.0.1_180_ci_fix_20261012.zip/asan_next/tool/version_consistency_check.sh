#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
version="$(sed -n 's/^version: //p' pubspec.yaml | head -1)"
if [[ "${GITHUB_REF:-}" == refs/tags/v* ]]; then
  tag_version="${GITHUB_REF#refs/tags/v}"
  [[ "$tag_version" == "$version" ]] || {
    echo "FAIL: release tag version ($tag_version) does not match pubspec version ($version)" >&2
    exit 1
  }
fi
grep -Fq "Version: $version" RELEASE_MANIFEST.md || { echo "FAIL: release manifest version mismatch: $version"; exit 1; }
grep -Fq "Asan Hisab v$version" RELEASE_FINAL_GATES_v18.md || { echo "FAIL: final gates version mismatch: $version"; exit 1; }
! grep -q '^-[[:space:]]*Version: 1.0.1+6$' RELEASE_GATE.md
printf 'PASS: version consistency (%s)\n' "$version"
