#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1"; exit 1; }
grep -q "published_artifact_name" tool/release_bundle_manifest.sh || fail "manifest published artifact field missing"
grep -Fq 'name: asan-hisab-release-${{ github.ref_name }}-${{ github.run_id }}-${{ github.run_attempt }}' .github/workflows/ci.yml || fail "workflow artifact naming pattern missing"
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/build/app/outputs/bundle/release"
printf 'aab' > "$tmp/build/app/outputs/bundle/release/app-release.aab"
printf '%s  app-release.aab\n' "$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')" > "$tmp/build/app-release.aab.sha256"
VERSION="$(sed -n 's/^version: //p' pubspec.yaml | head -1)"
TAG="v${VERSION}"
AAB_SHA="$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')"
printf '{"app_version":"%s","git_commit_sha":"local","release_ref":"refs/tags/%s","release_tag":"%s","aab_sha256":"%s","workflow_run_id":"123","workflow_run_attempt":"2","workflow_name":"CI","event_name":"push","artifact_name":"app-release.aab","published_artifact_name":"asan-hisab-release-%s-123-2"}\n' "$VERSION" "$TAG" "$TAG" "$AAB_SHA" "$TAG" > "$tmp/build/release-provenance.json"
GITHUB_WORKFLOW="CI" GITHUB_EVENT_NAME="push" GITHUB_REF="refs/tags/$TAG" GITHUB_REF_NAME="$TAG" GITHUB_RUN_ID='123' GITHUB_RUN_ATTEMPT='2' PROVENANCE_PATH="$tmp/build/release-provenance.json" AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" bash tool/release_bundle_manifest.sh >/dev/null || fail "valid published artifact identity rejected"
grep -q "^published_artifact_name=asan-hisab-release-${TAG}-123-2$" "$tmp/build/release-bundle-manifest.txt" || fail "published artifact name not emitted"
# The manifest and provenance schema must share the same 128-character identity ceiling.
python3 - "$tmp/build/release-provenance.json" <<'PY2'
import json,sys
p=sys.argv[1]; o=json.load(open(p)); o['published_artifact_name']='a'*129; json.dump(o,open(p,'w'))
PY2
if GITHUB_WORKFLOW=CI GITHUB_EVENT_NAME=push GITHUB_REF="refs/tags/$TAG" GITHUB_REF_NAME="$TAG" GITHUB_RUN_ID='123' GITHUB_RUN_ATTEMPT='2' PROVENANCE_PATH="$tmp/build/release-provenance.json" AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" bash tool/release_bundle_manifest.sh >/dev/null 2>&1; then
  fail "overlong published artifact identity accepted"
fi
echo 'PASS: release bundle published artifact name contract'
