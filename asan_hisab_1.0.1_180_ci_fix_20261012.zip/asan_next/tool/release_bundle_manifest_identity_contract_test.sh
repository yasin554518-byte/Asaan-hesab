#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/build/app/outputs/bundle/release" "$tmp/tool"
printf 'version: 1.0.1+85\n' > "$tmp/pubspec.yaml"
printf 'fixture-aab' > "$tmp/build/app/outputs/bundle/release/app-release.aab"
sha="$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')"
printf '%s  app-release.aab\n' "$sha" > "$tmp/build/app-release.aab.sha256"
printf '{"app_version":"1.0.1+85","aab_sha256":"%s","release_ref":"refs/tags/v1.0.1+85","workflow_run_id":"123","workflow_run_attempt":"1","workflow_name":"CI","event_name":"push","artifact_name":"app-release.aab","published_artifact_name":"asan-hisab-release-v1.0.1+85-123-1","git_commit_sha":"0123456789abcdef0123456789abcdef01234567"}\n' "$sha" > "$tmp/build/release-provenance.json"
cp tool/release_bundle_manifest.sh "$tmp/tool/release_bundle_manifest.sh"; chmod +x "$tmp/tool/release_bundle_manifest.sh"
( cd "$tmp" && GITHUB_REF='refs/tags/v1.0.1+85' GITHUB_REF_NAME='v1.0.1+85' GITHUB_RUN_ID='123' GITHUB_RUN_ATTEMPT='1' GITHUB_WORKFLOW='CI' GITHUB_EVENT_NAME='push' GITHUB_SHA='0123456789abcdef0123456789abcdef01234567' AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" PROVENANCE_PATH="$tmp/build/release-provenance.json" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" ./tool/release_bundle_manifest.sh ) >/dev/null || fail 'valid identity fixture rejected'
python3 - "$tmp/build/release-provenance.json" <<'PY'
from pathlib import Path
import json,sys
p=Path(sys.argv[1]); o=json.loads(p.read_text()); o['release_ref']='refs/tags/v9.9.9+999'; p.write_text(json.dumps(o)+'\n')
PY
if ( cd "$tmp" && GITHUB_REF='refs/tags/v1.0.1+85' GITHUB_REF_NAME='v1.0.1+85' GITHUB_RUN_ID='123' GITHUB_RUN_ATTEMPT='1' GITHUB_WORKFLOW='CI' GITHUB_EVENT_NAME='push' GITHUB_SHA='0123456789abcdef0123456789abcdef01234567' AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" PROVENANCE_PATH="$tmp/build/release-provenance.json" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" ./tool/release_bundle_manifest.sh ) >/dev/null 2>&1; then fail 'mismatched release identity accepted'; fi
python3 - "$tmp/build/release-provenance.json" <<'PY'
from pathlib import Path
import json,sys
p=Path(sys.argv[1]); o=json.loads(p.read_text()); o['git_commit_sha']=o['git_commit_sha'].upper(); p.write_text(json.dumps(o)+'\n')
PY
if ( cd "$tmp" && GITHUB_REF='refs/tags/v1.0.1+85' GITHUB_REF_NAME='v1.0.1+85' GITHUB_RUN_ID='123' GITHUB_RUN_ATTEMPT='1' GITHUB_WORKFLOW='CI' GITHUB_EVENT_NAME='push' GITHUB_SHA='0123456789abcdef0123456789abcdef01234567' AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" PROVENANCE_PATH="$tmp/build/release-provenance.json" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" ./tool/release_bundle_manifest.sh ) >/dev/null 2>&1; then fail 'uppercase commit SHA accepted'; fi
echo 'PASS: release bundle manifest identity contract'
