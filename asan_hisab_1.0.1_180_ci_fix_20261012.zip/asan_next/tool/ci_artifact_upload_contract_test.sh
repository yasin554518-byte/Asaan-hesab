#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
fail(){ echo "FAIL: $1" >&2; exit 1; }
[[ -f "$CI" ]] || fail 'CI workflow missing'
python3 - "$CI" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1]).read_text(encoding='utf-8')
if p.count('actions/upload-artifact@v4') != 1:
    raise SystemExit('FAIL: release artifact upload must have exactly one upload-artifact step')
if 'if: startsWith(github.ref, \'refs/tags/v\')' not in p:
    raise SystemExit('FAIL: artifact upload must be release-tag gated')
if 'build/app/outputs/bundle/release/app-release.aab' not in p:
    raise SystemExit('FAIL: AAB must be included in release artifact')
if 'build/app-release.aab.sha256' not in p:
    raise SystemExit('FAIL: AAB checksum must be included in release artifact')
if 'build/release-provenance.json' not in p:
    raise SystemExit('FAIL: release provenance must be included in release artifact')
if 'name: asan-hisab-release-${{ github.ref_name }}-${{ github.run_id }}-${{ github.run_attempt }}' not in p:
    raise SystemExit('FAIL: release artifact name must include release tag, run id, and rerun attempt')
if re.search(r'actions/upload-artifact@v4\n\s+with:\n(?:\s+.*\n){0,8}\s+if:', p):
    raise SystemExit('FAIL: artifact upload gate structure is malformed')
print('PASS: CI release artifact upload contract')
PY
