#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCRIPT="$ROOT/tool/prepare_android.sh"
EXPECTED="com.asanhisab.app"
grep -Fq "EXPECTED='${EXPECTED}'" "$SCRIPT"
grep -Eq "namespace.*EXPECTED|namespace.*\$EXPECTED" "$SCRIPT"
grep -Eq "applicationId.*EXPECTED|applicationId.*\$EXPECTED" "$SCRIPT"
echo "PASS: Android prepare contract"
