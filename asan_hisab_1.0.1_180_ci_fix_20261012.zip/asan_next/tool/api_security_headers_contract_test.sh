#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
import os, tempfile, threading, urllib.request
from pathlib import Path
import sys
sys.path.insert(0, str(Path('backend').resolve()))
import app
with tempfile.TemporaryDirectory() as td:
    app.DB_PATH = os.path.join(td, 'security.sqlite3')
    os.environ['ASAN_SYNC_TOKENS'] = '[]'
    server = app.ThreadingHTTPServer(('127.0.0.1', 0), app.Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
    base = f'http://127.0.0.1:{server.server_address[1]}'
    try:
        with urllib.request.urlopen(base + '/health', timeout=5) as r:
            assert r.headers.get('Content-Security-Policy') == "default-src 'none'; frame-ancestors 'none'; base-uri 'none'"
            assert r.headers.get('Permissions-Policy') == 'camera=(), microphone=(), geolocation=()'
            assert r.headers.get('Cross-Origin-Resource-Policy') == 'same-origin'
            assert r.headers.get('X-Download-Options') == 'noopen'
            assert r.headers.get('Strict-Transport-Security') is None
        req = urllib.request.Request(base + '/health', headers={'X-Forwarded-Proto': 'https'})
        with urllib.request.urlopen(req, timeout=5) as r:
            assert r.headers.get('Strict-Transport-Security') == 'max-age=31536000; includeSubDomains'
    finally:
        server.shutdown(); server.server_close()
print('PASS: API security headers contract test')
PY
