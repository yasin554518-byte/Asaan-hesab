#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
fail(){ echo "FAIL: $1" >&2; exit 1; }

python3 - "$CI" <<'PY'
import pathlib, sys
p=pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
required="permissions:\n  contents: read"
if required not in p:
    raise SystemExit("top-level least-privilege contents permission missing")
block=p.split("concurrency:",1)[0]
if "contents: write" in block or "actions: write" in block or "packages: write" in block:
    raise SystemExit("unsafe top-level write permission detected")
PY

grep -Fq 'permissions:' "$CI" || fail 'workflow permissions block missing'
grep -Fq 'contents: read' "$CI" || fail 'read-only contents permission missing'
if grep -Fq 'contents: write' "$CI" || grep -Fq 'actions: write' "$CI" || grep -Fq 'packages: write' "$CI"; then
  fail 'unsafe workflow write permission detected'
fi

echo 'PASS: CI least-privilege permissions contract'
