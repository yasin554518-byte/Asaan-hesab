#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
import os, tempfile
from pathlib import Path
import subprocess

script = Path('tool/production_preflight.sh').resolve()

def run(text):
    with tempfile.NamedTemporaryFile('w', delete=False) as f:
        f.write(text)
        name=f.name
    try:
        return subprocess.run([str(script), name], text=True, capture_output=True)
    finally:
        Path(name).unlink(missing_ok=True)

base='ASAN_SYNC_TOKENS=[{"token":"' + 'Aa1bC2dE3fG4hI5jK6lM7nO8pQ9rS0tU1vW2' + '","businessId":"biz-1","deviceId":"dev-1"}]\n'
r=run(base + 'ASAN_SYNC_BASE_URL=https://sync.example.com\n')
assert r.returncode == 0, r.stderr + r.stdout
for bad in (
    'ASAN_SYNC_BASE_URL=http://sync.example.com\n',
    'ASAN_SYNC_BASE_URL=https://sync.example.com?x=1\n',
    'ASAN_SYNC_BASE_URL=https://user:pass@sync.example.com\n',
    'ASAN_SYNC_BASE_URL=https://localhost:8443\n',
    'ASAN_SYNC_BASE_URL=https://127.0.0.1:8443\n',
    'ASAN_SYNC_BASE_URL=https://sync.example.com\nASAN_SYNC_TOKENS=[{"token":"' + 'A'*31 + '","businessId":"biz-1","deviceId":"dev-1"}]\n',
):
    env = base + bad if 'ASAN_SYNC_TOKENS=' not in bad else bad
    r=run(env)
    assert r.returncode != 0, 'invalid production configuration was accepted: ' + bad
print('PASS: production configuration safety contract test')
PY
