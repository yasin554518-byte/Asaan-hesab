#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1"; exit 1; }
grep -q 'release_bundle_manifest.sh' .github/workflows/ci.yml || fail 'CI manifest step missing'
grep -q 'build/release-bundle-manifest.txt' .github/workflows/ci.yml || fail 'manifest upload path missing'
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/build/app/outputs/bundle/release"
printf 'version: 1.0.1+76\n' > "$tmp/pubspec.yaml"
printf 'aab-fixture' > "$tmp/build/app/outputs/bundle/release/app-release.aab"
printf '{"app_version":"1.0.1+76","aab_sha256":"%s","release_ref":"refs/tags/v1.0.1+76","workflow_run_id":"local","workflow_run_attempt":"local","workflow_name":"local","event_name":"local","artifact_name":"app-release.aab","published_artifact_name":"local","git_commit_sha":"local"}\n' "$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')" > "$tmp/build/release-provenance.json"
printf '%s  app-release.aab\n' "$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')" > "$tmp/build/app-release.aab.sha256"
mkdir -p "$tmp/tool"
cp tool/release_bundle_manifest.sh "$tmp/tool/release_bundle_manifest.sh"
chmod +x "$tmp/tool/release_bundle_manifest.sh"
( cd "$tmp" && GITHUB_WORKFLOW='local' GITHUB_EVENT_NAME='local' GITHUB_REF='refs/tags/v1.0.1+76' RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" ./tool/release_bundle_manifest.sh )
grep -q '^manifest_version=3$' "$tmp/build/release-bundle-manifest.txt" || fail 'manifest version missing'
grep -Fq "if vals['manifest_version'] != '3':" tool/release_bundle_manifest.sh || fail 'manifest version validation missing'
grep -q '^artifact_sha256=' "$tmp/build/release-bundle-manifest.txt" || fail 'artifact sha missing'
grep -Fq 'manifest artifact SHA-256 does not match the release AAB' tool/release_bundle_manifest.sh || fail 'artifact SHA/AAB consistency validation missing'
grep -q '^artifact_name=app-release.aab$' "$tmp/build/release-bundle-manifest.txt" || fail 'canonical artifact name missing'
grep -q '^artifact_size_bytes=[1-9]' "$tmp/build/release-bundle-manifest.txt" || fail 'artifact size missing'
grep -q '^release_ref=refs/tags/v1.0.1+76$' "$tmp/build/release-bundle-manifest.txt" || fail 'full release ref missing'
grep -q '^workflow_run_id=local$' "$tmp/build/release-bundle-manifest.txt" || fail 'workflow run id missing'
grep -q '^workflow_run_attempt=local$' "$tmp/build/release-bundle-manifest.txt" || fail 'workflow run attempt missing'
grep -q '^workflow_name=local$' "$tmp/build/release-bundle-manifest.txt" || fail 'workflow name missing'
grep -q '^event_name=local$' "$tmp/build/release-bundle-manifest.txt" || fail 'event name missing'
grep -q '^commit_sha=local$' "$tmp/build/release-bundle-manifest.txt" || fail 'commit sha missing'
grep -q '^checksum_file_sha256=' "$tmp/build/release-bundle-manifest.txt" || fail 'checksum file sha missing'
echo 'PASS: release bundle manifest contract'
