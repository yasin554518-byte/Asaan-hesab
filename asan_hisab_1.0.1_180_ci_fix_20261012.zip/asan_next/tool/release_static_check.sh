#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
need(){ grep -qF -- "$2" "$ROOT/$1" || fail "$1 missing: $2"; }

# Database safety
need lib/core/database/app_database.dart "PRAGMA foreign_keys = ON"
need lib/core/database/app_database.dart "PRAGMA journal_mode = WAL"
need lib/core/database/app_database.dart "PRAGMA synchronous = NORMAL"

# Money/transaction safety
need lib/shared/services/sale_service.dart "transaction"
need lib/shared/services/purchase_service.dart "transaction"
need lib/shared/services/payment_service.dart "transaction"
need lib/shared/services/expense_service.dart "transaction"
need lib/shared/services/return_service.dart "transaction"
need lib/shared/services/return_service.dart "originalItem['unit_cost']"
need lib/shared/services/return_service.dart "final normalized = <String, ReturnLineInput>{}"
need lib/shared/services/return_service.dart "Return quantity exceeds returnable quantity"
need lib/shared/services/return_service.dart "Refund exceeds return total"
need lib/shared/services/return_service.dart "SALES_RETURN_REFUND"
need lib/shared/services/return_service.dart "PURCHASE_RETURN_REFUND"

# Sync safety
need lib/core/sync/sync_worker.dart "pullAndApply"
need lib/core/sync/sync_worker.dart "pushedIds"
need lib/core/sync/sync_worker.dart "intersection(pushedIds)"
need lib/core/sync/sync_apply_service.dart "financial records are immutable"
need lib/core/sync/sync_apply_service.dart "operation_id"
need lib/core/sync/sync_apply_service.dart "_belongsToBusiness"
need lib/core/sync/sync_apply_service.dart "table == 'businesses'"
need lib/core/sync/rest_cloud_sync_adapter.dart "https://"
need lib/core/sync/sync_config_service.dart "FlutterSecureStorage"
need lib/core/sync/sync_config_service.dart "OS secure keychain/keystore"
need lib/app/app.dart "NotoNaskhArabic"
need lib/core/sync/device_service.dart "device_id_"

# Security
need lib/core/security/pin_service.dart "sha256"
need lib/core/security/permission_service.dart "UserRole { owner, manager, cashier }"
need lib/app/app.dart "controller: username"
need lib/app/app.dart "business_id = ? AND username = ? AND active = 1"
need lib/app/app.dart "SessionShell(database: widget.database, businessId: widget.businessId, role: role)"
need lib/features/home/home_shell.dart "PermissionService().can(widget.role, Permission.payments)"
need lib/features/home/home_shell.dart "can(Permission.userManagement)"
need lib/features/home/home_shell.dart "can(Permission.backup)"
need lib/features/home/home_shell.dart "can(Permission.settings)"
need lib/features/home/home_shell.dart "can(Permission.reports)"
need test/permission_service_test.dart "cashier is limited to operational permissions"
need lib/features/home/home_shell.dart "if (can(Permission.purchases))"
need lib/features/home/home_shell.dart "if (can(Permission.userManagement))"
need lib/core/security/audit_service.dart "audit_logs"
need lib/app/app.dart "with WidgetsBindingObserver"
need lib/app/app.dart "didChangeAppLifecycleState"
need lib/app/app.dart "session.lock()"

# Statements / notifications
need lib/shared/services/statement_service.dart "running_balance"
need lib/shared/services/statement_service.dart "type == 'CUSTOMER'"
need lib/shared/services/statement_service.dart "type == 'SUPPLIER'"
need lib/shared/services/notification_service.dart "final seen = <String>{}"
need lib/shared/services/notification_service.dart "severity"
need lib/features/home/home_shell.dart "final entries=await statementService.partyStatement"

# Backup / restore
need lib/core/database/backup_service.dart "integrity_check"
need lib/core/database/backup_service.dart "Copied backup failed integrity check"
need lib/core/database/app_database.dart "before_restore"
need lib/core/database/app_database.dart "Restored schema version mismatch"
need lib/features/import_export/csv_import_service.dart "previewProducts"
need lib/features/import_export/csv_import_service.dart "maximum 5 MB"
need lib/features/import_export/csv_import_service.dart "db.transaction"
need lib/features/invoice/statement_pdf_service.dart "NotoNaskhArabic-Regular.ttf"
need lib/features/invoice/statement_pdf_service.dart "PdfPageFormat.a4"

# Release documentation
need RELEASE_GATE.md "Two-device authenticated cloud sync test"
need README.md "HTTPS"

echo "PASS: Asan Hisab release static invariants"

# Payment UI must disable submission while a payment transaction is in flight.
grep -q "onPressed:saving?null:save" lib/features/home/home_shell.dart || { echo "FAIL: payment double-submit guard missing"; exit 1; }
need lib/features/home/home_shell.dart "class LoanAddPage extends StatefulWidget"
need lib/features/home/home_shell.dart "MANUAL_LOAN"
need lib/features/home/home_shell.dart "business_id = ? AND deleted_at IS NULL"
# Reports must use the actual financial schema: financial transaction tables are immutable
# and do not have deleted_at; soft-delete is limited to master entities (products/parties).
need lib/features/home/management_pages.dart "FROM sales WHERE business_id=?"
need lib/features/home/management_pages.dart "FROM purchases WHERE business_id=?"
need lib/features/home/management_pages.dart "return_type='SALE_RETURN'"
need lib/features/home/management_pages.dart "return_type='PURCHASE_RETURN'"
need lib/features/home/management_pages.dart "s.business_id=?"
need lib/features/home/management_pages.dart "r.business_id=? AND r.return_type='SALE_RETURN'"
need lib/features/home/management_pages.dart "FROM expenses WHERE business_id=?"
