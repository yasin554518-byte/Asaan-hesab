#!/usr/bin/env bash
set -euo pipefail
EXPECTED='com.asanhisab.app'
MANIFEST='android/app/src/main/AndroidManifest.xml'
GRADLE='android/app/build.gradle'
if [[ ! -f "$MANIFEST" && ! -f "$GRADLE" ]]; then
  echo 'Android project not generated yet; run tool/prepare_android.sh first.' >&2
  exit 2
fi
if ! grep -R -q "$EXPECTED" android/app; then
  echo "ERROR: expected application id $EXPECTED not found under android/app" >&2
  exit 1
fi
echo "PASS: Android application id $EXPECTED is present"
