#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILE="$ROOT/lib/core/sync/sync_scheduler.dart"
python3 - "$FILE" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
if 'Future<void> retryNow() async {' not in s:
    raise SystemExit('FAIL: retryNow() missing')
if '_consecutiveFailures = 0;' not in s[s.index('Future<void> retryNow() async {'):s.index('void start()', s.index('Future<void> retryNow() async {'))]:
    raise SystemExit('FAIL: retryNow() does not clear backoff state')
if 'await trigger();' not in s[s.index('Future<void> retryNow() async {'):s.index('void start()', s.index('Future<void> retryNow() async {'))]:
    raise SystemExit('FAIL: retryNow() does not trigger immediate sync')
if 'Object? get lastError => _lastError;' not in s:
    raise SystemExit('FAIL: lastError diagnostic missing')
if 'catch (error)' not in s or '_lastError = error;' not in s:
    raise SystemExit('FAIL: sync failure is not retained for diagnostics')
print('PASS: scheduler exposes last error and supports immediate retry')
PY
