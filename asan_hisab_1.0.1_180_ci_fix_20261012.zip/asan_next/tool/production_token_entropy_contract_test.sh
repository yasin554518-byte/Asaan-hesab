#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 - <<'PY'
import subprocess, tempfile
from pathlib import Path
script=Path('tool/production_preflight.sh').resolve()
def run(token):
    text='ASAN_SYNC_BASE_URL=https://sync.example.com\nASAN_SYNC_TOKENS=[{"token":"%s","businessId":"biz-1","deviceId":"dev-1"}]\n' % token
    with tempfile.NamedTemporaryFile('w',delete=False) as f:
        f.write(text); name=f.name
    try: return subprocess.run([str(script),name],capture_output=True,text=True)
    finally: Path(name).unlink(missing_ok=True)
good='A9f3Zx7Q2mK8vN4pR6tY1wE5sC0bH7uJ'
r=run(good); assert r.returncode==0, r.stdout+r.stderr
for bad in ('A'*48,'12345678901234567890123456789012345678','AB'*24):
    r=run(bad); assert r.returncode!=0, 'weak/repetitive token accepted: '+bad
print('PASS: production token entropy contract test')
PY
