#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
[[ -x tool/release_bundle_manifest.sh ]] || fail 'manifest helper missing'
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/build/app/outputs/bundle/release"
printf 'AAB-V88' > "$tmp/build/app/outputs/bundle/release/app-release.aab"
(cd "$tmp/build/app/outputs/bundle/release" && sha256sum app-release.aab) > "$tmp/build/app-release.aab.sha256"
VERSION="$(sed -n 's/^version: //p' pubspec.yaml | head -1)"
AAB_SHA="$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')"
printf '{"app_version":"%s","git_commit_sha":"local","release_ref":"refs/tags/v%s","release_tag":"v%s","aab_sha256":"%s","workflow_run_id":"123","workflow_run_attempt":"2","workflow_name":"CI","event_name":"push","artifact_name":"app-release.aab","published_artifact_name":"asan-hisab-release-v%s-123-2"}\n' "$VERSION" "$VERSION" "$VERSION" "$AAB_SHA" "$VERSION" > "$tmp/build/release-provenance.json"
GITHUB_WORKFLOW="CI" GITHUB_EVENT_NAME="push" GITHUB_REF="refs/tags/v$VERSION" GITHUB_REF_NAME="v$VERSION" GITHUB_RUN_ID='123' GITHUB_RUN_ATTEMPT='2' PROVENANCE_PATH="$tmp/build/release-provenance.json" AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" bash tool/release_bundle_manifest.sh >/dev/null || fail 'valid canonical path rejected'
grep -q '^artifact_relative_path=build/app/outputs/bundle/release/app-release.aab$' "$tmp/build/release-bundle-manifest.txt" || fail 'canonical artifact path not emitted'
grep -q '^checksum_relative_path=build/app-release.aab.sha256$' "$tmp/build/release-bundle-manifest.txt" || fail 'canonical checksum path not emitted'

# Reject ambiguous checksum files containing extra records.
printf '%s  app-release.aab\n%s  other.aab\n' "$AAB_SHA" "$AAB_SHA" > "$tmp/build/app-release.aab.sha256"
if GITHUB_WORKFLOW="CI" GITHUB_EVENT_NAME="push" GITHUB_REF="refs/tags/v$VERSION" GITHUB_REF_NAME="v$VERSION" GITHUB_RUN_ID='123' GITHUB_RUN_ATTEMPT='2' PROVENANCE_PATH="$tmp/build/release-provenance.json" AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/bad-checksum-manifest.txt" bash tool/release_bundle_manifest.sh >/dev/null 2>&1; then
  fail 'ambiguous checksum file accepted'
fi
# Restore the valid checksum record for any subsequent callers.
(cd "$tmp/build/app/outputs/bundle/release" && sha256sum app-release.aab) > "$tmp/build/app-release.aab.sha256"
cp "$tmp/build/release-bundle-manifest.txt" "$tmp/build/bad-manifest.txt"
sed -i 's#artifact_relative_path=build/app/outputs/bundle/release/app-release.aab#artifact_relative_path=build/other/app.aab#' "$tmp/build/bad-manifest.txt"
if grep -q '^artifact_relative_path=build/other/app.aab$' "$tmp/build/bad-manifest.txt" && grep -q '^artifact_relative_path=' "$tmp/build/bad-manifest.txt"; then :; fi
echo 'PASS: release bundle manifest canonical path contract'
