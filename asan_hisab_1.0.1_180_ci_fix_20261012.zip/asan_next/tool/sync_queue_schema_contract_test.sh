#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHEMA="$ROOT/lib/core/database/schema.dart"
DB="$ROOT/lib/core/database/app_database.dart"

grep -Fq "CREATE UNIQUE INDEX IF NOT EXISTS ux_sync_queue_operation ON sync_queue(business_id, record_id, table_name, operation, device_id, version)" "$SCHEMA"
grep -Fq "if (oldVersion < 3)" "$DB"
grep -Fq "for (final sql in migrationV3Statements)" "$DB"
grep -Fq "migrationV3Statements" "$SCHEMA"

echo "SYNC_QUEUE_SCHEMA_CONTRACT: PASS"
