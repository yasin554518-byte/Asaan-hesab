#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
python3 - "$CI" <<'PY'
from pathlib import Path
import re, sys
p=Path(sys.argv[1]).read_text(encoding="utf-8")
if p.count("actions/upload-artifact@v4") != 1:
    raise SystemExit("FAIL: expected one release artifact upload")
m=re.search(r"name:\s*asan-hisab-release-\$\{\{ github\.ref_name \}\}-\$\{\{ github\.run_id \}\}-\$\{\{ github\.run_attempt \}\}", p)
if not m:
    raise SystemExit("FAIL: release artifact name must include immutable run id")
if "github.run_id" not in p:
    raise SystemExit("FAIL: unique run id missing")
if "github.run_attempt" not in p:
    raise SystemExit("FAIL: rerun attempt discriminator missing")
if not re.search(r"overwrite:\s*false", p):
    raise SystemExit("FAIL: release artifact upload must explicitly reject overwrite")
print("PASS: CI release artifact uniqueness contract")
PY
