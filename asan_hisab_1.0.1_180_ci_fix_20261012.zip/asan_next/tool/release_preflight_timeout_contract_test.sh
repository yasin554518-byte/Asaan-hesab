#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
preflight="tool/final_release_preflight.sh"
[[ -f "$preflight" ]] || fail 'preflight script missing'
grep -Fq 'RELEASE_GATE_TIMEOUT_SECONDS="${RELEASE_GATE_TIMEOUT_SECONDS:-60}"' "$preflight" || fail 'default gate timeout missing'
grep -Fq 'RELEASE_GATE_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$' "$preflight" || fail 'positive timeout validation missing'
grep -Fq 'timeout --signal=TERM --kill-after=5s' "$preflight" || fail 'bounded timeout command missing'
grep -Fq 'release gate timed out:' "$preflight" || fail 'timeout diagnostic missing'
grep -Fq 'run_gate backend_contract_tests python3 backend/contract_test.py' "$preflight" || fail 'backend gate is not timeout-wrapped'
grep -Fq 'run_gate flutter_state_lifecycle_contract_test bash tool/flutter_state_lifecycle_contract_test.sh' "$preflight" || fail 'Flutter lifecycle gate is not timeout-wrapped'
echo 'PASS: release preflight timeout contract'
