#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCRIPT="$ROOT/tool/configure_android_signing.sh"
grep -Fq 'ANDROID_KEYSTORE_BASE64' "$SCRIPT"
grep -Fq 'key.properties' "$SCRIPT"
grep -Fq 'signingConfigs' "$SCRIPT"
grep -Fq 'chmod 600' "$SCRIPT"
grep -Fq 'keytool -list -keystore' "$SCRIPT"
grep -Fq 'injected Android release keystore/credentials are invalid' "$SCRIPT"
# Source tree must never contain actual keystore/private-key material.
if find "$ROOT" -type f \( -name '*.jks' -o -name '*.keystore' \) -print -quit | grep -q .; then
  echo 'FAIL: keystore file found in repository' >&2; exit 1
fi
if grep -RniE 'BEGIN (RSA|OPENSSH|EC|PRIVATE) KEY' "$ROOT" --exclude-dir=.git >/dev/null 2>&1; then
  echo 'FAIL: private-key material found in repository' >&2; exit 1
fi
echo 'PASS: Android signing contract checks'
