#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
need(){ grep -qF -- "$2" "$ROOT/$1" || fail "$1 missing: $2"; }

# Sale arithmetic and customer ledger direction.
need lib/shared/services/sale_service.dart "Money.remaining(total: total, paid: paid)"
need lib/shared/services/sale_service.dart "'entry_type': 'SALE', 'debit': total, 'credit': 0"
need lib/shared/services/sale_service.dart "'entry_type': 'SALE_PAYMENT', 'debit': 0, 'credit': paid"
need lib/shared/services/sale_service.dart "'transaction_type': 'SALE', 'amount': paid"

# Purchase arithmetic and supplier ledger direction.
need lib/shared/services/purchase_service.dart "Money.remaining(total: total, paid: paid)"
need lib/shared/services/purchase_service.dart "'entry_type': 'PURCHASE', 'debit': 0, 'credit': total"
need lib/shared/services/purchase_service.dart "'entry_type': 'PURCHASE_PAYMENT', 'debit': paid, 'credit': 0"
need lib/shared/services/purchase_service.dart "'transaction_type': 'PURCHASE', 'amount': paid"

# Customer receipt reduces customer debt and increases cash; supplier payment does the inverse.
need lib/shared/services/payment_service.dart "'debit': normalized == 'SUPPLIER' ? amount : 0"
need lib/shared/services/payment_service.dart "'credit': normalized == 'CUSTOMER' ? amount : 0"
need lib/shared/services/payment_service.dart "'transaction_type': normalized == 'CUSTOMER' ? 'CUSTOMER_PAYMENT' : 'SUPPLIER_PAYMENT'"
need lib/shared/services/payment_service.dart "'amount': amount * (normalized == 'CUSTOMER' ? 1 : -1)"

# Manual loan must be a customer debit and remain transactional.
need lib/features/home/home_shell.dart "db.transaction"
need lib/features/home/home_shell.dart "'entry_type': 'MANUAL_LOAN', 'debit': value, 'credit': 0"

# Financial tables are immutable transaction records; no soft-delete predicate may hide entries.
need lib/shared/services/statement_service.dart "FROM ledger_entries"
need lib/features/home/management_pages.dart "FROM sales WHERE business_id=?"
need lib/features/home/management_pages.dart "FROM purchases WHERE business_id=?"
need lib/features/home/management_pages.dart "FROM expenses WHERE business_id=?"

echo 'FINANCIAL_LEDGER_INVARIANTS_CONTRACT: PASS'
