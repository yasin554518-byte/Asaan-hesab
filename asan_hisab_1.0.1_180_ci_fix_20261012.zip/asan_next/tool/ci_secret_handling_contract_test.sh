#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
fail(){ echo "FAIL: $1" >&2; exit 1; }

# CI must never enable shell tracing while release/production secrets are in scope.
if grep -nE '(^|[[:space:]])set[[:space:]]+-x([[:space:]]|$)' "$CI" >/dev/null; then
  fail 'shell tracing (set -x) is forbidden in release workflow'
fi

# Secret expressions are allowed in env blocks, but never directly in run commands.
python3 - "$CI" <<'PY'
import pathlib, re, sys
lines = pathlib.Path(sys.argv[1]).read_text(encoding='utf-8').splitlines()
secret_re = re.compile(r'\$\{\{\s*secrets\.[A-Za-z0-9_]+\s*\}\}')
run_indent = None
for line in lines:
    if not line.strip():
        continue
    indent = len(line) - len(line.lstrip(' '))
    stripped = line.strip()
    if run_indent is not None and indent <= run_indent and not stripped.startswith('|'):
        run_indent = None
    if re.match(r'^run:', stripped):
        run_indent = indent
        if secret_re.search(stripped):
            raise SystemExit('direct GitHub secret interpolation detected in run command')
        continue
    if run_indent is not None and indent > run_indent and secret_re.search(line):
        raise SystemExit('direct GitHub secret interpolation detected in run block')

# Printing a secret variable from a run block is forbidden.
run_indent = None
for line in lines:
    if not line.strip():
        continue
    indent = len(line) - len(line.lstrip(' '))
    stripped = line.strip()
    if run_indent is not None and indent <= run_indent:
        run_indent = None
    if re.match(r'^run:', stripped):
        run_indent = indent
        continue
    if run_indent is not None and indent > run_indent:
        if re.search(r'\b(echo|printf|print)\b[^\n]*(ANDROID_KEYSTORE_BASE64|ANDROID_KEY_ALIAS|ANDROID_KEYSTORE_PASSWORD|ANDROID_KEY_PASSWORD|ASAN_PRODUCTION_BASE_URL|ASAN_PRODUCTION_TOKEN|ASAN_PRODUCTION_BUSINESS_ID|ASAN_PRODUCTION_DEVICE_ID)', stripped):
            raise SystemExit('secret variable output detected in run block')
PY

for name in \
  ANDROID_KEYSTORE_BASE64 ANDROID_KEY_ALIAS ANDROID_KEYSTORE_PASSWORD ANDROID_KEY_PASSWORD \
  ASAN_PRODUCTION_BASE_URL ASAN_PRODUCTION_TOKEN ASAN_PRODUCTION_BUSINESS_ID ASAN_PRODUCTION_DEVICE_ID; do
  grep -Fq "${name}: \${{ secrets.${name} }}" "$CI" || fail "env-based secret injection missing for ${name}"
done

echo 'PASS: CI secret handling contract'
