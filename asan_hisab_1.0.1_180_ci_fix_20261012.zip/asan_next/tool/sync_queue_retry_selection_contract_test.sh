#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILE="$ROOT/lib/core/sync/sync_queue_service.dart"

grep -F "limit: limit," "$FILE" >/dev/null
grep -F "datetime(last_attempt_at) <= datetime(" "$FILE" >/dev/null
grep -F "WHEN retry_count = 1 THEN 2" "$FILE" >/dev/null
grep -F "WHEN retry_count = 2 THEN 4" "$FILE" >/dev/null
grep -F "WHEN retry_count = 3 THEN 8" "$FILE" >/dev/null
grep -F "ELSE 16" "$FILE" >/dev/null
if grep -F "limit: limit * 2," "$FILE" >/dev/null; then
  echo "FAIL: retry selection still uses starvation-prone limit*2 prefetch" >&2
  exit 1
fi
if grep -F ").take(limit).toList()" "$FILE" >/dev/null; then
  echo "FAIL: retry eligibility is still filtered after the SQL limit" >&2
  exit 1
fi
echo "PASS: sync queue retry selection contract"
