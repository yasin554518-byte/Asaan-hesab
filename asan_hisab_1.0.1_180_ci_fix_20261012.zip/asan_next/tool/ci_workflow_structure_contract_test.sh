#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
python3 - "$CI" <<'PY'
from pathlib import Path
import re, sys
p=Path(sys.argv[1]).read_text(encoding='utf-8')
# Each checkout step must have exactly one 'with' mapping and one persist-credentials key.
checkout_blocks = re.findall(r'(?ms)^\s{6}- uses: actions/checkout@v4\n(.*?)(?=^\s{6}- |\Z)', p)
if not checkout_blocks:
    raise SystemExit('FAIL: no checkout steps found')
for i, block in enumerate(checkout_blocks, 1):
    if len(re.findall(r'^\s{8}with:\s*$', block, re.M)) != 1:
        raise SystemExit(f'FAIL: checkout step {i} must contain exactly one with mapping')
    if len(re.findall(r'^\s{10}persist-credentials:\s*false\s*$', block, re.M)) != 1:
        raise SystemExit(f'FAIL: checkout step {i} must contain exactly one persist-credentials=false key')
# Contract invocations must occur once in the source workflow to avoid accidental duplicate gates.
for needle in ['./tool/ci_checkout_security_contract_test.sh','./tool/ci_workflow_structure_contract_test.sh']:
    count=p.count(needle)
    if count != 1:
        raise SystemExit(f'FAIL: {needle} must be invoked exactly once (found {count})')
print(f'PASS: CI workflow structure ({len(checkout_blocks)} checkout steps)')
PY
