#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
need(){ grep -qF -- "$2" "$ROOT/$1" || fail "$1 missing: $2"; }
need lib/shared/services/return_service.dart "DeviceService.ensureDeviceInTransaction"
need lib/shared/services/return_service.dart "SyncQueueService.enqueueInTransactionStatic"
need lib/shared/services/return_service.dart "enqueueRows('returns'"
need lib/shared/services/return_service.dart "enqueueRows('return_items'"
need lib/shared/services/return_service.dart "enqueueRows('stock_movements'"
need lib/shared/services/return_service.dart "enqueueRows('ledger_entries'"
need lib/shared/services/return_service.dart "enqueueRows('cash_transactions'"
need lib/shared/services/return_service.dart "reference_type = ? AND reference_id = ?"
echo 'RETURN_SYNC_CONTRACT: PASS'
