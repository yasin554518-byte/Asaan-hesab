#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1"; exit 1; }
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/build/app/outputs/bundle/release" "$tmp/tool"
printf 'version: 1.0.1+82\n' > "$tmp/pubspec.yaml"
printf 'aab-fixture' > "$tmp/build/app/outputs/bundle/release/app-release.aab"
printf '{"app_version":"1.0.1+82","aab_sha256":"%s","release_ref":"local","workflow_run_id":"local","workflow_run_attempt":"local","workflow_name":"local","event_name":"local","artifact_name":"app-release.aab","published_artifact_name":"local","git_commit_sha":"local"}\n' "$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')" > "$tmp/build/release-provenance.json"
cp tool/release_bundle_manifest.sh "$tmp/tool/release_bundle_manifest.sh"
chmod +x "$tmp/tool/release_bundle_manifest.sh"
sha="$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')"
printf '%s  ../app-release.aab\n' "$sha" > "$tmp/build/app-release.aab.sha256"
if ( cd "$tmp" && AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" PROVENANCE_PATH="$tmp/build/release-provenance.json" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" ./tool/release_bundle_manifest.sh >/dev/null 2>&1 ); then
  fail 'path-traversing checksum reference was accepted'
fi
printf '%s  app-release.aab\n' "$sha" > "$tmp/build/app-release.aab.sha256"
( cd "$tmp" && AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" PROVENANCE_PATH="$tmp/build/release-provenance.json" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" ./tool/release_bundle_manifest.sh )
echo 'PASS: release checksum path safety contract'
