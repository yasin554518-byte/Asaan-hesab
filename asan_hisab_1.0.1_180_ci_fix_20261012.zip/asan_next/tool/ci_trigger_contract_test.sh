#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
grep -Fq 'tags: ["v*"]' "$CI" || { echo 'FAIL: release tag trigger missing' >&2; exit 1; }
grep -Fq 'ASAN_HISAB_REQUIRE_SIGNING' "$CI" || { echo 'FAIL: release signing gate wiring missing' >&2; exit 1; }
grep -Fq 'startsWith(github.ref, '\''refs/tags/v'\'')' "$CI" || { echo 'FAIL: release tag signing condition missing' >&2; exit 1; }
echo 'PASS: CI release-tag trigger and signing contract'
grep -Fq './tool/version_consistency_check.sh' "$CI" || { echo 'FAIL: version consistency gate missing' >&2; exit 1; }
echo 'PASS: CI version/tag consistency gate present'

grep -Fq 'Require Android release signing secrets for version tags' "$CI" || { echo 'FAIL: early release secret gate missing' >&2; exit 1; }
grep -Fq 'missing required release secret' "$CI" || { echo 'FAIL: explicit release secret validation missing' >&2; exit 1; }
echo 'PASS: early release signing-secret gate present'
