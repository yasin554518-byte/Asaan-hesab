from pathlib import Path
s = Path('lib/features/home/home_shell.dart').read_text(encoding='utf-8')
for cls in ('class _SalePageState', 'class _PurchasePageState'):
    start=s.index(cls)
    end=s.find('class ', start+len(cls))
    body=s[start:end if end!=-1 else len(s)]
    assert "if(!mounted)return;setState(()=>saving=true);" in body, f'{cls}: must guard mounted before saving setState'
    assert "if(d>gross)return msg('تخفیف له ټول مبلغ زیات دی');" in body, f'{cls}: must reject discount above gross'
    assert "if(pa>total)return msg('تادیه له ټول مبلغ زیاته ده');" in body, f'{cls}: must reject overpayment before service call'
print('PASS: sale/purchase validation and lifecycle contract')
