#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT
printf '%s\n' 'ASAN_SYNC_BASE_URL=https://sync.example.com' 'ASAN_SYNC_TOKENS=[{"token":"Aa1234567890BbCcDdEeFf0011223344556677","businessId":"biz-1","deviceId":"dev-1"}]' > "$tmp"
chmod 600 "$tmp"
bash tool/production_preflight.sh "$tmp" >/dev/null
chmod 640 "$tmp"
if bash tool/production_preflight.sh "$tmp" >/dev/null 2>&1; then
  echo 'FAIL: group-readable production env was accepted' >&2
  exit 1
fi
echo 'PASS: production env permission contract test'
