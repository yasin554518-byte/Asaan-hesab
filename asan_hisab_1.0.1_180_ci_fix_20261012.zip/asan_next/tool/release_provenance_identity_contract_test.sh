#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/build"
base='{"app_version":"1.0.1+88","git_commit_sha":"0123456789012345678901234567890123456789","release_ref":"refs/tags/v1.0.1+88","release_tag":"v1.0.1+88","aab_sha256":"0123456789012345678901234567890123456789012345678901234567890123","workflow_run_id":"1","workflow_run_attempt":"1","workflow_name":"CI","event_name":"push","artifact_name":"app-release.aab","published_artifact_name":"asan-hisab-release-v1.0.1+88-1-1"}'
printf '%s\n' "$base" > "$tmp/build/release-provenance.json"
PROVENANCE_PATH="$tmp/build/release-provenance.json" bash "$ROOT/tool/release_provenance_schema_check.sh"
python3 - "$tmp/build/release-provenance.json" <<'PY'
import json,sys
p=sys.argv[1]; o=json.load(open(p)); o['event_name']='bad space'; json.dump(o,open(p,'w'))
PY
if PROVENANCE_PATH="$tmp/build/release-provenance.json" bash "$ROOT/tool/release_provenance_schema_check.sh"; then echo 'FAIL: unsupported identity character accepted'; exit 1; fi
python3 - "$tmp/build/release-provenance.json" <<'PY'
import json,sys
p=sys.argv[1]; o=json.load(open(p)); o['event_name']='E'*201; json.dump(o,open(p,'w'))
PY
if PROVENANCE_PATH="$tmp/build/release-provenance.json" bash "$ROOT/tool/release_provenance_schema_check.sh"; then echo 'FAIL: overlong identity accepted'; exit 1; fi
python3 - "$tmp/build/release-provenance.json" <<'PY'
from pathlib import Path
p=Path(__import__('sys').argv[1])
text=p.read_text()
text=text.replace('\"event_name\":\"E\"*201', '') if False else text
# Construct a minimal valid object with a duplicate key by appending a second event_name.
text=text.rsplit('}',1)[0] + ',\"event_name\":\"push\"}'
p.write_text(text)
PY
if PROVENANCE_PATH="$tmp/build/release-provenance.json" bash "$ROOT/tool/release_provenance_schema_check.sh"; then echo 'FAIL: duplicate provenance key accepted'; exit 1; fi
python3 - "$tmp/build/release-provenance.json" <<'PY2'
import json,sys
p=sys.argv[1]
o={
  'app_version':'1.0.1+88',
  'git_commit_sha':'0123456789012345678901234567890123456789',
  'release_ref':'refs/tags/v1.0.1+88',
  'release_tag':'v1.0.1+88',
  'aab_sha256':'0123456789012345678901234567890123456789012345678901234567890123',
  'workflow_run_id':1,
  'workflow_run_attempt':'1',
  'workflow_name':'CI',
  'event_name':'push',
  'artifact_name':'app-release.aab',
  'published_artifact_name':'asan-hisab-release-v1.0.1+88-1-1'
}
json.dump(o,open(p,'w'))
PY2
if PROVENANCE_PATH="$tmp/build/release-provenance.json" bash "$ROOT/tool/release_provenance_schema_check.sh"; then echo 'FAIL: non-string workflow_run_id accepted'; exit 1; fi
echo 'PASS: release provenance identity contract'
