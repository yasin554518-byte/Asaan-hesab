#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
AAB="${AAB_PATH:-$ROOT/build/app/outputs/bundle/release/app-release.aab}"
OUT="${PROVENANCE_PATH:-$ROOT/build/release-provenance.json}"
fail(){ echo "FAIL: $1" >&2; exit 1; }
[[ -f "$AAB" ]] || fail "AAB not found: $AAB"
[[ -s "$AAB" ]] || fail "AAB is empty"
version="$(sed -n 's/^version: //p' pubspec.yaml | head -1)"
[[ -n "$version" ]] || fail "pubspec version missing"
commit="${GITHUB_SHA:-$(git rev-parse HEAD 2>/dev/null || printf '%s' 'unknown')}"
ref="${GITHUB_REF:-unknown}"
tag="${GITHUB_REF_NAME:-unknown}"
sha="$(sha256sum "$AAB" | cut -d' ' -f1)"
run_id="${GITHUB_RUN_ID:-unknown}"
run_attempt="${GITHUB_RUN_ATTEMPT:-unknown}"
workflow_name="${GITHUB_WORKFLOW:-unknown}"
event_name="${GITHUB_EVENT_NAME:-unknown}"
artifact_name="$(basename "$AAB")"
if [[ "$ref" == refs/tags/v* && -n "${GITHUB_RUN_ID:-}" && -n "${GITHUB_RUN_ATTEMPT:-}" ]]; then
  published_artifact_name="asan-hisab-release-${GITHUB_REF_NAME}-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}"
else
  published_artifact_name="local"
fi
mkdir -p "$(dirname "$OUT")"
python3 - "$OUT" "$version" "$commit" "$ref" "$tag" "$sha" "$run_id" "$run_attempt" "$workflow_name" "$event_name" "$artifact_name" "$published_artifact_name" <<'PY'
import json,sys
out,version,commit,ref,tag,sha,run_id,run_attempt,workflow_name,event_name,artifact_name,published_artifact_name=sys.argv[1:]
obj={
  "app_version": version,
  "git_commit_sha": commit,
  "release_ref": ref,
  "release_tag": tag,
  "aab_sha256": sha,
  "workflow_run_id": run_id,
  "workflow_run_attempt": run_attempt,
  "workflow_name": workflow_name,
  "event_name": event_name,
  "artifact_name": artifact_name,
  "published_artifact_name": published_artifact_name,
}
with open(out,'w',encoding='utf-8') as f:
    json.dump(obj,f,indent=2,sort_keys=True)
    f.write('\n')
PY
python3 - "$OUT" "$sha" "$version" "$run_id" "$run_attempt" "$workflow_name" "$event_name" "$artifact_name" "$published_artifact_name" <<'PY'
import json,sys
obj=json.load(open(sys.argv[1],encoding='utf-8'))
assert obj['aab_sha256']==sys.argv[2]
assert obj['app_version']==sys.argv[3]
assert obj['workflow_run_id']==sys.argv[4]
assert obj['workflow_run_attempt']==sys.argv[5]
for forbidden in ('password','private_key','keystore','secret','token'):
    assert forbidden not in json.dumps(obj).lower(), forbidden
PY
echo "PASS: release provenance ($version, $sha)"
