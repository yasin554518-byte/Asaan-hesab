#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
need(){ grep -qF -- "$2" "$ROOT/$1" || fail "$1 missing: $2"; }
need lib/core/utils/ledger_balance.dart "class LedgerBalance"
need lib/core/utils/ledger_balance.dart "balance + debit - credit"
need lib/core/utils/ledger_balance.dart "balance + credit - debit"
need lib/core/utils/ledger_balance.dart "Ledger amounts cannot be negative"
need lib/core/utils/ledger_balance.dart "A ledger entry cannot contain both debit and credit"
need lib/shared/services/statement_service.dart "LedgerBalance.apply"
need test/ledger_balance_contract_test.dart "customer debt increases on debit"
need test/ledger_balance_contract_test.dart "supplier balance increases on credit"
echo 'LEDGER_BALANCE_CONTRACT: PASS'
