#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $*" >&2; exit 1; }
grep -Fq "followLinks: false" lib/features/home/home_shell.dart || fail 'backup discovery must not follow symlinks'
grep -Fq "asan_hisab_backup_" lib/features/home/home_shell.dart || fail 'canonical backup prefix missing'
grep -Fq "Future<void> _loadLatestBackup()" lib/features/home/home_shell.dart || fail 'latest backup discovery missing'
grep -Fq "await _loadLatestBackup();" lib/features/home/home_shell.dart || fail 'restore must refresh latest backup'
printf 'PASS: latest backup discovery contract\n'
