#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
fail(){ echo "FAIL: $1" >&2; exit 1; }
[[ -f "$CI" ]] || fail 'CI workflow missing'
python3 - "$CI" <<'PY'
from pathlib import Path
import re, sys
p=Path(sys.argv[1]).read_text(encoding='utf-8')
blocks=re.findall(r'uses:\s*actions/upload-artifact@v4\n(?P<body>(?:\s+.*\n)+?)(?=\n\S|\Z)', p)
if len(blocks) != 1:
    raise SystemExit('FAIL: expected exactly one upload-artifact block')
body=blocks[0]
if not re.search(r'^\s*if-no-files-found:\s*error\s*$', body, re.M):
    raise SystemExit('FAIL: release artifact upload must fail when expected files are missing')
print('PASS: CI release artifact completeness contract')
PY
