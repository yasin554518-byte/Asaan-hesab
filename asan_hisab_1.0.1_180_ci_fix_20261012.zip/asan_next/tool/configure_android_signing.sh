#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ANDROID="$ROOT/android"
PROPS="$ANDROID/key.properties"
KEYSTORE="$ANDROID/upload-keystore.jks"

if [[ -z "${ANDROID_KEYSTORE_BASE64:-}" ]]; then
  echo "INFO: Android signing secrets not provided; leaving release build unsigned."
  exit 0
fi
for v in ANDROID_KEYSTORE_BASE64 ANDROID_KEY_ALIAS ANDROID_KEYSTORE_PASSWORD ANDROID_KEY_PASSWORD; do
  [[ -n "${!v:-}" ]] || { echo "FAIL: missing Android signing secret $v" >&2; exit 1; }
done
mkdir -p "$ANDROID"
printf '%s' "$ANDROID_KEYSTORE_BASE64" | base64 --decode > "$KEYSTORE"
cat > "$PROPS" <<EOF_PROPS
storeFile=upload-keystore.jks
storePassword=${ANDROID_KEYSTORE_PASSWORD}
keyPassword=${ANDROID_KEY_PASSWORD}
keyAlias=${ANDROID_KEY_ALIAS}
EOF_PROPS
chmod 600 "$KEYSTORE" "$PROPS"

# Fail before Flutter/Gradle build if the injected keystore is malformed.
command -v keytool >/dev/null 2>&1 || { echo 'FAIL: keytool is required to validate release keystore.' >&2; exit 1; }
keytool -list -keystore "$KEYSTORE" -storepass "$ANDROID_KEYSTORE_PASSWORD" -alias "$ANDROID_KEY_ALIAS" >/dev/null || {
  echo 'FAIL: injected Android release keystore/credentials are invalid.' >&2
  exit 1
}

G="$ANDROID/app/build.gradle"
K="$ANDROID/app/build.gradle.kts"
if [[ -f "$G" ]]; then
  python - "$G" <<'PY2'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
if 'keystorePropertiesFile' not in s:
    s='''\n// Asan Hisab release signing; credentials are injected by CI and never committed.\ndef keystoreProperties = new Properties()\ndef keystorePropertiesFile = rootProject.file("key.properties")\nif (keystorePropertiesFile.exists()) {\n    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))\n}\n''' + s
block='''\n\n// Production upload signing configuration.\nandroid {\n    signingConfigs {\n        release {\n            keyAlias keystoreProperties['keyAlias']\n            keyPassword keystoreProperties['keyPassword']\n            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null\n            storePassword keystoreProperties['storePassword']\n        }\n    }\n    buildTypes {\n        release {\n            signingConfig signingConfigs.release\n        }\n    }\n}\n'''
if 'signingConfig signingConfigs.release' not in s:
    s += block
p.write_text(s)
PY2
elif [[ -f "$K" ]]; then
  python - "$K" <<'PY2'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
if 'keystorePropertiesFile' not in s:
    s='''\n// Asan Hisab release signing; credentials are injected by CI and never committed.\nval keystoreProperties = java.util.Properties()\nval keystorePropertiesFile = rootProject.file("key.properties")\nif (keystorePropertiesFile.exists()) {\n    keystoreProperties.load(java.io.FileInputStream(keystorePropertiesFile))\n}\n''' + s
block='''\n\nandroid {\n    signingConfigs {\n        create("release") {\n            keyAlias = keystoreProperties["keyAlias"] as String\n            keyPassword = keystoreProperties["keyPassword"] as String\n            storeFile = file(keystoreProperties["storeFile"] as String)\n            storePassword = keystoreProperties["storePassword"] as String\n        }\n    }\n    buildTypes {\n        getByName("release") {\n            signingConfig = signingConfigs.getByName("release")\n        }\n    }\n}\n'''
if 'signingConfig = signingConfigs.getByName("release")' not in s:
    s += block
p.write_text(s)
PY2
else
  echo "FAIL: no Android app Gradle file found" >&2
  exit 1
fi
