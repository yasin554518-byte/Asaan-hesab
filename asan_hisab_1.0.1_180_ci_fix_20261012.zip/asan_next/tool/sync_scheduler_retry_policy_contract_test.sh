#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SCHED="$ROOT/lib/core/sync/sync_scheduler.dart"
QUEUE="$ROOT/lib/core/sync/sync_queue_service.dart"
python3 - "$SCHED" "$QUEUE" <<'PY'
from pathlib import Path
import sys
sched = Path(sys.argv[1]).read_text()
queue = Path(sys.argv[2]).read_text()
if 'SyncQueueService.retryDelayMinutes(consecutiveFailures - 1)' not in sched:
    raise SystemExit('FAIL: scheduler retry policy is not delegated to durable queue policy')
if 'Duration retryDelay(int consecutiveFailures)' not in sched:
    raise SystemExit('FAIL: scheduler retry policy contract helper missing')
for n, expected in [(0,1),(1,2),(2,4),(3,8),(4,16)]:
    marker = f'case {n}'
# Verify the durable policy remains bounded 1/2/4/8/16 minutes.
if '(1 << exponent).clamp(1, 30).toInt()' not in queue:
    raise SystemExit('FAIL: durable queue retry policy implementation missing')
print('PASS: scheduler retry policy is delegated to 1/2/4/8/16-minute durable queue policy')
PY
