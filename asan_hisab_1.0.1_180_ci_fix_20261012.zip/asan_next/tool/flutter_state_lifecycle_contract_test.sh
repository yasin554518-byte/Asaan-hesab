#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 - "$ROOT/lib/features/home/home_shell.dart" <<'PY'
import re, sys
from pathlib import Path
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
# Lightweight brace-aware class extraction: enough to catch duplicate lifecycle
# methods without requiring a Flutter/Dart SDK in release-preflight environments.
classes = []
for m in re.finditer(r'class\s+(\w+)\s+extends\s+State<[^>]+>\s*\{', s):
    start = m.end(); depth = 1; i = start
    while i < len(s) and depth:
        if s[i] == '{': depth += 1
        elif s[i] == '}': depth -= 1
        i += 1
    classes.append((m.group(1), s[start:i-1]))
for name, body in classes:
    count = len(re.findall(r'\bvoid\s+initState\s*\(\s*\)', body))
    if count > 1:
        raise SystemExit(f'FAIL: {name} declares initState {count} times')
# Backup discovery belongs only to the backup page state. A stray call in another
# Stateful page is a compile-time error because the method is not in scope.
for name, body in classes:
    if name != '_BackupPageState' and '_loadLatestBackup(' in body:
        raise SystemExit(f'FAIL: {name} references _loadLatestBackup outside BackupPage')
print('PASS: Flutter Stateful lifecycle contract')
PY
