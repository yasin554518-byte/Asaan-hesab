#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1"; exit 1; }
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/build/app/outputs/bundle/release" "$tmp/tool"
printf 'version: 1.0.1+76\n' > "$tmp/pubspec.yaml"
printf 'aab-fixture' > "$tmp/build/app/outputs/bundle/release/app-release.aab"
sha="$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')"
printf '%s  app-release.aab\n' "$sha" > "$tmp/build/app-release.aab.sha256"
printf '{"app_version":"1.0.1+76","aab_sha256":"%s","release_ref":"local","workflow_run_id":"local","workflow_run_attempt":"local","workflow_name":"local","event_name":"local","artifact_name":"app-release.aab","published_artifact_name":"local","git_commit_sha":"local"}\n' "$sha" > "$tmp/build/release-provenance.json"
cp tool/release_bundle_manifest.sh "$tmp/tool/release_bundle_manifest.sh"; chmod +x "$tmp/tool/release_bundle_manifest.sh"
( cd "$tmp" && GITHUB_WORKFLOW='local' GITHUB_EVENT_NAME='local' GITHUB_REF='local' RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" ./tool/release_bundle_manifest.sh ) >/dev/null || fail 'valid metadata rejected'
if ( cd "$tmp" && GITHUB_WORKFLOW=$'local\nINJECTED' GITHUB_EVENT_NAME='local' GITHUB_REF='local' RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/bad.txt" ./tool/release_bundle_manifest.sh ) >/dev/null 2>&1; then
  fail 'control-character metadata accepted'
fi
# Release inputs must be regular files, not symlinks, to keep provenance bound to the uploaded bytes.
ln -s "$tmp/build/app/outputs/bundle/release/app-release.aab" "$tmp/build/app/outputs/bundle/release/aab-link.aab"
if ( cd "$tmp" && AAB_PATH="$tmp/build/app/outputs/bundle/release/aab-link.aab" GITHUB_WORKFLOW='local' GITHUB_EVENT_NAME='local' GITHUB_REF='local' RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/symlink.txt" ./tool/release_bundle_manifest.sh ) >/dev/null 2>&1; then
  fail 'symlinked AAB accepted'
fi
echo 'PASS: release bundle manifest metadata safety contract'
