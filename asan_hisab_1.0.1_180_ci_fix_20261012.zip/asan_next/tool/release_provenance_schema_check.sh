#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILE="${PROVENANCE_PATH:-$ROOT/build/release-provenance.json}"
[[ -f "$FILE" ]] || { echo "FAIL: provenance file missing: $FILE" >&2; exit 1; }
python3 - "$FILE" <<'PY'
import hashlib, json, re, sys
p=sys.argv[1]
def reject_duplicate_keys(pairs):
    obj={}
    for key, value in pairs:
        if key in obj:
            raise SystemExit(f'FAIL: duplicate provenance key: {key}')
        obj[key]=value
    return obj
with open(p, encoding='utf-8') as f:
    obj=json.load(f, object_pairs_hook=reject_duplicate_keys)
required={'app_version','git_commit_sha','release_ref','release_tag','aab_sha256','workflow_run_id','workflow_run_attempt','workflow_name','event_name','artifact_name','published_artifact_name'}
if set(obj) != required:
    raise SystemExit(f'FAIL: provenance schema keys mismatch: {sorted(obj)}')
if not isinstance(obj['app_version'], str) or not re.fullmatch(r'\d+\.\d+\.\d+\+\d+', obj['app_version']):
    raise SystemExit('FAIL: invalid app_version')
if not isinstance(obj['git_commit_sha'], str) or not re.fullmatch(r'[0-9a-f]{40}|local', obj['git_commit_sha']):
    raise SystemExit('FAIL: invalid git_commit_sha')
if not isinstance(obj['release_ref'], str) or not re.fullmatch(r'refs/tags/v\d+\.\d+\.\d+\+\d+', obj['release_ref']):
    raise SystemExit('FAIL: release_ref must be an exact semantic version tag ref')
if not isinstance(obj['release_tag'], str) or obj['release_tag'] != obj['release_ref'].split('/')[-1]:
    raise SystemExit('FAIL: release_tag/ref mismatch')
if obj['release_tag'] != 'v' + obj['app_version']:
    raise SystemExit('FAIL: release_tag must match app_version')
if not isinstance(obj['workflow_run_id'], str) or not re.fullmatch(r'[1-9][0-9]*|local', obj['workflow_run_id']):
    raise SystemExit('FAIL: invalid workflow_run_id')
if not isinstance(obj['workflow_run_attempt'], str) or not re.fullmatch(r'[1-9][0-9]*|local', obj['workflow_run_attempt']):
    raise SystemExit('FAIL: invalid workflow_run_attempt')
for key in ('workflow_name','event_name','artifact_name','published_artifact_name'):
    if not isinstance(obj[key], str) or not obj[key]:
        raise SystemExit(f'FAIL: {key} missing')
if any(any(ord(ch) < 32 or ord(ch) == 127 for ch in obj[key]) for key in ('workflow_name','event_name','artifact_name','published_artifact_name')):
    raise SystemExit('FAIL: provenance identity contains control characters')
for key in ('workflow_name','event_name','artifact_name','published_artifact_name'):
    if len(obj[key]) > 128:
        raise SystemExit(f'FAIL: {key} exceeds 128 characters')
    if obj[key] != 'local' and not re.fullmatch(r'[A-Za-z0-9._+/@:-]+', obj[key]):
        raise SystemExit(f'FAIL: {key} contains unsupported identity characters')
if obj['artifact_name'] != 'app-release.aab':
    raise SystemExit('FAIL: artifact_name must be app-release.aab')
if obj['published_artifact_name'] != 'local':
    expected=f"asan-hisab-release-{obj['release_tag']}-{obj['workflow_run_id']}-{obj['workflow_run_attempt']}"
    if obj['published_artifact_name'] != expected:
        raise SystemExit('FAIL: published artifact identity mismatch')
if not re.fullmatch(r'[0-9a-f]{64}', obj['aab_sha256']):
    raise SystemExit('FAIL: invalid AAB SHA-256')
text=json.dumps(obj, sort_keys=True).lower()
for forbidden in ('password','private_key','keystore','secret','token'):
    if forbidden in text:
        raise SystemExit(f'FAIL: forbidden secret-like field/content: {forbidden}')
print('PASS: release provenance schema')
PY
