#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

for required in 'backend/.env' 'android/key.properties' 'android/*.jks' 'android/*.keystore'; do
  grep -Fq "$required" .gitignore || {
    echo "FAIL: .gitignore missing secret protection for $required" >&2
    exit 1
  }
done

if find . -path './.git' -prune -o -type f \( -name '*.jks' -o -name '*.keystore' \) -print | grep -q .; then
  echo 'FAIL: signing keystore material is present in the source tree' >&2
  exit 1
fi

if [[ -f backend/.env ]]; then
  echo 'FAIL: backend/.env must never be committed in a release source tree' >&2
  exit 1
fi

if [[ -f android/key.properties ]]; then
  echo 'FAIL: android/key.properties must never be committed in a release source tree' >&2
  exit 1
fi

echo 'PASS: secret-material source-tree protection'
