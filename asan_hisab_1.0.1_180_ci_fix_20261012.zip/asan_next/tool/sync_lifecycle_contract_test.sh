#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 - "$ROOT/lib/app/app.dart" "$ROOT/lib/core/sync/sync_scheduler.dart" <<'PY'
import re, sys
from pathlib import Path
app = Path(sys.argv[1]).read_text(encoding='utf-8')
sched = Path(sys.argv[2]).read_text(encoding='utf-8')
if 'with WidgetsBindingObserver' not in app:
    raise SystemExit('FAIL: SessionShell is not a lifecycle observer')
if '_syncScheduler.pause();' not in app or '_syncScheduler.resume();' not in app:
    raise SystemExit('FAIL: app lifecycle does not explicitly pause/resume sync scheduler')
if 'bool _paused = false;' not in sched:
    raise SystemExit('FAIL: scheduler has no paused state')
if 'void pause()' not in sched or 'void resume(' not in sched:
    raise SystemExit('FAIL: scheduler pause/resume API missing')
if not re.search(r'if \(_disposed \|\| _paused \|\| _running\) return;', sched):
    raise SystemExit('FAIL: trigger/retry path does not honor paused state')
print('PASS: sync lifecycle contract')
PY
