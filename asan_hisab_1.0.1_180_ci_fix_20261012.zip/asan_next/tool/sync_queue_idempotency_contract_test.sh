#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
file="lib/core/sync/sync_queue_service.dart"
src="$(cat "$file")"
grep -Fq "conflictAlgorithm: ConflictAlgorithm.ignore" "$file" || { echo 'FAIL: enqueue is not conflict-safe'; exit 1; }
grep -Fq "where: 'business_id = ? AND record_id = ? AND table_name = ? AND operation = ? AND device_id = ? AND version = ?'" "$file" || { echo 'FAIL: canonical operation lookup missing'; exit 1; }
count=$(grep -Fc "where: 'business_id = ? AND record_id = ? AND table_name = ? AND operation = ? AND device_id = ? AND version = ?'" "$file")
[ "$count" -ge 2 ] || { echo 'FAIL: canonical lookup must occur before and after insert'; exit 1; }
grep -Fq "return canonical.first['id'] as String;" "$file" || { echo 'FAIL: canonical id return missing'; exit 1; }
grep -Fq "CREATE UNIQUE INDEX IF NOT EXISTS ux_sync_queue_operation" lib/core/database/schema.dart || { echo 'FAIL: unique sync operation index missing'; exit 1; }
echo 'PASS: sync queue enqueue idempotency/race contract'
