#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
fail(){ echo "FAIL: $1" >&2; exit 1; }
[[ -f "$CI" ]] || fail 'CI workflow missing'
python3 - "$CI" <<'PY2'
from pathlib import Path
import re, sys
p=Path(sys.argv[1]).read_text(encoding='utf-8')
for label in ('Require Android release signing secrets for version tags','Release provenance','Release provenance schema gate','AAB checksum','Upload AAB'):
    m=re.search(r'- name: '+re.escape(label)+r'\n(?P<body>(?:\s+.*\n)*?)(?=\n\s*- name:|\n\S|\Z)', p)
    if not m:
        raise SystemExit(f'FAIL: missing CI step: {label}')
    if "if: startsWith(github.ref, 'refs/tags/v')" not in m.group('body'):
        raise SystemExit(f'FAIL: {label} must be tag-only')
if not re.search(r'name:\s+asan-hisab-release-\$\{\{ github\.ref_name \}\}', p):
    raise SystemExit('FAIL: release artifact name must include github.ref_name')
if not re.search(r"production-smoke:\n\s+if: startsWith\(github.ref, 'refs/tags/v'\)\n\s+needs: \[flutter, backend\]", p):
    raise SystemExit('FAIL: production smoke trigger/dependencies are unsafe')
print('PASS: CI release trigger safety contract')
PY2
