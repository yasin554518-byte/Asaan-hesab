#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail(){ echo "FAIL: $*" >&2; exit 1; }
need(){ grep -Fq "$2" "$1" || fail "$1 missing required restore safety invariant: $2"; }

[[ -f lib/core/database/backup_service.dart ]] || fail 'backup service missing'
[[ -f lib/core/database/app_database.dart ]] || fail 'database service missing'
[[ -x deploy/verify_backup.sh ]] || fail 'backup verifier missing or not executable'

# The live DB must be protected before replacement and the safety copy must only
# be removed after the reopened replacement has passed integrity/schema checks.
need lib/core/database/app_database.dart "final safety = File('\${path}.before_restore')"
need lib/core/database/app_database.dart "await current.copy(safety.path)"
need lib/core/database/app_database.dart "if (await wal.exists()) await wal.delete();"
need lib/core/database/app_database.dart "if (await shm.exists()) await shm.delete();"
need lib/core/database/app_database.dart "final reopened = await _openDatabase(path);"
need lib/core/database/app_database.dart "PRAGMA integrity_check"
need lib/core/database/app_database.dart "Restored schema version mismatch"
need lib/core/database/app_database.dart "if (await safety.exists()) await safety.delete();"
need lib/core/database/app_database.dart "if (await safety.exists()) {"
need lib/core/database/app_database.dart "await safety.copy(path);"

# The restore service must verify the backup before replacement and verify the
# live DB again after replacement.
need lib/core/database/backup_service.dart "Backup integrity check failed"
need lib/core/database/backup_service.dart "Backup schema version"
need lib/core/database/backup_service.dart "await database.replaceDatabaseFile(backup.path);"
need lib/core/database/backup_service.dart "Restored database integrity check failed"

# Run a real verifier against a temporary valid SQLite backup, then prove that
# a checksum-tampered backup is rejected. This does not require Flutter.
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
python3 - "$tmp" <<'PY'
import sqlite3, pathlib, hashlib, sys
root=pathlib.Path(sys.argv[1])
db=root/'asan_sync_test.sqlite3'
con=sqlite3.connect(db)
con.execute('PRAGMA user_version=4')
con.execute('CREATE TABLE auth_devices(id TEXT PRIMARY KEY)')
con.execute('CREATE TABLE operations(operation_id TEXT PRIMARY KEY)')
con.execute('INSERT INTO auth_devices VALUES (\'device-1\')')
con.commit(); con.close()
h=hashlib.sha256(db.read_bytes()).hexdigest()
(db.with_name(db.name+'.sha256')).write_text(f'{h}  {db.name}\n')
PY
./deploy/verify_backup.sh "$tmp/asan_sync_test.sqlite3" | grep -q 'PASS: backup checksum and SQLite integrity verification' || fail 'valid backup verifier smoke failed'
printf 'x' >> "$tmp/asan_sync_test.sqlite3"
if ./deploy/verify_backup.sh "$tmp/asan_sync_test.sqlite3" >/dev/null 2>&1; then
  fail 'tampered backup was accepted'
fi
printf 'PASS: backup restore/recovery contract and verifier smoke\n'
