#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }

# CI must publish exactly the three release bundle artifacts.
grep -q 'build/app/outputs/bundle/release/app-release.aab' .github/workflows/ci.yml || fail 'AAB artifact path missing'
grep -q 'build/app-release.aab.sha256' .github/workflows/ci.yml || fail 'AAB checksum path missing'
grep -q 'build/release-provenance.json' .github/workflows/ci.yml || fail 'provenance path missing'

# A checksum file must contain one canonical SHA-256 line for the AAB.
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
printf 'asan-hisab-release-fixture-v62\n' > "$tmp/app-release.aab"
sha256sum "$tmp/app-release.aab" > "$tmp/app-release.aab.sha256"
python3 - "$tmp/app-release.aab" "$tmp/app-release.aab.sha256" <<'PY'
import hashlib, pathlib, re, sys
artifact=pathlib.Path(sys.argv[1])
checksum=pathlib.Path(sys.argv[2]).read_text(encoding='utf-8').strip()
m=re.fullmatch(r'([0-9a-f]{64})  (.+)', checksum)
if not m:
    raise SystemExit('checksum file is not canonical SHA-256 format')
if pathlib.Path(m.group(2)).name != artifact.name:
    raise SystemExit('checksum does not name the expected AAB')
actual=hashlib.sha256(artifact.read_bytes()).hexdigest()
if m.group(1) != actual:
    raise SystemExit('checksum does not match AAB')
PY

# Release bundle must not contain obvious secrets or extra executable payloads.
for name in .env .env.production keystore.jks upload-keystore.jks release-key.jks; do
  [[ ! -e "$tmp/$name" ]] || fail "secret/signing material present in bundle fixture: $name"
done

# Version must be derived from the current source, never hard-coded in the contract.
VERSION="$(sed -n 's/^version: //p' pubspec.yaml | head -1)"
grep -q "^version: ${VERSION}$" pubspec.yaml || fail 'pubspec version mismatch'
grep -q "Version: ${VERSION}" RELEASE_MANIFEST.md || fail 'release manifest version mismatch'

echo 'PASS: release bundle integrity contract'
