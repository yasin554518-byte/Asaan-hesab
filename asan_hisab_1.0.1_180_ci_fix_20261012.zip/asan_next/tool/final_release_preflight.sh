#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPYCACHEPREFIX="${PYTHONPYCACHEPREFIX:-/tmp/asan_hisab_pycache}"
rm -rf "$PYTHONPYCACHEPREFIX"
cleanup_release_caches(){
  rm -rf "$ROOT/__pycache__" "$ROOT/backend/__pycache__" "$ROOT/tool/__pycache__"
}
trap cleanup_release_caches EXIT

RELEASE_GATE_TIMEOUT_SECONDS="${RELEASE_GATE_TIMEOUT_SECONDS:-60}"
run_gate(){
  local label="$1"; shift
  if ! [[ "$RELEASE_GATE_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]]; then
    echo "FAIL: RELEASE_GATE_TIMEOUT_SECONDS must be a positive integer" >&2
    exit 1
  fi
  echo "RUN: release gate: $label"
  local rc=0
  if timeout --signal=TERM --kill-after=5s "${RELEASE_GATE_TIMEOUT_SECONDS}s" "$@"; then
    return 0
  else
    rc=$?
    if [[ $rc -eq 124 || $rc -eq 137 ]]; then
      echo "FAIL: release gate timed out: $label (limit ${RELEASE_GATE_TIMEOUT_SECONDS}s)" >&2
    else
      echo "FAIL: release gate failed: $label (exit $rc)" >&2
    fi
    exit "$rc"
  fi
}

run_gate release_preflight_timeout_contract_test bash tool/release_preflight_timeout_contract_test.sh
run_gate version_consistency bash tool/version_consistency_check.sh
run_gate smoke_check bash tool/smoke_check.sh
run_gate release_static_check bash tool/release_static_check.sh
run_gate release_bundle_manifest_contract_test bash tool/release_bundle_manifest_contract_test.sh
run_gate release_bundle_manifest_identity_contract_test bash tool/release_bundle_manifest_identity_contract_test.sh
run_gate release_bundle_manifest_metadata_safety_contract_test bash tool/release_bundle_manifest_metadata_safety_contract_test.sh
run_gate release_checksum_path_safety_contract_test bash tool/release_checksum_path_safety_contract_test.sh
run_gate release_checksum_generation_contract_test bash tool/release_checksum_generation_contract_test.sh
run_gate release_tag_integrity_contract_test bash tool/release_tag_integrity_contract_test.sh
cleanup_release_caches
if [[ -d android ]]; then
  bash tool/verify_android_application_id.sh
else
  echo "SKIP: Android host project not generated (Flutter SDK required)"
fi
run_gate release_candidate_check bash tool/release_candidate_check.sh
run_gate sync_scheduler_error_propagation_contract_test bash tool/sync_scheduler_error_propagation_contract_test.sh
run_gate backup_restore_live_path_contract_test bash tool/backup_restore_live_path_contract_test.sh
run_gate sync_worker_push_failure_contract_test bash tool/sync_worker_push_failure_contract_test.sh
run_gate sync_queue_retry_selection_contract_test bash tool/sync_queue_retry_selection_contract_test.sh
run_gate sync_scheduler_retry_policy_contract_test bash tool/sync_scheduler_retry_policy_contract_test.sh
run_gate flutter_state_lifecycle_contract_test bash tool/flutter_state_lifecycle_contract_test.sh
run_gate backend_compile python3 -c "import py_compile; [py_compile.compile(src, cfile='/tmp/asan_hisab_preflight_compile.pyc', doraise=True) for src in ('backend/app.py', 'backend/contract_test.py')]"
rm -f /tmp/asan_hisab_preflight_compile.pyc
run_gate backend_contract_tests python3 backend/contract_test.py
if [[ -f "$ROOT/backend/.env" ]]; then
  run_gate production_preflight bash tool/production_preflight.sh "$ROOT/backend/.env"
else
  echo 'SKIP: production env not present (expected until deployment)'
fi
printf '%s\n' 'PASS: final release preflight (automated gates)'
