#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1"; exit 1; }
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
cp tool/release_provenance_schema_check.sh "$tmp/schema.sh"
chmod +x "$tmp/schema.sh"
cat > "$tmp/valid.json" <<'JSON'
{"app_version":"1.0.1+110","git_commit_sha":"local","release_ref":"refs/tags/v1.0.1+110","release_tag":"v1.0.1+110","aab_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","workflow_run_id":"12345","workflow_run_attempt":"2","workflow_name":"CI","event_name":"push","artifact_name":"app-release.aab","published_artifact_name":"asan-hisab-release-v1.0.1+110-12345-2"}
JSON
PROVENANCE_PATH="$tmp/valid.json" "$tmp/schema.sh" >/dev/null
python3 - <<'PY' "$tmp"
from pathlib import Path
import json,sys
root=Path(sys.argv[1])
obj=json.loads((root/'valid.json').read_text())
for field in ('workflow_run_id','workflow_run_attempt'):
    obj[field]='0'
    (root/f'{field}.json').write_text(json.dumps(obj))
PY
for f in workflow_run_id workflow_run_attempt; do
  if PROVENANCE_PATH="$tmp/$f.json" "$tmp/schema.sh" >/dev/null 2>&1; then fail "zero $f was accepted"; fi
done
for f in workflow_run_id workflow_run_attempt; do
  python3 - <<'PY' "$tmp/$f.json" "$f"
from pathlib import Path
import json,sys
p=Path(sys.argv[1]); field=sys.argv[2]
o=json.loads(p.read_text()); o[field]='0123'; p.write_text(json.dumps(o))
PY
  if PROVENANCE_PATH="$tmp/$f.json" "$tmp/schema.sh" >/dev/null 2>&1; then fail "leading-zero $f was accepted"; fi
done
echo 'PASS: release provenance run identity canonical contract'
