#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FILE="$ROOT/lib/app/app.dart"
python3 - "$FILE" <<'PY'
import re, sys
p=sys.argv[1]
s=open(p, encoding='utf-8').read()
m=re.search(r'Future<void> _runAutoSync\(\) async \{(.*?)\n  \}\n\n  @override\n  void didChangeAppLifecycleState', s, re.S)
if not m:
    raise SystemExit('FAIL: _runAutoSync block not found')
body=m.group(1)
if re.search(r'catch\s*\(', body):
    raise SystemExit('FAIL: _runAutoSync swallows errors; scheduler backoff cannot observe failures')
if 'SyncWorker(widget.database, adapter).run(widget.businessId)' not in body:
    raise SystemExit('FAIL: _runAutoSync no longer invokes SyncWorker')
print('PASS: sync scheduler observes auto-sync failures')
PY
