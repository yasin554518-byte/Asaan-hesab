#!/usr/bin/env python3
"""Two-device offline/replay/cursor sync contract test using the real backend Handler."""
import json
import os
import tempfile
import threading
import urllib.error
import urllib.request
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'backend'))
import app


def req(url, method='GET', payload=None, token=None):
    data = None if payload is None else json.dumps(payload).encode()
    headers = {}
    if payload is not None:
        headers['Content-Type'] = 'application/json'
    if token:
        headers['Authorization'] = 'Bearer ' + token
    r = urllib.request.Request(url, data=data, method=method, headers=headers)
    with urllib.request.urlopen(r, timeout=5) as x:
        return x.status, json.loads(x.read().decode())


def op(op_id, record_id, device, version, payload, table='customers', operation='CREATE'):
    return {
        'operationId': op_id,
        'recordId': record_id,
        'tableName': table,
        'operation': operation,
        'deviceId': device,
        'version': version,
        'payload': payload,
    }


def main():
    with tempfile.TemporaryDirectory() as td:
        app.DB_PATH = os.path.join(td, 'sync.sqlite3')
        token_a = 'device-a-token-0123456789abcdef0123456789abcdef'
        token_b = 'device-b-token-fedcba9876543210fedcba9876543210'
        os.environ['ASAN_SYNC_TOKENS'] = json.dumps([
            {'token': token_a, 'businessId': 'biz-a', 'deviceId': 'dev-a'},
            {'token': token_b, 'businessId': 'biz-a', 'deviceId': 'dev-b'},
        ])
        server = app.ThreadingHTTPServer(('127.0.0.1', 0), app.Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = f'http://127.0.0.1:{server.server_address[1]}'
        try:
            # Device A creates two records while Device B is offline.
            queued = [
                op('a-1', 'cust-101', 'dev-a', 1, {'id': 'cust-101', 'name': 'Offline One'}),
                op('a-2', 'cust-102', 'dev-a', 1, {'id': 'cust-102', 'name': 'Offline Two'}),
            ]
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId': 'biz-a', 'operations': queued}, token_a)
            assert s == 200 and out['syncedOperationIds'] == ['a-1', 'a-2']

            # Device B resumes and pulls both operations from cursor 0.
            s, pulled = req(base + '/v1/sync/pull?businessId=biz-a&deviceId=dev-b&cursor=0', token=token_b)
            assert s == 200 and [x['operationId'] for x in pulled['operations']] == ['a-1', 'a-2']
            assert pulled['nextCursor'] == '2'

            # Cursor resume must return nothing after the acknowledged cursor.
            s, empty = req(base + '/v1/sync/pull?businessId=biz-a&deviceId=dev-b&cursor=2', token=token_b)
            assert s == 200 and empty['operations'] == [] and empty['nextCursor'] == '2'

            # Device B writes while A is offline; A later resumes from cursor 0.
            b_op = op('b-1', 'cust-103', 'dev-b', 1, {'id': 'cust-103', 'name': 'Return Path'})
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId': 'biz-a', 'operations': [b_op]}, token_b)
            assert out['syncedOperationIds'] == ['b-1'] and not out['conflictOperationIds']
            s, pulled = req(base + '/v1/sync/pull?businessId=biz-a&deviceId=dev-a&cursor=0', token=token_a)
            assert s == 200 and [x['operationId'] for x in pulled['operations']] == ['a-1', 'a-2', 'b-1']
            assert pulled['nextCursor'] == '3'

            # Replay after a lost acknowledgement must be idempotent.
            s, replay = req(base + '/v1/sync/push', 'POST', {'businessId': 'biz-a', 'operations': [b_op]}, token_b)
            assert replay['syncedOperationIds'] == ['b-1'] and replay['conflictOperationIds'] == []
            with app.db() as c:
                count = c.execute('SELECT COUNT(*) FROM operations WHERE operation_id=?', ('b-1',)).fetchone()[0]
                assert count == 1

            # A stale master-data version is rejected rather than overwriting newer data.
            newer = op('a-4', 'cust-101', 'dev-a', 2, {'id': 'cust-101', 'name': 'Newer'})
            stale = op('a-5', 'cust-101', 'dev-a', 1, {'id': 'cust-101', 'name': 'Stale'})
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId': 'biz-a', 'operations': [newer]}, token_a)
            assert out['syncedOperationIds'] == ['a-4']
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId': 'biz-a', 'operations': [stale]}, token_a)
            assert out['conflictOperationIds'] == ['a-5']

            # Financial records remain immutable through remote UPDATE replay.
            sale = op('sale-1', 'sale-1', 'dev-a', 1, {'id': 'sale-1', 'total': 100}, table='sales')
            sale_update = op('sale-2', 'sale-1', 'dev-a', 2, {'id': 'sale-1', 'total': 50}, table='sales', operation='UPDATE')
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId': 'biz-a', 'operations': [sale]}, token_a)
            assert out['syncedOperationIds'] == ['sale-1']
            s, out = req(base + '/v1/sync/push', 'POST', {'businessId': 'biz-a', 'operations': [sale_update]}, token_a)
            assert out['conflictOperationIds'] == ['sale-2']
        finally:
            server.shutdown()
            server.server_close()
    print('PASS: two-device sync contract test')


if __name__ == '__main__':
    main()
