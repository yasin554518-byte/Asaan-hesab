#!/usr/bin/env bash
set -euo pipefail
BASE_URL="${ASAN_PRODUCTION_BASE_URL:-${ASAN_SYNC_BASE_URL:-}}"
TOKEN="${ASAN_PRODUCTION_TOKEN:-${ASAN_SYNC_SMOKE_TOKEN:-}}"
BUSINESS_ID="${ASAN_PRODUCTION_BUSINESS_ID:-${ASAN_SYNC_SMOKE_BUSINESS_ID:-}}"
DEVICE_ID="${ASAN_PRODUCTION_DEVICE_ID:-${ASAN_SYNC_SMOKE_DEVICE_ID:-}}"
fail(){ echo "FAIL: $*" >&2; exit 1; }
[[ -n "$BASE_URL" ]] || fail 'ASAN_SYNC_BASE_URL is required'
[[ "$BASE_URL" == https://* ]] || fail 'production sync endpoint must use HTTPS'
[[ "$BASE_URL" != *'?'* && "$BASE_URL" != *'#'* ]] || fail 'production sync endpoint must not contain query or fragment'
[[ -n "$TOKEN" && ${#TOKEN} -ge 32 ]] || fail 'ASAN_SYNC_SMOKE_TOKEN must be at least 32 characters'
[[ -n "$BUSINESS_ID" && -n "$DEVICE_ID" ]] || fail 'business/device smoke identifiers are required'
BASE_URL="${BASE_URL%/}"
status=$(curl --fail-with-body --silent --show-error --dump-header /tmp/asan-health.headers --output /tmp/asan-health.json --write-out '%{http_code}' --max-time 10 --proto '=https' --tlsv1.2 "$BASE_URL/health") || fail 'HTTPS health request failed'
[[ "$status" == 200 ]] || fail "health returned HTTP $status"
grep -q '"ok":true' /tmp/asan-health.json || fail 'health response did not report ok=true'
grep -qi '^content-type: application/json' /tmp/asan-health.headers || fail 'health response must be JSON'
grep -qi '^x-content-type-options: nosniff' /tmp/asan-health.headers || fail 'health response missing nosniff header'
status=$(curl --silent --show-error --output /dev/null --write-out '%{http_code}' --max-time 10 --proto '=https' --tlsv1.2 --get \
  --data-urlencode "businessId=$BUSINESS_ID" --data-urlencode "deviceId=$DEVICE_ID" --data-urlencode "cursor=0" \
  "$BASE_URL/v1/sync/pull") || fail 'unauthorized probe request failed'
[[ "$status" == 401 ]] || fail "unauthorized pull expected HTTP 401, got $status"
status=$(curl --fail-with-body --silent --show-error --dump-header /tmp/asan-pull.headers --output /tmp/asan-pull.json --write-out '%{http_code}' --max-time 10 --proto '=https' --tlsv1.2 \
  -H "Authorization: Bearer $TOKEN" \
  --get --data-urlencode "businessId=$BUSINESS_ID" --data-urlencode "deviceId=$DEVICE_ID" --data-urlencode "cursor=0" \
  "$BASE_URL/v1/sync/pull") || fail 'authorized pull request failed'
[[ "$status" == 200 ]] || fail "authorized pull expected HTTP 200, got $status"
grep -q '"operations"' /tmp/asan-pull.json || fail 'pull response missing operations'
grep -qi '^content-type: application/json' /tmp/asan-pull.headers || fail 'pull response must be JSON'
grep -qi '^cache-control: no-store' /tmp/asan-pull.headers || fail 'pull response missing no-store cache header'
rm -f /tmp/asan-health.json /tmp/asan-health.headers /tmp/asan-pull.json /tmp/asan-pull.headers
printf '%s\n' 'PASS: production HTTPS endpoint smoke checks completed'
