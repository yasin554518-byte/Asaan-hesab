from pathlib import Path

s = Path('lib/features/home/home_shell.dart').read_text(encoding='utf-8')
start = s.index('class PurchasePage')
end = s.index('class LoanAddPage', start)
body = s[start:end]
needle = "catch(e){if(mounted)msg('ستونزه: $e');}"
assert needle in body, 'Purchase catch must guard mounted before SnackBar/context access'
assert "finally{if(mounted)setState(()=>saving=false);}" in body
print('PASS: Purchase lifecycle contract')
