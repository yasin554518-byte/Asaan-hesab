#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
cat > "$tmp/valid.json" <<'JSON'
{"app_version":"1.0.1+82","git_commit_sha":"local","release_ref":"refs/tags/v1.0.1+82","release_tag":"v1.0.1+82","aab_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","workflow_run_id":"local","workflow_run_attempt":"local","workflow_name":"local","event_name":"local","artifact_name":"app-release.aab","published_artifact_name":"local"}
JSON
PROVENANCE_PATH="$tmp/valid.json" bash tool/release_provenance_schema_check.sh >/dev/null
cat > "$tmp/bad.json" <<'JSON'
{"app_version":"1.0.1+82","git_commit_sha":"local","release_ref":"refs/tags/v1.0.1","release_tag":"v1.0.1","aab_sha256":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa","workflow_run_id":"local","workflow_run_attempt":"local","workflow_name":"local","event_name":"local","artifact_name":"app-release.aab","published_artifact_name":"local"}
JSON
if PROVENANCE_PATH="$tmp/bad.json" bash tool/release_provenance_schema_check.sh >/dev/null 2>&1; then
  echo 'FAIL: mismatched release tag/version accepted'; exit 1
fi
echo 'PASS: release provenance release-ref identity contract'
