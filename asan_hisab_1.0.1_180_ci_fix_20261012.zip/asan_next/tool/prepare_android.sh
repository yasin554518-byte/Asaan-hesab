#!/usr/bin/env bash
set -euo pipefail

# Generate the Android host project without replacing application source/assets.
# The package id is pinned before the first Play publication.
if ! command -v flutter >/dev/null 2>&1; then
  echo "ERROR: Flutter SDK is required to generate Android platform files." >&2
  exit 1
fi

flutter create \
  --platforms=android \
  --project-name asan_hisab \
  --org com.asanhisab \
  --overwrite \
  .

EXPECTED='com.asanhisab.app'
APP_GRADLE='android/app/build.gradle'
APP_KTS='android/app/build.gradle.kts'
MANIFEST='android/app/src/main/AndroidManifest.xml'

# Flutter's generated package varies with the project name. Normalize both
# namespace and applicationId to the immutable production id.
if [[ -f "$APP_GRADLE" ]]; then
  sed -i -E "s/^namespace .*/namespace '$EXPECTED'/" "$APP_GRADLE"
  sed -i -E "s/^    applicationId .*/    applicationId '$EXPECTED'/" "$APP_GRADLE"
elif [[ -f "$APP_KTS" ]]; then
  sed -i -E "s/^    namespace = .*/    namespace = \"$EXPECTED\"/" "$APP_KTS"
  sed -i -E "s/^        applicationId = .*/        applicationId = \"$EXPECTED\"/" "$APP_KTS"
else
  echo "ERROR: Flutter did not generate an Android app module." >&2
  exit 1
fi

# Remove any stale package replacement from generated Java/Kotlin source.
find android/app/src -type f \( -name '*.kt' -o -name '*.java' \) -print0 2>/dev/null | \
  xargs -0 -r sed -i -E 's/package com\.asanhisab\.[A-Za-z0-9_]+/package com.asanhisab.app/'

# Keep the manifest explicit as a defense-in-depth check.
if [[ -f "$MANIFEST" ]]; then
  sed -i -E "s/android:label=\"[^\"]*\"/android:label=\"آسان حساب\"/" "$MANIFEST" || true
fi

echo "Android platform generated and normalized to $EXPECTED."
