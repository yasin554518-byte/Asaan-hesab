#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -qF -- "ORDER BY date ASC, created_at ASC, id ASC" lib/shared/services/statement_service.dart || fail "statement ordering is not deterministic"
grep -qF -- "running_balance" lib/shared/services/statement_service.dart || fail "running balance missing"
echo 'STATEMENT_ORDER_CONTRACT: PASS'
