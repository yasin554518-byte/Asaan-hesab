#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/lib/app/app.dart"
grep -q "Timer.periodic(const Duration(minutes: 5)" "$APP"
grep -q "state == AppLifecycleState.resumed" "$APP"
grep -q "SyncWorker" "$APP"
grep -q "SyncConfigService" "$APP"
echo "AUTO_SYNC_CHECK: PASS"
