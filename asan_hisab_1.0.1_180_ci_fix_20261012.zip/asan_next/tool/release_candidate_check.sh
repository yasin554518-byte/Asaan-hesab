#!/usr/bin/env bash
set -euo pipefail

# Python contract tests can create bytecode caches in the checkout. Keep the
# release tree deterministic even when this gate is run after other tests.
cleanup_python_cache() {
  find . -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
  find . -type f -name '*.pyc' -delete 2>/dev/null || true
}
cleanup_python_cache
trap cleanup_python_cache EXIT

VERSION=$(sed -n 's/^version: //p' pubspec.yaml | head -1)
[ -n "$VERSION" ] || { echo 'FAIL: missing pubspec version'; exit 1; }

grep -q "com.asanhisab" tool/prepare_android.sh || { echo 'FAIL: Android org/application id not configured'; exit 1; }

grep -R -nE 'BEGIN (RSA|OPENSSH|EC) PRIVATE KEY|AIza[0-9A-Za-z_-]{20,}|sk-[A-Za-z0-9]{20,}' . \
  --exclude-dir=.git --exclude='*.pyc' >/tmp/asan_secret_hits 2>/dev/null && {
  echo 'FAIL: possible secret material found'; cat /tmp/asan_secret_hits; exit 1;
} || true

if find . -type d -name __pycache__ -print -quit | grep -q .; then
  echo 'FAIL: __pycache__ present in release tree'
  exit 1
fi

if [ -d android ]; then
  ./tool/verify_android_application_id.sh
else
  grep -q "com.asanhisab" tool/prepare_android.sh || { echo "FAIL: Android org/application id not configured"; exit 1; }
  echo "PASS: Android application-id source configuration"
fi
./tool/smoke_check.sh
./tool/release_static_check.sh
python3 ./tool/purchase_lifecycle_contract_test.py
python3 ./tool/sale_purchase_validation_contract_test.py

echo "PASS: release candidate checks ($VERSION)"
