#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }

# The CI release job must publish the three linked release artifacts together.
grep -q 'build/app/outputs/bundle/release/app-release.aab' .github/workflows/ci.yml || fail 'CI AAB artifact path missing'
grep -q 'build/app-release.aab.sha256' .github/workflows/ci.yml || fail 'CI AAB checksum artifact missing'
grep -q 'build/release-provenance.json' .github/workflows/ci.yml || fail 'CI provenance artifact missing'

grep -q 'aab_sha256' tool/release_provenance.sh || fail 'provenance checksum field missing'
grep -q 'app_version' tool/release_provenance.sh || fail 'provenance version field missing'
grep -q 'git_commit_sha' tool/release_provenance.sh || fail 'provenance commit field missing'
grep -q 'release_ref' tool/release_provenance.sh || fail 'provenance ref field missing'
[[ -x tool/release_provenance_schema_check.sh ]] || fail 'provenance schema checker missing'

VERSION="$(sed -n 's/^version: //p' pubspec.yaml | head -1)"
TAG="v${VERSION}"
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
printf 'asan-hisab-aab-fixture-v62\n' > "$tmp/app-release.aab"
sha="$(sha256sum "$tmp/app-release.aab" | cut -d' ' -f1)"
ASAN_TEST_VERSION="$VERSION" ASAN_TEST_TAG="$TAG" python3 - "$tmp/release-provenance.json" "$sha" <<'PY'
import json, os, sys
out, sha = sys.argv[1:]
obj = {
    'app_version': os.environ['ASAN_TEST_VERSION'],
    'git_commit_sha': '0123456789abcdef0123456789abcdef01234567',
    'release_ref': 'refs/tags/' + os.environ['ASAN_TEST_TAG'],
    'release_tag': os.environ['ASAN_TEST_TAG'],
    'aab_sha256': sha,
    'workflow_run_id': '12345',
    'workflow_run_attempt': '1',
    'workflow_name': 'CI',
    'event_name': 'push',
    'artifact_name': 'app-release.aab',
    'published_artifact_name': 'asan-hisab-release-' + os.environ['ASAN_TEST_TAG'] + '-12345-1',
}
with open(out, 'w', encoding='utf-8') as f:
    json.dump(obj, f, sort_keys=True)
PY
ASAN_TEST_VERSION="$VERSION" python3 - "$tmp/release-provenance.json" "$tmp/app-release.aab" <<'PY'
import hashlib, json, os, sys
p, aab = sys.argv[1:]
obj=json.load(open(p, encoding='utf-8'))
required={'app_version','git_commit_sha','release_ref','release_tag','aab_sha256','workflow_run_id','workflow_run_attempt','workflow_name','event_name','artifact_name','published_artifact_name'}
if set(obj) != required:
    raise SystemExit(f'wrong provenance keys: {sorted(obj)}')
actual=hashlib.sha256(open(aab,'rb').read()).hexdigest()
if obj['aab_sha256'] != actual:
    raise SystemExit('provenance AAB SHA-256 mismatch')
if obj['app_version'] != os.environ['ASAN_TEST_VERSION']:
    raise SystemExit('provenance version mismatch')
if any(x in json.dumps(obj).lower() for x in ('password','private_key','keystore','secret','token')):
    raise SystemExit('secret-like field detected in provenance')
PY
python3 - "$tmp/release-provenance.json" <<'PY'
import json, sys
p=sys.argv[1]
obj=json.load(open(p, encoding='utf-8'))
obj['token']='SHOULD_BE_REJECTED'
open(p,'w',encoding='utf-8').write(json.dumps(obj))
PY
if PROVENANCE_PATH="$tmp/release-provenance.json" tool/release_provenance_schema_check.sh >/dev/null 2>&1; then
  echo 'FAIL: provenance schema checker accepted a secret-like field' >&2
  exit 1
fi
cp "$tmp/release-provenance.json" "$tmp/release-provenance-invalid.json"
python3 - "$tmp/release-provenance.json" <<'PY'
import json, sys
p=sys.argv[1]
obj=json.load(open(p, encoding='utf-8'))
obj.pop('token', None)
obj['release_tag']='v9.9.9+999'
open(p,'w',encoding='utf-8').write(json.dumps(obj))
PY
if PROVENANCE_PATH="$tmp/release-provenance.json" tool/release_provenance_schema_check.sh >/dev/null 2>&1; then
  echo 'FAIL: provenance schema checker accepted a release tag/ref mismatch' >&2
  exit 1
fi
python3 - "$tmp/release-provenance.json" <<'PY'
import json, sys
p=sys.argv[1]
obj=json.load(open(p, encoding='utf-8'))
obj['release_tag']=obj['release_ref'].split('/')[-1]
open(p,'w',encoding='utf-8').write(json.dumps(obj))
PY
PROVENANCE_PATH="$tmp/release-provenance.json" tool/release_provenance_schema_check.sh

echo 'PASS: release artifact provenance contract'
