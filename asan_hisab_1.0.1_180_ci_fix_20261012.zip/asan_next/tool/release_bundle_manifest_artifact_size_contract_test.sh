#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
fail(){ echo "FAIL: $1" >&2; exit 1; }
grep -Fq "re.fullmatch(r'[1-9][0-9]*', vals['artifact_size_bytes'])" tool/release_bundle_manifest.sh || fail 'positive decimal artifact-size validation missing'
grep -Fq "manifest artifact size does not match the release AAB" tool/release_bundle_manifest.sh || fail 'artifact-size/AAB consistency validation missing'
tmp="$(mktemp -d)"; trap 'rm -rf "$tmp"' EXIT
mkdir -p "$tmp/build/app/outputs/bundle/release" "$tmp/tool"
cp pubspec.yaml "$tmp/pubspec.yaml"
printf 'fixture-aab' > "$tmp/build/app/outputs/bundle/release/app-release.aab"
sha="$(sha256sum "$tmp/build/app/outputs/bundle/release/app-release.aab" | awk '{print $1}')"
printf '%s  app-release.aab\n' "$sha" > "$tmp/build/app-release.aab.sha256"
printf '{"app_version":"%s","aab_sha256":"%s","release_ref":"local","workflow_run_id":"local","workflow_run_attempt":"local","workflow_name":"local","event_name":"local","artifact_name":"app-release.aab","published_artifact_name":"local","git_commit_sha":"local"}\n' "$(sed -n 's/^version: //p' pubspec.yaml | head -1)" "$sha" > "$tmp/build/release-provenance.json"
cp tool/release_bundle_manifest.sh "$tmp/tool/release_bundle_manifest.sh"; chmod +x "$tmp/tool/release_bundle_manifest.sh"
( cd "$tmp" && AAB_PATH="$tmp/build/app/outputs/bundle/release/app-release.aab" PROVENANCE_PATH="$tmp/build/release-provenance.json" CHECKSUM_PATH="$tmp/build/app-release.aab.sha256" RELEASE_BUNDLE_MANIFEST_PATH="$tmp/build/release-bundle-manifest.txt" ./tool/release_bundle_manifest.sh ) >/dev/null || fail 'valid local fixture rejected'
size="$(sed -n 's/^artifact_size_bytes=//p' "$tmp/build/release-bundle-manifest.txt")"
[[ "$size" =~ ^[1-9][0-9]*$ ]] || fail 'emitted artifact size is not a positive decimal integer'
echo 'PASS: release bundle artifact size contract'
