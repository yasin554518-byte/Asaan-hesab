#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CI="$ROOT/.github/workflows/ci.yml"
python3 - "$CI" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]).read_text(encoding="utf-8")
blocks=p.split("- uses: actions/checkout@v4")[1:]
if not blocks:
    raise SystemExit("FAIL: no checkout steps found")
for i,b in enumerate(blocks, 1):
    head=b.split("- uses:",1)[0]
    if "persist-credentials: false" not in head:
        raise SystemExit(f"FAIL: checkout step {i} must disable credential persistence")
print(f"PASS: checkout credential persistence disabled ({len(blocks)} steps)")
PY
