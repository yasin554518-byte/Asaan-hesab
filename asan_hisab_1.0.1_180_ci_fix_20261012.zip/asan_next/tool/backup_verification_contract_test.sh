#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
[[ -x deploy/backup_sync_db.sh ]] || { echo 'FAIL: backup script missing or not executable'; exit 1; }
[[ -x deploy/verify_backup.sh ]] || { echo 'FAIL: backup verification script missing or not executable'; exit 1; }
grep -Fq 'verify_backup.sh' deploy/backup_sync_db.sh || { echo 'FAIL: backup creation must invoke verification'; exit 1; }
grep -Fq "sha256sum" deploy/verify_backup.sh || { echo 'FAIL: backup verifier must verify checksum'; exit 1; }
grep -Fq "PRAGMA integrity_check" deploy/verify_backup.sh || { echo 'FAIL: backup verifier must run SQLite integrity_check'; exit 1; }
grep -Fq "auth_devices" deploy/verify_backup.sh || { echo 'FAIL: backup verifier must check sync schema'; exit 1; }
grep -Fq "operations" deploy/verify_backup.sh || { echo 'FAIL: backup verifier must check sync schema'; exit 1; }
if grep -nE 'REPLACE_|BEGIN (RSA|OPENSSH|EC|PRIVATE) KEY|PRIVATE KEY' deploy/verify_backup.sh >/dev/null 2>&1; then
  echo 'FAIL: backup verifier contains secret material placeholders' >&2
  exit 1
fi
printf 'PASS: backup verification contract\n'
