# Asan Hisab v42

Version: 1.0.1+28

## Security hardening
- Production sync bootstrap now rejects auth tokens shorter than 32 characters.
- Token business/device identifiers must be non-empty.
- Added backend contract coverage for rejecting weak bootstrap tokens.

All local source/release/static/backend contract gates were rerun after the change.
