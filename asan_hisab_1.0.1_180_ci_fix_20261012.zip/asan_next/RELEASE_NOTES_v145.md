# Release Notes v145

Version: 1.0.1+131

- Added an optional note field to the receipt/payment UI.
- Payment notes are passed into the atomic payment transaction and synchronized with the payment, ledger entry, and cash transaction.
- Clears the payment note after a successful save.

Validation: release static/candidate, sync payload safety, two-device sync, backup/recovery, checksum/manifest, and backend compile gates are required.
