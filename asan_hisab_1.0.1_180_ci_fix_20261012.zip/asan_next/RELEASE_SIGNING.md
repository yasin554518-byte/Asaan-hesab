# Android release signing

Do not commit a keystore, passwords, or Play credentials to the repository.

## CI secrets
For a signed AAB, configure these GitHub Actions secrets:

- `ANDROID_KEYSTORE_BASE64` — base64 of the upload keystore (`.jks`)
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`

CI creates `android/key.properties` and `android/upload-keystore.jks` only for the build job. They are not committed or uploaded as artifacts.

If the secrets are absent, CI deliberately builds an unsigned AAB and does **not** claim Play Store readiness.

The immutable Android application id is:
`com.asanhisab.app`
