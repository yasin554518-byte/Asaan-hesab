# Asan Hisab v78

- Version: 1.0.1+68
- Strengthened release provenance with GitHub workflow run ID and run attempt.
- This makes reruns auditable at the provenance level and aligns provenance metadata with the unique release artifact name.
- Android/Flutter AAB build remains an environment-dependent gate and is not claimed as built here.
