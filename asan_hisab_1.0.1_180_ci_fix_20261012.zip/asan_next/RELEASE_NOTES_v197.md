# Asan Hisab v197 — 1.0.1+180

- Synced the Alerts/Sync post-await lifecycle contract with the current mounted-safe implementation.
- Kept the Sync Status flow guarded after `worker.run()`, refreshed the queue, then updated the status through `setState`.
- No functional data/sync behavior changed; this release tightens regression coverage to match the implemented lifecycle-safe flow.

Validation: targeted lifecycle contracts PASS. Flutter SDK/device/AAB tests remain unavailable in this runtime.
