# Asan Hisab v63 — Release Tag Integrity Gate

Version: 1.0.1+49

- Added a release-tag integrity contract for tag-triggered releases.
- Requires release automation to derive the tag/ref and commit from GitHub runtime variables rather than hard-coded release values.
- Verifies release version format and current manifest/version alignment.
- Wired the gate into CI and final automated release preflight.
- No production secrets, signing keys, or private material are added to source.
