# Asan Hisab v95

- Version: 1.0.1+82.
- Tightened release bundle manifest identity validation: commit SHA must be `local` or exactly 40 hexadecimal characters.
- Tightened workflow run ID and run-attempt validation: each must be `local` or numeric.
- Added a regression contract proving valid release identity metadata is accepted and an invalid commit SHA is rejected.
