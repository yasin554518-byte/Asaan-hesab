# Release Notes v177

Version: 1.0.1+161

- Hardened Returns page async selection lifecycle.
- Prevented post-dispose `setState` after loading return-transaction items.
- Added regression coverage for the Returns selection lifecycle.
