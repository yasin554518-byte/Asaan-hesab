# Asan Hisab v150

Version 1.0.1+136.

- Statement period opening balance is now explicit in the UI.
- Statement PDF uses the balance immediately before the selected date range as its opening balance.
- PDF period label reflects the selected date range.
- Existing running-balance semantics remain unchanged.
