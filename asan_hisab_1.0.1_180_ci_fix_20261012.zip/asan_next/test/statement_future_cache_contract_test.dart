import 'dart:io';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Statement caches its load future and refreshes it only on explicit input changes', () {
    final source = File('lib/features/home/home_shell.dart').readAsStringSync();
    expect(source, contains('Future<_StatementViewData>? _statementFuture;'));
    expect(source, contains('_statementFuture=_loadStatement(partyId!)'));
    expect(source, contains('_statementFuture=v==null?null:_loadStatement(v)'));
    expect(source, contains('future:_statementFuture'));
    expect(source, isNot(contains('future:_loadStatement(partyId!)')));
  });
}
