import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  final start = source.indexOf('Future<void> _printStatement');
  final end = source.indexOf('\n  @override Widget build', start);
  if (start < 0 || end < 0) {
    throw StateError('Statement PDF method not found');
  }
  final method = source.substring(start, end);
  if (!method.contains('openingBalanceAt')) {
    throw StateError('PDF must obtain the period opening balance from StatementService');
  }
  if (method.contains("party['opening_balance']")) {
    throw StateError('PDF must not fall back to the party original opening balance');
  }
  if (method.contains('firstRunning')) {
    throw StateError('PDF must not reconstruct period opening from the first filtered row');
  }
  if (!method.contains('bal=widget.partyType=='CUSTOMER'?bal+d-c:bal+c-d')) {
    throw StateError('PDF rows must advance balances from the period opening');
  }
  stdout.writeln('Statement PDF period consistency contract: PASS');
}
