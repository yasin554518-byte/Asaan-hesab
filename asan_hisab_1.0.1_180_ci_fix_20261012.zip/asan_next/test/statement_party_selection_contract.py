from pathlib import Path
s=Path('lib/features/home/home_shell.dart').read_text()
assert "final selectedPartyId=parties.any((x)=>x['id']==partyId)?partyId:null;" in s
assert 'value:selectedPartyId' in s
print('PASS: statement party selection contract')
