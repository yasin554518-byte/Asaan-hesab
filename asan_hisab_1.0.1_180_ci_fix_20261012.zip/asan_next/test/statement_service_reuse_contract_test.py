from pathlib import Path
p=Path('lib/features/home/home_shell.dart')
s=p.read_text()
assert 'final statementService=StatementService(widget.database.db);' in s
assert s.count('final statementService=StatementService(widget.database.db);') >= 2
assert 'final entries=await statementService.partyStatement' in s
assert 'final periodOpening=await statementService.openingBalanceAt' in s
print('PASS: StatementService reuse contract')
