import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  if (!source.contains('Future<List<Map<String,dynamic>>>? _partiesFuture')) {
    throw StateError('Statement page must cache the parties future');
  }
  if (!source.contains('_partiesFuture=_loadParties();')) {
    throw StateError('Statement parties future must be initialized once in initState');
  }
  if (!source.contains('future:_partiesFuture')) {
    throw StateError('FutureBuilder must consume the cached parties future');
  }
  if (source.contains("future:widget.database.db.query(widget.partyType=='CUSTOMER'?'customers':'suppliers'")) {
    throw StateError('Statement build must not issue a fresh parties query on every rebuild');
  }
  print('statement_parties_future_cache_contract: PASS');
}
