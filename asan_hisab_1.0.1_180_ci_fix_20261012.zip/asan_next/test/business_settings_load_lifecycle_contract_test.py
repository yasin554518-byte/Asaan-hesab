from pathlib import Path

s = Path("lib/features/home/home_shell.dart").read_text()
needle = "final rows = await widget.database.db.query('businesses', where: 'id = ?', whereArgs: [widget.businessId], limit: 1);\n    if (!mounted || rows.isEmpty) return;"
assert needle in s, "Business Settings load must guard mounted before controller writes"
idx = s.index(needle)
block = s[idx:idx+500]
assert block.index("if (!mounted || rows.isEmpty) return;") < block.index("name.text ="), "mounted guard must precede controller writes"
print("business settings load lifecycle contract: PASS")
