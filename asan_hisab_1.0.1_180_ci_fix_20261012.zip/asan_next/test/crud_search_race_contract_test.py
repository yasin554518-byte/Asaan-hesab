from pathlib import Path
p=Path('lib/features/home/management_pages.dart')
s=p.read_text()
checks=[
("int _loadToken = 0;", 'load token exists'),
("final token = ++_loadToken;", 'token captured per load'),
("if (!mounted || token != _loadToken) return;", 'stale load is ignored'),
]
for needle,msg in checks:
    assert needle in s, msg
print('CRUD search race contract: PASS')
