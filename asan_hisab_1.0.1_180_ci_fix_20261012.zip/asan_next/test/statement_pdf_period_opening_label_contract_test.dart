import 'dart:io';

void main() {
  final source = File('lib/features/invoice/statement_pdf_service.dart').readAsStringSync();
  if (!source.contains("date == 'ټول حساب' ? 'د پیل بیلانس' : 'د فلټر د پیل بیلانس'")) {
    throw StateError('filtered Statement PDF must label its opening balance as period opening');
  }
  print('PASS: Statement PDF opening-balance label distinguishes filtered periods.');
}
