from pathlib import Path

p = Path("lib/features/home/management_pages.dart")
s = p.read_text(encoding="utf-8")
assert "if (!mounted) { for (final c in [name, phone, address, cost, sale, stock, minStock, barcode, part, sku]) { c.dispose(); } return; }" in s
assert "if (!mounted || ok != true) return;" in s
print("PASS: CRUD dialog lifecycle contract")
