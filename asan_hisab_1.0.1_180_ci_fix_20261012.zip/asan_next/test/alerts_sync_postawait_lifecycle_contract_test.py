from pathlib import Path
root = Path(__file__).resolve().parents[1]
home = (root / 'lib/features/home/home_shell.dart').read_text()
assert "Future<void> _refresh() async {\n    if (!mounted) return;\n    final next = NotificationService(widget.database.db).loadAlerts(widget.businessId);\n    setState(() => future = next);\n    await next;\n  }" in home
needle = "final result = await worker.run(widget.businessId);\n      if (!mounted) return;\n      final summary = 'Push: ${result.synced}، Conflict: ${result.conflicts}، Pull: ${result.pullApplied}';\n      refresh();\n      if (!mounted) return;\n      setState(() => statusText = summary);"
assert needle in home
print('alerts/sync post-await lifecycle contract: PASS')
