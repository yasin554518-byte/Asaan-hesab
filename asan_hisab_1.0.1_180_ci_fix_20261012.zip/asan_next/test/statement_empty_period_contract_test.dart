import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  if (!source.contains('final filteredClosing=st.data!.isEmpty?periodOpening:')) {
    throw StateError('empty filtered statement must close at period opening balance');
  }
  if (source.contains('final filteredClosing=st.data!.isEmpty?opening:')) {
    throw StateError('statement UI regressed to party opening balance for empty filtered periods');
  }
  print('statement empty-period closing contract: PASS');
}
