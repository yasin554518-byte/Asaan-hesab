from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'lib/features/home/management_pages.dart').read_text()

assert 'final p=await CsvImportService(widget.database.db).previewProducts' in SRC
assert "if (!mounted) return;\n      setState(() {\n        preview = p;\n        result = p.canImport" in SRC
assert "if(p.canImport) setState" not in SRC
assert "else setState(()=>result='د Import لپاره ستونزې شته" not in SRC

print('PASS: CSV preview post-await lifecycle contract')
