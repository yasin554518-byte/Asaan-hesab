import 'package:flutter_test/flutter_test.dart';
import 'package:asan_hisab/core/sync/sync_scheduler.dart';

void main() {
  test('scheduler retry policy is identical to durable queue policy', () async {
    expect(SyncScheduler.retryDelay(1), const Duration(minutes: 1));
    expect(SyncScheduler.retryDelay(2), const Duration(minutes: 2));
    expect(SyncScheduler.retryDelay(3), const Duration(minutes: 4));
    expect(SyncScheduler.retryDelay(5), const Duration(minutes: 16));
    expect(SyncScheduler.retryDelay(99), const Duration(minutes: 16));
  });
}
