import 'dart:io';

void main() {
  final source = File('lib/shared/services/payment_service.dart').readAsStringSync();
  if (!source.contains("'note': note, 'date': now, 'created_at': now")) {
    throw StateError('Payment ledger entry must persist payment note');
  }
  if (!source.contains("'reference_type': 'PAYMENT', 'reference_id': paymentId")) {
    throw StateError('Payment ledger reference contract missing');
  }
  stdout.writeln('PAYMENT_NOTE_LEDGER_CONTRACT_PASS');
}
