from pathlib import Path

src = Path("lib/features/home/home_shell.dart").read_text()
needle = "void msg(String x){if(!mounted)return;ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(x)));}"
assert src.count(needle) == 3
print("PASS: sale/purchase/payment message helpers are mounted-safe")
