import 'package:flutter_test/flutter_test.dart';
import 'package:asan_hisab/core/utils/ledger_balance.dart';

void main() {
  test('customer debt increases on debit and decreases on credit', () {
    expect(LedgerBalance.apply(partyType: 'CUSTOMER', balance: 1000, debit: 500, credit: 0), 1500);
    expect(LedgerBalance.apply(partyType: 'CUSTOMER', balance: 1500, debit: 0, credit: 400), 1100);
  });

  test('supplier balance increases on credit and decreases on debit', () {
    expect(LedgerBalance.apply(partyType: 'SUPPLIER', balance: 1000, debit: 0, credit: 500), 1500);
    expect(LedgerBalance.apply(partyType: 'SUPPLIER', balance: 1500, debit: 400, credit: 0), 1100);
  });

  test('ledger rejects negative or two-sided entries', () {
    expect(() => LedgerBalance.apply(partyType: 'CUSTOMER', balance: 0, debit: -1, credit: 0), throwsArgumentError);
    expect(() => LedgerBalance.apply(partyType: 'CUSTOMER', balance: 0, debit: 10, credit: 1), throwsArgumentError);
  });
}

test('aggregate ledger totals may contain both debit and credit', () {
  expect(LedgerBalance.fromTotals(partyType: 'CUSTOMER', balance: 1000, debit: 500, credit: 200), 1300);
  expect(LedgerBalance.fromTotals(partyType: 'SUPPLIER', balance: 1000, debit: 200, credit: 500), 1300);
  expect(() => LedgerBalance.fromTotals(partyType: 'CUSTOMER', balance: 0, debit: -1, credit: 0), throwsArgumentError);
});
