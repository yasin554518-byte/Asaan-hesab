import 'dart:io';

void main() {
  final source = File('lib/shared/services/statement_service.dart').readAsStringSync();
  if (!source.contains('Future<int> openingBalanceAt(')) {
    throw StateError('StatementService must expose openingBalanceAt');
  }
  if (!source.contains("date < ?")) {
    throw StateError('openingBalanceAt must calculate balance strictly before the period start');
  }
  if (!source.contains('LedgerBalance.apply(')) {
    throw StateError('period opening must use the centralized ledger balance rules');
  }
  stdout.writeln('statement period opening contract: PASS');
}
