import 'package:flutter_test/flutter_test.dart';
import 'package:asan_hisab/core/security/permission_service.dart';

void main() {
  final service = PermissionService();

  test('owner has every permission', () {
    for (final permission in Permission.values) {
      expect(service.can(UserRole.owner, permission), isTrue,
          reason: 'Owner should have $permission');
    }
  });

  test('manager cannot access owner-only controls', () {
    expect(service.can(UserRole.manager, Permission.backup), isFalse);
    expect(service.can(UserRole.manager, Permission.restore), isFalse);
    expect(service.can(UserRole.manager, Permission.userManagement), isFalse);
    expect(service.can(UserRole.manager, Permission.sales), isTrue);
    expect(service.can(UserRole.manager, Permission.reports), isTrue);
  });

  test('cashier is limited to operational permissions', () {
    for (final permission in [
      Permission.sales,
      Permission.payments,
      Permission.customers,
      Permission.suppliers,
      Permission.stock,
    ]) {
      expect(service.can(UserRole.cashier, permission), isTrue,
          reason: 'Cashier should have $permission');
    }
    for (final permission in [
      Permission.purchases,
      Permission.returns,
      Permission.expenses,
      Permission.reports,
      Permission.backup,
      Permission.restore,
      Permission.userManagement,
      Permission.settings,
    ]) {
      expect(service.can(UserRole.cashier, permission), isFalse,
          reason: 'Cashier should not have $permission');
    }
  });
}
