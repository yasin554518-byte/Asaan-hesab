from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
s = (ROOT / "lib/features/home/management_pages.dart").read_text()
needle = "if(!ok)return;\n    if (!mounted) return;\n    setState(()=>importing=true);"
assert needle in s, "CSV Import confirmation must guard mounted state before setState"
print("PASS: CSV import confirmation lifecycle contract")
