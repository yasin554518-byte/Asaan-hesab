from pathlib import Path

src = Path('lib/features/home/home_shell.dart').read_text()
needle = "}catch(e){if(mounted)msg('ستونزه: $e');}finally{if(mounted)setState(()=>saving=false);}}@override void dispose(){q.dispose();"
assert needle in src, 'Sale save catch must guard SnackBar access with mounted'
print('sale_save_lifecycle_contract_test: PASS')
