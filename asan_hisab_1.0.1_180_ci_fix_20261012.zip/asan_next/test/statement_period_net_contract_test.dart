import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  if (!source.contains("Text('خالص: \${filteredClosing-periodOpening}')")) {
    throw StateError('filtered statement net must use periodOpening');
  }
  if (source.contains("Text('خالص: \${filteredClosing-opening}')")) {
    throw StateError('statement net regressed to party opening balance');
  }
  print('statement period-net contract: PASS');
}
