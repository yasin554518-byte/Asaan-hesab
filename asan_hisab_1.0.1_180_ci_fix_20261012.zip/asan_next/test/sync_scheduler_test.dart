import 'dart:async';
import 'package:flutter_test/flutter_test.dart';
import '../lib/core/sync/sync_scheduler.dart';

void main() {
  test('coalesces overlapping automatic sync runs', () async {
    final started = Completer<void>();
    final release = Completer<void>();
    var calls = 0;
    final scheduler = SyncScheduler(
      interval: const Duration(hours: 1),
      callback: () async {
        calls++;
        started.complete();
        await release.future;
      },
    );

    final first = scheduler.trigger();
    await started.future;
    await scheduler.trigger();
    expect(calls, 1);

    release.complete();
    await first;
    scheduler.dispose();
  });

  test('failed automatic sync is swallowed and records a retry failure', () async {
    final scheduler = SyncScheduler(
      interval: const Duration(hours: 1),
      callback: () async => throw StateError('temporary network failure'),
    );

    await scheduler.trigger();
    expect(scheduler.consecutiveFailures, 1);
    scheduler.dispose();
  });

  test('successful retry resets failure count', () async {
    var calls = 0;
    final scheduler = SyncScheduler(
      interval: const Duration(hours: 1),
      callback: () async {
        calls++;
        if (calls == 1) throw StateError('temporary network failure');
      },
    );

    await scheduler.trigger();
    expect(scheduler.consecutiveFailures, 1);
    await scheduler.trigger();
    expect(scheduler.consecutiveFailures, 0);
    expect(calls, 2);
    scheduler.dispose();
  });


  test('paused scheduler does not trigger and resume can trigger immediately', () async {
    var calls = 0;
    final scheduler = SyncScheduler(
      interval: const Duration(hours: 1),
      callback: () async { calls++; },
    );

    scheduler.pause();
    await scheduler.trigger();
    expect(calls, 0);
    expect(scheduler.isPaused, isTrue);

    scheduler.resume();
    await Future<void>.delayed(Duration.zero);
    expect(calls, 1);
    expect(scheduler.isPaused, isFalse);
    scheduler.dispose();
  });

  test('pause cancels a pending automatic timer', () async {
    var calls = 0;
    final scheduler = SyncScheduler(
      interval: const Duration(milliseconds: 20),
      callback: () async { calls++; },
    );

    scheduler.start();
    await Future<void>.delayed(const Duration(milliseconds: 1));
    scheduler.pause();
    await Future<void>.delayed(const Duration(milliseconds: 40));
    expect(calls, 1);
    scheduler.dispose();
  });

}
