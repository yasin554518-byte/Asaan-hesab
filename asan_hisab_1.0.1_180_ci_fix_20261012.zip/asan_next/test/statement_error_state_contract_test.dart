import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  assert(source.contains("if(st.hasError)return Center"));
  assert(source.contains("label:const Text('بیا هڅه')"));
  assert(source.contains("if(!st.hasData)return const Center(child:CircularProgressIndicator())"));
  print('Statement error-state contract: PASS');
}
