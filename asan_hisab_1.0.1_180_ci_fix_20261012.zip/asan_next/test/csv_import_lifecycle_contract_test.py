from pathlib import Path
s=Path('lib/features/home/management_pages.dart').read_text()
assert 'if (!mounted) return;\n      setState(()=>preview=p);' in s
assert "catch(e){if(mounted)setState(()=>result='ستونزه: $e');}" in s
assert 'if (!mounted) return;\n      setState(()=>result=' in s
print('CSV import lifecycle contract: PASS')
