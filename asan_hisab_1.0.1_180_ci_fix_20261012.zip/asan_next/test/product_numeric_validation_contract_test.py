from pathlib import Path

src = Path('lib/features/home/management_pages.dart').read_text()
assert "final numeric = <String, String>{" in src
assert "final value = int.tryParse(entry.value.trim());" in src
assert "value == null || value < 0" in src
assert "باید صفر یا مثبت عدد وي" in src
assert "'د پېرود قیمت': cost.text" in src
assert "'د پلور قیمت': sale.text" in src
assert "'ابتدایي ذخیره': stock.text" in src
assert "'د کمې ذخیرې حد': minStock.text" in src
print('product numeric validation contract: PASS')
