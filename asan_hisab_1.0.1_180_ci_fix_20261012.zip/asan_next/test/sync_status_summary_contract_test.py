from pathlib import Path

s = Path("lib/features/home/home_shell.dart").read_text()
assert "final summary = 'Push: ${result.synced}، Conflict: ${result.conflicts}، Pull: ${result.pullApplied}';" in s
assert "if (!mounted) return;\n      setState(() => statusText = summary);" in s
assert "Text('Sync بشپړ شو • ${summary}')" in s
assert "statusText = 'Push: ${result.synced}، Conflict: ${result.conflicts}، Pull: ${result.pullApplied}';" not in s
print('PASS: sync status summary lifecycle contract')
