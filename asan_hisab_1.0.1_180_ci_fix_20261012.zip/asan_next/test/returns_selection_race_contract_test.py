from pathlib import Path
s = Path('lib/features/home/home_shell.dart').read_text()
start = s.index('Future<void> selectOriginal')
end = s.index('void selectProduct', start)
segment = s[start:end]
assert 'int _selectionRequest = 0;' in s
assert 'final request = ++_selectionRequest;' in segment
assert 'request != _selectionRequest' in segment
assert segment.index('request != _selectionRequest') < segment.index('setState(() {')
print('PASS: Returns selection race contract')
