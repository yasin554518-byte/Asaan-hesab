import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  if (!source.contains("note:((r['note'] as String?)?.trim() ?? '')")) {
    throw StateError('Statement PDF note mapping must safely normalize null/blank notes');
  }
  if (source.contains("note:'\${r['note']??''}'")) {
    throw StateError('Statement PDF note mapping must not stringify null as literal null');
  }
  print('statement_pdf_note_null_safety_contract_test: PASS');
}
