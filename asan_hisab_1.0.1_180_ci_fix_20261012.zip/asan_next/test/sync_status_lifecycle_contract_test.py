from pathlib import Path
s=Path('lib/features/home/home_shell.dart').read_text()
assert "      refresh();\n      if (mounted) ScaffoldMessenger.of(context).showSnackBar" in s, 'retryFailed must refresh before success message'
assert "if (!mounted) return;\n      setState(() => statusText = 'Sync ستونزه');" in s, 'sync error must guard mounted before status update'
assert "if (mounted) ScaffoldMessenger.of(context).showSnackBar" in s, 'success snackbar must remain mounted-safe'
print('SYNC STATUS LIFECYCLE CONTRACT: PASS')
