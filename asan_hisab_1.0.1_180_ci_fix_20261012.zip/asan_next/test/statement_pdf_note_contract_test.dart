import 'dart:io';

void main() {
  final service = File('lib/features/invoice/statement_pdf_service.dart').readAsStringSync();
  final home = File('lib/features/home/home_shell.dart').readAsStringSync();
  if (!service.contains("headers: const ['نېټه', 'معامله', 'یادښت', 'ډېبټ', 'کریډیټ', 'بیلانس']")) {
    throw StateError('Statement PDF must expose a note column');
  }
  if (!service.contains('r.note,')) {
    throw StateError('Statement PDF must render the row note');
  }
  if (!service.contains('required this.note')) {
    throw StateError('StatementPdfRow must require note');
  }
  if (!home.contains("note:'\${r['note']??''}'")) {
    throw StateError('Home statement printer must pass ledger note into PDF rows');
  }
  print('statement_pdf_note_contract_test: PASS');
}
