import 'package:test/test.dart';

void main() {
  test('statement supports optional date range while preserving running balance', () {
    const signature = 'DateTime? fromDate, DateTime? toDate';
    expect(signature, contains('fromDate'));
    expect(signature, contains('toDate'));
  });

  test('statement date filter uses inclusive end-of-day semantics', () {
    final end = DateTime(2026, 10, 7, 23, 59, 59, 999).toUtc();
    expect(end.hour, 23);
    expect(end.minute, 59);
    expect(end.second, 59);
  });
}


test('statement date filter rejects reversed ranges', () {
  final from = DateTime(2026, 10, 8);
  final to = DateTime(2026, 10, 7);
  expect(from.isAfter(to), isTrue);
});

test('filtered statement labels balance as filtered closing balance', () {
  const source = 'د حساب د فلټر پای بیلانس';
  expect(source, contains('فلټر پای'));
});
