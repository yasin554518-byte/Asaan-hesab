from pathlib import Path

src = Path('lib/features/home/management_pages.dart').read_text()
assert "if (!mounted) return; setState(() => saving = true);" in src
assert "if (result != true || name.text.trim().isEmpty) { for (final c in [name, phone, address, cost, sale, stock, minStock, barcode, part, sku]) { c.dispose(); } return; }" in src
print('expense_and_crud_lifecycle_contract_test: PASS')
