from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
text = (ROOT / "lib/features/home/management_pages.dart").read_text()
needle = "if(r.errors.isEmpty && mounted) setState(()=>preview=null);"
assert needle in text, "CSV import preview clear must be mounted-guarded after await"
print("PASS: csv import post-await mounted guard")
