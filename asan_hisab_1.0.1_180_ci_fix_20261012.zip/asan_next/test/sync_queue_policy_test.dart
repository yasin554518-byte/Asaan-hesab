import 'package:flutter_test/flutter_test.dart';
import 'package:asan_hisab/core/sync/sync_queue_service.dart';

void main() {
  test('retry backoff is bounded exponential', () {
    expect(SyncQueueService.retryDelayMinutes(0), 1);
    expect(SyncQueueService.retryDelayMinutes(1), 2);
    expect(SyncQueueService.retryDelayMinutes(2), 4);
    expect(SyncQueueService.retryDelayMinutes(3), 8);
    expect(SyncQueueService.retryDelayMinutes(4), 16);
    expect(SyncQueueService.retryDelayMinutes(5), 16);
    expect(SyncQueueService.retryDelayMinutes(99), 16);
  });

  test('negative retry count is treated as first retry', () {
    expect(SyncQueueService.retryDelayMinutes(-5), 1);
  });
}
