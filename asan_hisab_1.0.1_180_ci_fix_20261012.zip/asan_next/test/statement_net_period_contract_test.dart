import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  if (!source.contains("filteredClosing-periodOpening")) {
    throw StateError(
      'Statement net summary must compare filtered closing balance '
      'against period opening balance.',
    );
  }
  if (source.contains("filteredClosing-opening")) {
    throw StateError(
      'Statement net summary must not compare a filtered closing balance '
      'against the party original opening balance.',
    );
  }
  print('PASS: Statement net summary uses periodOpening.');
}
