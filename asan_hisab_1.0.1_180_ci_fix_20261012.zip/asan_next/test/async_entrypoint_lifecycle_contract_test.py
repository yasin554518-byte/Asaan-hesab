from pathlib import Path
s=Path('lib/features/home/home_shell.dart').read_text()
checks=[
('backup guard', 'Future<void> backup() async {\n    if (!mounted) return;\n    setState(() => busy = true);'),
('restore guard', 'Future<void> restore() async {\n    if (!mounted) return;\n    await _loadLatestBackup();\n    if (!mounted) return;'),
('verify guard', 'Future<void> verify() async {\n    if (!mounted) return;\n    setState(() => busy = true);'),
('settings guard', 'Future<void> save() async {\n    if (name.text.trim().isEmpty) return;\n    if (!mounted) return;\n    setState(() => saving = true);')]
for n,x in checks:
    assert x in s, n
print('PASS: async entry-point lifecycle guards')
