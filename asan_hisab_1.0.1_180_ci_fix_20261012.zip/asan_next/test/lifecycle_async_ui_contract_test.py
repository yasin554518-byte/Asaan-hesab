from pathlib import Path

p=Path('lib/features/home/home_shell.dart').read_text()
assert "if (!mounted) return;\n    baseUrl.text = url;" in p
assert "void _msg(String text) {\n    if (!mounted) return;" in p
assert "void refresh() {\n    if (!mounted) return;" in p
print('lifecycle async UI contract: PASS')
