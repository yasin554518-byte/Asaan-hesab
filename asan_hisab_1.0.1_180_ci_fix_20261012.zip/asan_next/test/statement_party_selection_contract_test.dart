import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  if (!source.contains("final selectedPartyId=parties.any((x)=>x['id']==partyId)?partyId:null;")) {
    throw StateError('Statement party selector must null invalid/deleted initial party IDs');
  }
  if (!source.contains('value:selectedPartyId')) {
    throw StateError('Statement party selector must use normalized selected party ID');
  }
  stdout.writeln('PASS: statement party selection contract');
}
