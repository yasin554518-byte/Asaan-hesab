import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  if (!source.contains("'entry_type': 'MANUAL_LOAN'")) {
    throw StateError('manual loan entry missing');
  }
  if (!source.contains("'note': note.text.trim()")) {
    throw StateError('manual loan note is not persisted in ledger entry');
  }
}
