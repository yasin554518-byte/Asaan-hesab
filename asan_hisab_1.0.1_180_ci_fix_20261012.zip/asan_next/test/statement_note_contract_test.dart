import 'package:test/test.dart';

void main() {
  test('statement rows expose transaction note for ledger history', () {
    const selectedColumns = 'id, date, created_at, entry_type, debit, credit, reference_type, reference_id, note';
    expect(selectedColumns, contains('note'));
    expect(selectedColumns, contains('created_at'));
  });
}
