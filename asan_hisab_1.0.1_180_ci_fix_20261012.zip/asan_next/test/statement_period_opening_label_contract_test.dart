import 'dart:io';

void main() {
  final source = File('lib/features/home/home_shell.dart').readAsStringSync();
  const expected = "ListTile(title:const Text('د فلټر د پیل بیلانس'),trailing:Text('\$periodOpening'))";
  if (!source.contains(expected)) {
    throw StateError('Statement opening-balance label must explicitly identify the filtered-period opening balance');
  }
  if (source.contains("ListTile(title:const Text('د پیل بیلانس'),trailing:Text('\$periodOpening'))")) {
    throw StateError('ambiguous Statement opening-balance label remains');
  }
  print('PASS: Statement opening-balance label identifies filtered-period opening balance.');
}
