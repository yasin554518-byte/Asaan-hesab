from pathlib import Path
p=Path('lib/features/home/home_shell.dart').read_text()
assert "Future<void> retryFailed() async {\n    if (!mounted) return;\n    setState(() => busy = true);" in p
assert "Future<void> syncNow() async {\n    if (!mounted) return;\n    setState(() { busy = true; statusText = 'Sync روان دی...'; });" in p
print('PASS: sync status async entry lifecycle guards')
