from pathlib import Path
s = Path('lib/features/home/home_shell.dart').read_text()
needle = 'final items=await widget.database.db.query(type=='"'"'SALE_RETURN'"'"'?'"'"'sale_items'"'"':'"'"'purchase_items'"'"''
pos = s.index(needle)
segment = s[pos:s.index('void selectProduct', pos)]
assert '!mounted' in segment
assert segment.index('!mounted') < segment.index('setState(() {')
print('PASS: Returns selection lifecycle contract')
