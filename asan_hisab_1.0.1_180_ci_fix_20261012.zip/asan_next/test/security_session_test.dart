import 'package:flutter_test/flutter_test.dart';
import 'package:asan_hisab/core/security/session_service.dart';

void main() {
  test('session starts unlocked and touch keeps it alive', () async {
    var locks = 0;
    final session = SessionService(
      timeout: const Duration(milliseconds: 60),
      onLocked: () => locks++,
    );

    session.start();
    expect(session.locked, isFalse);

    await Future<void>.delayed(const Duration(milliseconds: 35));
    session.touch();
    await Future<void>.delayed(const Duration(milliseconds: 35));
    expect(session.locked, isFalse);
    expect(locks, 0);

    await Future<void>.delayed(const Duration(milliseconds: 40));
    expect(session.locked, isTrue);
    expect(locks, 1);
    session.dispose();
  });

  test('lock is idempotent and cancels the timer', () async {
    var locks = 0;
    final session = SessionService(
      timeout: const Duration(milliseconds: 30),
      onLocked: () => locks++,
    );

    session.start();
    session.lock();
    session.lock();
    expect(session.locked, isTrue);
    expect(locks, 1);

    await Future<void>.delayed(const Duration(milliseconds: 50));
    expect(locks, 1);
    session.dispose();
  });

  test('start reopens a locked session and replaces the old timer', () async {
    var locks = 0;
    final session = SessionService(
      timeout: const Duration(milliseconds: 50),
      onLocked: () => locks++,
    );

    session.start();
    session.lock();
    expect(session.locked, isTrue);

    session.start();
    expect(session.locked, isFalse);
    await Future<void>.delayed(const Duration(milliseconds: 20));
    expect(session.locked, isFalse);
    expect(locks, 1);

    await Future<void>.delayed(const Duration(milliseconds: 45));
    expect(session.locked, isTrue);
    expect(locks, 2);
    session.dispose();
  });
}
