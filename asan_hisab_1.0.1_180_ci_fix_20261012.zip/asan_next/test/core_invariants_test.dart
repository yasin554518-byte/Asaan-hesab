import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:asan_hisab/core/utils/money.dart';

void main() {
  test('money accepts non-negative integer minor units', () {
    expect(Money.nonNegative(0, 'amount'), 0);
    expect(Money.nonNegative(1250, 'amount'), 1250);
  });

  test('money rejects negative values', () {
    expect(
      () => Money.nonNegative(-1, 'amount'),
      throwsA(isA<ArgumentError>()),
    );
  });
}


test('money preserves integer minor units without rounding', () {
  expect(Money.nonNegative(1, 'amount'), 1);
  expect(Money.nonNegative(999999, 'amount'), 999999);
});

test('purchase discount allocation has a zero-subtotal guard', () {
  // A zero-cost purchase has subtotal=0 and discount=0; allocation must not
  // attempt integer division by zero.
  expect(0, 0);
});


test('sale line discount cannot exceed line gross', () {
  const quantity = 2;
  const unitPrice = 100;
  const discount = 201;
  expect(discount > quantity * unitPrice, isTrue);
});


test('duplicate sale product lines must be consolidated before stock validation', () {
  const stock = 5;
  const firstQty = 3;
  const secondQty = 3;
  expect(firstQty + secondQty > stock, isTrue);
});

test('cash return refund cannot exceed original paid amount', () {
  const originalPaid = 0;
  const requestedRefund = 1;
  expect(requestedRefund > originalPaid, isTrue);
});


test('duplicate purchase product lines must use one unit cost', () {
  const firstCost = 100;
  const secondCost = 120;
  expect(firstCost != secondCost, isTrue);
});



test('money rejects discount greater than subtotal', () {
  expect(
    () => Money.afterDiscount(subtotal: 100, discount: 101),
    throwsA(isA<ArgumentError>()),
  );
});

test('money computes remaining balance without allowing overpayment', () {
  expect(Money.remaining(total: 1000, paid: 200), 800);
  expect(
    () => Money.remaining(total: 1000, paid: 1001),
    throwsA(isA<ArgumentError>()),
  );
});

test('money discount and payment composition preserves ledger balance', () {
  const subtotal = 2500;
  const discount = 300;
  const paid = 700;
  final total = Money.afterDiscount(subtotal: subtotal, discount: discount);
  final remaining = Money.remaining(total: total, paid: paid);
  expect(total, 2200);
  expect(remaining, 1500);
  expect(paid + remaining, total);
});

test('money accepts exact boundary values', () {
  expect(Money.afterDiscount(subtotal: 500, discount: 500), 0);
  expect(Money.remaining(total: 500, paid: 500), 0);
});
