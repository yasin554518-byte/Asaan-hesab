from pathlib import Path
p=Path('lib/features/home/home_shell.dart')
s=p.read_text(encoding='utf-8')
assert s.count('if (!mounted) return;') >= 2
assert 'showDatePicker(context:context, initialDate:fromDate' in s
assert 'showDatePicker(context:context, initialDate:toDate' in s
print('statement date-picker lifecycle contract: PASS')
