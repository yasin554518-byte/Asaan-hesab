# Asan Hisab v158

Version: 1.0.1+144

## Change
- Statement UI now displays the filtered period opening balance in the primary “د پیل بیلانس” row instead of the unfiltered party opening balance.
- Added a source-level regression contract for this display invariant.
