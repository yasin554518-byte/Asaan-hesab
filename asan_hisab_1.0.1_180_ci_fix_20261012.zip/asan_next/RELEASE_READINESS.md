# Asan Hisab — Release Readiness

## Automated CI gate
The repository CI now bootstraps the Android host project with Flutter, then runs:
- `flutter pub get`
- `dart analyze`
- `flutter test`
- `flutter build appbundle --release`
- Backend Python compile
- Backend contract test

The successful AAB is uploaded as a CI artifact named `asan-hisab-release-aab`.

## Important publication setting
`tool/prepare_android.sh` currently uses the Android application id `com.asanhisab.app` via Flutter's `--org com.asanhisab`. **Confirm the final application id before the first Play Store publication**, because changing it later creates a different Android application.

## What CI cannot prove
- Two physical Android devices syncing over a real HTTPS deployment
- Play Console signing/upload configuration and store listing
- Real-device camera, PDF printer, notification, storage, and RTL behavior
- Production database backup/restore under real traffic
- Performance at 10k products / 10k customers / 50k transactions

Those checks remain explicit release gates rather than being marked as passed automatically.

## v1.0.1+4 hardening
- Backend container runs as a non-root user.
- Backend and Compose expose a health check for `/health`.
- CI builds the container and starts it for an HTTP health smoke test.
- Android AAB remains unsigned unless signing secrets are configured in the CI environment; Play publication still requires the user's own signing/upload configuration.

## v1.0.1+5 release-operations hardening
- Added a production-oriented Nginx HTTPS reverse-proxy example.
- Added an online SQLite backup helper for the Docker deployment and SHA-256 backup checksums.
- Added an explicit Android application-id verification gate to CI.
- Added release signing/deployment documentation hooks without embedding any private signing key.

## v1.0.1+10 active baseline
- Active package version: `1.0.1+10`.
- CI now checks release-version consistency before other source/release gates.
- Historical release notes are retained, but the active release baseline is explicitly separated from them.

## v1.0.1+10 automatic sync hardening
- Foreground auto-sync retries every 5 minutes when an authenticated HTTPS backend is configured.
- Sync also runs when the app returns to the foreground.
- Auto-sync failures are isolated from local/offline bookkeeping.


## v1.0.1+10 release-artifact gate
- CI verifies the expected active version and application ID.
- CI checks that the release AAB exists and records its SHA-256 checksum.
- No private signing material is committed to the repository.

## v1.0.1+23 production endpoint smoke gate
- Added `tool/production_endpoint_smoke.sh` for a real deployed HTTPS sync endpoint.
- The gate requires an `https://` endpoint, a non-placeholder smoke token, a valid business/device pair, HTTP 200 health, HTTP 401 for an unauthenticated pull, and HTTP 200 for an authenticated pull.
- Smoke credentials are supplied only through the deployment/CI environment and are never stored in the repository.


## v1.0.1+25 tagged-release production smoke gate
- Tagged releases now run `tool/production_endpoint_smoke.sh` after the Flutter and backend jobs complete.
- The gate requires `ASAN_SYNC_BASE_URL`, `ASAN_SYNC_SMOKE_TOKEN`, `ASAN_SYNC_SMOKE_BUSINESS_ID`, and `ASAN_SYNC_SMOKE_DEVICE_ID` as CI secrets.
- It validates the deployed HTTPS endpoint, unauthenticated rejection, and authenticated pull before a tagged release can be considered production-ready.

- v52 two-device sync replay/cursor contract gate added.

- v54 production API security headers contract gate added; HSTS is emitted only when HTTPS is explicitly indicated by the reverse proxy.
