# Asan Hisab v163

Version: 1.0.1+149

## Changes
- Added a user-visible error message when Statement PDF generation/printing fails.
- Preserved the existing financial, filtering, PDF, and Sync semantics.
