# Asan Hisab automatic sync

The app performs best-effort automatic cloud synchronization while the authenticated Flutter session is alive:

- immediately when the session starts;
- every 5 minutes while the session remains active;
- immediately when the app returns to the foreground;
- overlapping sync runs are coalesced;
- transient sync errors never interrupt local/offline bookkeeping.

A true operating-system scheduled background job (for example Android WorkManager) is intentionally not claimed here because the source archive does not contain a checked-in Android host project; CI generates the Android host during build. The OS-level worker should be added and tested as part of the real Android build/device gate rather than represented as already complete.
