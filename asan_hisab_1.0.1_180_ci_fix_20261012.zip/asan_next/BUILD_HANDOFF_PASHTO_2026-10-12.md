# د آسان حساب د APK جوړولو لارښود — ۲۰۲۶/۱۰/۱۲

## اوسنی حالت

- د پروژې هدف نسخه: `1.0.1+180`
- Android application ID: `com.asanhisab.app`
- د QA APK لپاره GitHub Actions workflow: `.github/workflows/qa-apk.yml`
- د Release AAB لپاره workflow: `.github/workflows/ci.yml`
- په دې چاپېریال کې Flutter، Dart، Android SDK او ADB نشته؛ نو دلته APK/AAB نه شي جوړېدای.
- په دې نوبت کې ۲۷ قرارداد ازموینې بریالۍ شوې؛ د ټولو ۶۰ ازموینو د بشپړې اجرا هڅه د چاپېریال د وخت له حد سره مخ شوه. دا د ټولو ازموینو د بریا ادعا نه ده.

## د APK ترلاسه کولو واقعي لاره

۱. ZIP په کمپیوټر یا GitHub Codespaces کې خلاص کړئ؛ د `asan_next/` دننه ټول فایلونه د GitHub repository په اصلي فولډر کې واچوئ، نه دا چې ZIP د repository په توګه پورته کړئ.

۲. په repository کې `main` یا `master` branch ته فایلونه commit/push کړئ. د `.github/workflows/qa-apk.yml` فایل باید هم ورسره وي.

۳. په GitHub کې repository پرانیزئ، **Actions → QA Android APK → Run workflow** وټاکئ. که فایلونه `main` یا `master` ته push شي، workflow په خپله هم پیلېږي.

۴. تر هغې انتظار وکړئ چې workflow شین/بریالی شي. د run په پاڼه کې د **Artifacts** برخه کې `asan-hisab-qa-apk-...` فایل ښکته کړئ. په ZIP کې به `app-debug.apk` وي.

۵. APK په Android موبایل کې نصب او لاندې موارد په لاس وازمویئ: نوی حساب، قرض زیاتول، تادیه ثبتول، پاتې بیلانس، راپور/statement، backup/restore او د دوو موبایلونو sync.

## د خپرولو (Release) لپاره

- د QA debug APK د Play Store وروستی خپرېدونکی فایل نه دی.
- د `v*` tag لپاره `ci.yml` د release AAB جوړوي او د Android signing secrets او production smoke secrets غوښتنه کوي.
- د signing keys او secrets ارزښتونه په چټ کې مه شریکوئ. په GitHub repository settings کې یې خوندي کړئ.
- تر بریالي Flutter analyze/test، AAB build، او حقیقي Android/device sync ازموینې مخکې نسخه د بشپړې شوې په توګه مه اعلانوی.

## څه چې له دې چاپېریاله نه دي ترسره شوي

- GitHub repository ته push یا workflow run نه دی شوی؛ دلته د repository remote/credentials شتون نه و.
- APK/AAB نه دی جوړ شوی.
- د دوو حقیقي موبایلونو ترمنځ sync نه دی تایید شوی.
