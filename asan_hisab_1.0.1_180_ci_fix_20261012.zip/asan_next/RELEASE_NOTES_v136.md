# Asan Hisab v136

Version: 1.0.1+123

- Made financial sync queue insertion atomic with local payment/receipt records.
- Customer receipts and supplier payments now enqueue payment, ledger, and cash records in the same SQLite transaction.
- Manual customer loan additions now enqueue their ledger record atomically.
- Added transaction-scoped device identity resolution for safe first-use sync setup.
- Added regression coverage through source/contract release gates.

Known environment limits: Flutter/Dart SDK and a real Android device are not available in the current build environment, so AAB/device tests remain pending.
