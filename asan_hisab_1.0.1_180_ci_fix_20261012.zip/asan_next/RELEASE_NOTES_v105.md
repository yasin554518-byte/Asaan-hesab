# Asan Hisab v105

- Version: 1.0.1+91
- Hardened release bundle published-artifact identity length to the same 128-character ceiling used by provenance schema validation.
- Added regression coverage rejecting an overlong published artifact identity.
- Android AAB build not executed because Flutter/Android SDK is unavailable in this environment.
- Production deployment not executed because production secrets/environment are unavailable.
