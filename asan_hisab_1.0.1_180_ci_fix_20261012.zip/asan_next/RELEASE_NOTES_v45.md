# Release Notes v45

- Hardened sync response buffering to avoid duplicate byte copies.
- Rejects oversized responses immediately when Content-Length exceeds 8 MiB.
- Still enforces the 8 MiB streaming cap when Content-Length is unknown.
- Version: 1.0.1+32.
