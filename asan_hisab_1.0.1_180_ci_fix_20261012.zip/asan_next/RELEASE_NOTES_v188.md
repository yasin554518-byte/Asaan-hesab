# Release Notes v188

Version: 1.0.1+171

- Hardened Alerts refresh against post-dispose async completion.
- Hardened Sync Status post-await state mutation with a mounted guard.
- Added regression contract for both post-await lifecycle paths.
