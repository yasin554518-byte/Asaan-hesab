# Asan Hisab — Source Smoke QA

This check is intentionally toolchain-independent. It does not replace `flutter test`, `dart analyze`, a release build, or real-device QA.

Run from the project root:

```bash
./tool/smoke_check.sh
```

The check verifies that the core database/security/accounting/sync files exist, schema version 4 is declared, required SQLite/accounting references are present, and an obvious plaintext numeric PIN pattern is not present in `lib/`.

Release still requires Flutter SDK, analyzer/tests, Android AAB build, real-device backup/restore, two-device authenticated sync, and financial reconciliation tests.
