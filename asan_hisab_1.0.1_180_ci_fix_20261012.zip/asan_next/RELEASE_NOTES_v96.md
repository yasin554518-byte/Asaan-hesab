
## v96

- Hardened provenance identity schema validation.
- Added regression coverage for invalid commit SHA and workflow run ID.
- Version 1.0.1+82.
