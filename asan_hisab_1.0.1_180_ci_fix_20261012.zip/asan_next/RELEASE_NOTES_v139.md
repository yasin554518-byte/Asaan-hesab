# Asan Hisab v139

Version 1.0.1+125.

- Made party statement ordering deterministic for same-timestamp ledger entries.
- Running balance now follows date, created_at, then id ordering.
- Added a statement-order contract gate.
- Flutter/AAB/device gates remain environment-dependent when the SDK/device is unavailable.
