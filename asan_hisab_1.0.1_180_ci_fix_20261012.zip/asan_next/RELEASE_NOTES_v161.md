# Asan Hisab v161 — 1.0.1+147

- Hardened Statement PDF note mapping so nullable/blank ledger notes become an empty string instead of ever rendering a literal `null`.
- Added a source-level regression contract for nullable Statement PDF notes.
