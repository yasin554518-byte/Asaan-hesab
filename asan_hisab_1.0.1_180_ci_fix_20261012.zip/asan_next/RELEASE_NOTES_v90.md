# Asan Hisab v1.0.1+76 — Release Metadata Safety

- Added release bundle manifest metadata safety validation.
- Duplicate manifest keys are rejected instead of silently overwritten.
- Control characters in manifest values are rejected to prevent malformed or ambiguous release metadata.
- Added CI and final-preflight contract coverage for the safety gate.
