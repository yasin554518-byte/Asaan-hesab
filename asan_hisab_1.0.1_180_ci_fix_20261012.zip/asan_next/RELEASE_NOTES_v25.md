# Asan Hisab v25 — Sync Retry Reliability

- Fixed Dart retry-backoff type handling in `SyncQueueService`.
- Centralized the bounded exponential retry policy in a testable helper.
- Added unit tests for 1/2/4/8/16 minute retry delays and edge cases.
- Made release version checks derive from `pubspec.yaml` instead of stale hard-coded build numbers.
- Final automated preflight passes without Flutter/Android SDK; Android build remains a real-environment gate.
- App build: `1.0.1+13`.
