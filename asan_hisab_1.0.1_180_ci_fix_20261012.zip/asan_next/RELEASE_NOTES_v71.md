# Asan Hisab v71

Version: `1.0.1+57`

## CI Artifact Retention Gate
- Release AAB/checksum/provenance uploads now declare an explicit 14-day artifact retention period.
- Added `tool/ci_artifact_retention_contract_test.sh` to prevent accidental omission or excessive retention.
- Release artifact remains tag-gated and includes only the intended release files.
