# Asan Hisab v47

- Fixed the production smoke environment-variable contract: GitHub Actions `ASAN_PRODUCTION_*` secrets are now consumed by the smoke script (legacy `ASAN_SYNC_*` names remain accepted for compatibility).
- Production smoke now validates JSON content type and key security/cache headers on health and authorized pull responses.
- Version: 1.0.1+33.
