# Asan Hisab v98

- Version: 1.0.1+84.
- Tightened release-bundle manifest validation for semantic app version and exact tag-to-version identity.
- Added safe-length bounds for workflow/event identity fields.
- Existing release, sync, checksum, provenance, and backend gates retained.
