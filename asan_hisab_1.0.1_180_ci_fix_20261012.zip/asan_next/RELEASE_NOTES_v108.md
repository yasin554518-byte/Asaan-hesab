# Asan Hisab v108

- Version: 1.0.1+94
- Tightened release bundle manifest validation: artifact_size_bytes must be a positive decimal integer with no sign or leading zero.
- Added an artifact-size regression contract test covering valid, signed, and leading-zero values.
- Existing provenance, checksum, bundle identity, backend, and release preflight gates remain required.
