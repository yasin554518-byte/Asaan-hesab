# v70 — CI Release Artifact Upload Contract Gate

- Version: `1.0.1+56`
- Added a CI contract test that verifies release artifact upload is tag-gated and contains the AAB, checksum, and release provenance.
- Prevents accidental removal or duplication of release artifacts in the workflow.
- Existing release, security, sync, backup/restore, signing, and provenance gates remain unchanged.
