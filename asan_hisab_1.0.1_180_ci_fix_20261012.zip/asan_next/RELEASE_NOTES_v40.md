# Asan Hisab v1.0.1+27 — Release Signing Preflight Hardening

- Added early validation of the injected Android release keystore with `keytool` before Flutter/Gradle build.
- Invalid keystore credentials now fail the release pipeline before the expensive AAB build step.
- Extended Android signing contract coverage for the early keystore validation.
- Version bumped to 1.0.1+27.

Local verified gates: source smoke, release static, secret-material protection, Android signing contract, CI tag/signing contract, release candidate, backend contract tests, and final release preflight. Production HTTPS remains deployment-dependent; Flutter AAB remains CI-dependent because Flutter SDK is not installed in this runtime.
