# Asan Hisab v1.0.1+6 — Release Notes

## Hardening
- Added standard security response headers to Sync API responses.
- Production SQLite backup helper now fails clearly when the service container is unavailable.
- Backup helper supports configurable retention with `RETENTION_DAYS` (default 30 days).
- Backup checksums remain SHA-256 and old backup/checksum pairs are pruned together.

## Verified locally
- Python compile
- Backend contract tests
- Source smoke check
- Release static check

## Not claimed as locally verified
- Flutter AAB build (requires Flutter/Android SDK)
- Real two-device HTTPS sync
- Production Docker deployment
- Play Console publication
