# Asan Hisab v46

Version: 1.0.1+32

- Added a real Docker container health smoke gate to backend CI after image build.
- The gate waits for the image HEALTHCHECK to become healthy, fails on unhealthy containers, and probes `/health` over the published port.
- Keeps the existing Android signing, release-tag, production HTTPS, sync security, and secret-material gates unchanged.
