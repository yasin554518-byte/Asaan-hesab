# Asan Hisab v178 — 1.0.1+162

- Added lifecycle safety before Payment save state mutation.
- Added lifecycle safety before Sync test state mutation.
- Preserved mounted guard after asynchronous Sync clear.
- Release metadata advanced from v177.
