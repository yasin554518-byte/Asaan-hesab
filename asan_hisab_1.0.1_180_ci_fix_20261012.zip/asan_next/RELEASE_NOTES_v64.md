# Asan Hisab v64 — CI Release Contract Alignment Gate

- Version: 1.0.1+50
- Aligns active release contract tests with the current application version.
- Removes stale hard-coded v48/v49 expectations from release bundle, provenance, and tag-integrity contracts.
- Keeps release provenance tag/ref derived from GitHub environment variables.
- No signing keys, tokens, or production secrets are stored in source.
