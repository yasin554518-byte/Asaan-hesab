# Asan Hisab v166 — 1.0.1+152

- Cached the Statement customer/supplier list future so ordinary rebuilds do not repeat the parties database query.
- Added a source-level regression contract for parties Future caching.
