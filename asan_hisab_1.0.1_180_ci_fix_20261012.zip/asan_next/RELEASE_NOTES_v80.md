# Asan Hisab v80

- Version: 1.0.1+68
- Strengthened release bundle manifest with release ref, workflow run ID, and workflow run attempt.
- Added contract coverage for the new audit metadata.


- Superseded by v81.
