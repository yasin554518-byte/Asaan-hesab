# Asan Hisab v126

- Version: 1.0.1+112
- Centralized SyncScheduler retry-delay calculation through SyncQueueService.retryDelayMinutes so durable queue and scheduler policies cannot drift.
- Added scheduler retry-policy contract coverage.
- Android AAB build was not executed because Flutter/Android SDK is unavailable in this environment.
- Production deployment was not executed because production environment/secrets are unavailable.
