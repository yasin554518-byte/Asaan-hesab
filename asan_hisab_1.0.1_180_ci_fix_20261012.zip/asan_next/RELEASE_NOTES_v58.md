# Release Notes v58 — Production Container Security Gate

- Version: 1.0.1+44.
- Added a production Docker Compose profile with no direct host port publishing.
- Production container uses a read-only root filesystem, drops all Linux capabilities, and enables `no-new-privileges`.
- Added a constrained `/tmp` tmpfs and disabled Python bytecode writes for the production container.
- Added `production_container_security_contract_test.sh` covering container privilege, filesystem, network exposure, and TLS reverse-proxy invariants.
