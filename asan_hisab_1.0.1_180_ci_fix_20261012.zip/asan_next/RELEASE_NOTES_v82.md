# Asan Hisab v82

- Version: 1.0.1+68
- Release bundle manifest upgraded to schema version 3.
- Manifest records the Git commit SHA for stronger release-to-source traceability.
- Commit SHA is validated when running in GitHub Actions.
- Bundle manifest contract is included in final automated preflight.
