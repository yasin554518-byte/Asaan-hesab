# Release Notes — v142

- Version: 1.0.1+129
- Fixed aggregate ledger balance calculation when a party has both debit and credit history.
- Added aggregate debit/credit invariant coverage for customer and supplier balances.
