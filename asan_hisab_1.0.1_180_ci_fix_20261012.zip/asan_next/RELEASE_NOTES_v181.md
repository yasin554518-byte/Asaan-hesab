# Asan Hisab v181

Version: 1.0.1+165

## Changes
- Added mounted guard before async Backup/Restore/Verify state changes.
- Added mounted guard before Settings save state change.
- Added regression contract for async entry-point lifecycle safety.

## Validation
- Static/source contracts
- Version consistency
- Backup verification/recovery contracts
- ZIP integrity
