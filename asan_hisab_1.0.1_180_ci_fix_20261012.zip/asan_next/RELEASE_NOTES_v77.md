# Asan Hisab v77

Version: 1.0.1+63

## CI release artifact rerun safety
- Release artifact names include the release tag, immutable workflow run ID, and `github.run_attempt`.
- This keeps `overwrite: false` safe across workflow reruns of the same GitHub Actions run.
- CI contract checks require the rerun discriminator.
