# Asan Hisab v168 — 1.0.1+154

- Reused a single StatementService instance within Statement load/print operations to avoid duplicate service construction while preserving existing query semantics.
- Added a source regression contract for StatementService reuse.
