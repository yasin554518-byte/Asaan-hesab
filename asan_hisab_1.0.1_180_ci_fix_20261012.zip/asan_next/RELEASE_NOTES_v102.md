# Asan Hisab v102

Version: 1.0.1+88

- Hardened release provenance identity validation with safe character allowlists for workflow and event identity fields.
- Applied the same safe-character contract to the release bundle manifest.
- Existing length and identity checks remain enforced.
