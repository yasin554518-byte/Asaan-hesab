# Asan Hisab v123

- Version: 1.0.1+109
- Fixed duplicate Flutter `initState()` declarations in Settings, Alerts, Sync configuration, and Sync status pages.
- Removed stray `_loadLatestBackup()` calls from pages that do not own backup discovery.
- Added a brace-aware Stateful lifecycle contract test and wired it into final release preflight.
- Existing sync, backup, security, backend, checksum, and release gates retained.
