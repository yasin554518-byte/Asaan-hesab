# Asan Hisab v1.0.1+30 — Sync Response Safety Gate

- Sync client now requires JSON responses from the server.
- Sync client caps a server response at 8 MiB before decoding it, preventing unbounded response buffering.
- Version bumped to 1.0.1+30.
