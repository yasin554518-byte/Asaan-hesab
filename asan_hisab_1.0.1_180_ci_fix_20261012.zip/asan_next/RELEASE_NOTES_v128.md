# Asan Hisab v128

Version: 1.0.1+114

## Sync queue hardening
- Made queue enqueue idempotent under concurrent callers by using the existing unique operation index with a conflict-safe insert.
- The canonical queue row ID is returned after the insert/ignore path, preventing duplicate-operation races from surfacing as failures.

## Validation
- Static/release/sync contract gates are run against this release candidate.
- Android AAB build remains unavailable in environments without Flutter/Android SDK.
