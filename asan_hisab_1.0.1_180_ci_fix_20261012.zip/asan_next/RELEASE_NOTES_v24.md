# Asan Hisab v24

## Sync reliability hardening
- Added bounded exponential retry backoff for failed sync queue items (1–30 minutes).
- Transport/server failures now move attempted pending operations into retry state instead of repeatedly re-sending as pending.
- Offline/local bookkeeping remains independent of sync availability.
- Version: 1.0.1+11.
