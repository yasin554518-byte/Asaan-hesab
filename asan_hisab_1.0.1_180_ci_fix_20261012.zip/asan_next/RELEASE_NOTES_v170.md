# v170 — 1.0.1+156

## Change
- Hardened Sale save error handling against widget disposal: the error SnackBar is now shown only while the Sale page remains mounted.
- Prevents post-dispose context access after an awaited sale transaction.

## Validation
- Static release checks and lifecycle contract test passed.
