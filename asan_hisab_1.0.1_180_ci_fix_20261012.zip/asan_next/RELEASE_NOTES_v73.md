# Asan Hisab v73

## CI Release Artifact Uniqueness Gate

- Release artifact names include both the release tag and GitHub run ID.
- Re-runs cannot collide with an earlier artifact name.
- Added a contract test for unique release artifact naming.
- Version: 1.0.1+62.
