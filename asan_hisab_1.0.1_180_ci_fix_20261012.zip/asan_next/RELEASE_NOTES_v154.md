# Asan Hisab v154

Version: 1.0.1+140

## Change
- Statement net summary now uses the filtered period opening balance (`periodOpening`) rather than the party's original opening balance.
- Added a source-level regression contract for the filtered net summary.
