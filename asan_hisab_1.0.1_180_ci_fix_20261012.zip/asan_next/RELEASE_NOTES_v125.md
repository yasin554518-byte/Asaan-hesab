# Asan Hisab v125

- Version: 1.0.1+111
- Aligned SyncScheduler automatic retry delays with the durable SyncQueue retry policy: 1, 2, 4, 8, and 16 minutes, capped by the configured 30-minute maximum.
- Kept the normal successful-sync interval independent from failure backoff.
- Added `sync_scheduler_retry_policy_contract_test.sh` and wired it into final release preflight.
- Android AAB build remains pending because Flutter/Android SDK is unavailable in the current build environment.
- Production smoke/deployment remains pending until production environment/secrets are supplied.
