# Asan Hisab v39

## Release hardening

- Aligned backend contract-test device tokens with the production preflight minimum token length (32+ characters).
- Keeps the revocation, business-isolation, duplicate-delivery, and concurrent-idempotency coverage unchanged.
- Prevents a false confidence gap where tests used short development tokens while production configuration required stronger token length.

Version: 1.0.1+25
