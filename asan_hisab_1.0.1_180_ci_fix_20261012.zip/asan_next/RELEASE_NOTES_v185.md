# Release Notes — v185

- Version: 1.0.1+169
- Hardened Sale, Purchase, and Payment SnackBar helper methods with mounted lifecycle guards.
- Prevents UI feedback calls from touching a disposed State object.
- Added a focused static lifecycle regression contract.
