# Release Notes v111

- Version: 1.0.1+97
- Hardened release provenance and bundle-manifest workflow run identity validation to require canonical positive decimal run IDs and attempts (or `local` in local fixtures).
- Added regression coverage rejecting zero and leading-zero workflow run identities.
