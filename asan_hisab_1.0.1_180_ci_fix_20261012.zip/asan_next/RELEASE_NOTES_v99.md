# Asan Hisab v99

- Version: 1.0.1+85.
- Tightened release bundle published-artifact identity validation with a strict canonical format and length bound.
- Added regression coverage through the release-bundle identity contract.
- Android AAB build remains a host-gated step when Flutter/Android SDK are unavailable.
- Production deployment remains environment-gated until production secrets/environment are supplied.
