# Asan Hisab v121

Version 1.0.1+107.

- Silenced expected stderr from the negative checksum path-safety fixture.
- The test still requires path-traversing checksum references to be rejected.
- This keeps release preflight output clean while preserving the security regression gate.
