# Release Notes v116

- Version: 1.0.1+102
- SyncScheduler now retains the last transport/sync error for diagnostics.
- Added `retryNow()` to bypass pending exponential backoff for an explicit immediate retry.
- Added a regression contract test for immediate retry and error diagnostics.
- Android AAB build remains gated on Flutter/Android SDK availability.
- Production deployment remains gated on production environment/secrets.
