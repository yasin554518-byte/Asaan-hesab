# Asan Hisab v68

## CI Checkout Credential Security Gate

- Version: 1.0.1+54
- All GitHub Actions checkout steps disable credential persistence.
- Added a contract test preventing accidental re-enablement.
- Existing release, provenance, sync, backup/restore, signing, and production security gates remain enabled.
