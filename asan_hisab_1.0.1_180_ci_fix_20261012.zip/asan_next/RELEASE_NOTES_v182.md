# Asan Hisab v182

Version: 1.0.1+166

- Product editor now rejects invalid or negative numeric values before database writes.
- Cost, sale price, opening stock, and minimum stock must be zero or positive integers.
- Added a regression contract for product numeric validation.
