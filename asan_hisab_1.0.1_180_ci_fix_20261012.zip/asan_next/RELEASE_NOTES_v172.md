# Asan Hisab v175

Version: 1.0.1+159

## Changes
- Hardened tag-only Android release signing secret validation in CI.
- Added release keystore configuration and AAB signature verification gates.
- Added release provenance and provenance-schema gates before artifact publication.
- Added tag-only production HTTPS smoke job with explicit dependencies on Flutter and backend jobs.
- Hardened CI workflow contract/checkout-security coverage.

## Validation
- CI release trigger safety: PASS
- CI signing trigger contract: PASS
- CI secret handling contract: PASS
- Android signing contract: PASS
- CI workflow contract: PASS
- CI workflow structure: PASS
- Checkout security contract: PASS
- Backend compile: PASS

Flutter/Dart SDK is unavailable in this runtime, so Flutter tests/AAB/device execution are not claimed as executed here.
