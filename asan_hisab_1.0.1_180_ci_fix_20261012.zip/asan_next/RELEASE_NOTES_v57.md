# Asan Hisab v57

## Production Environment Permission Gate

- Version: 1.0.1+43
- Production environment files containing live sync tokens must be owner-only (no group/other permissions).
- Added `tool/production_env_permissions_contract_test.sh` covering secure and group-readable file modes.
- Existing HTTPS, token entropy, duplicate-binding, signing, provenance, backup/restore, payload-safety, and two-device sync gates remain in place.
