# Asan Hisab v147

Version 1.0.1+133.

- Persist payment notes in the corresponding ledger entry so Statement shows the same note as the payment record.
- Added payment-note ledger contract coverage.
- Release hygiene: removed generated Python __pycache__ artifacts before packaging.
