# آسان حساب — د Android وروستي جوړولو عملي لارښود

نسخه: `1.0.1+180`  
Application ID: `com.asanhisab.app`

## اوسنی حالت
دا بسته د Flutter سرچینه او د جوړولو تنظیمات لري؛ APK/AAB پکې نه شته. په هغه چاپېریال کې چې دا بسته وکتل شوه، Flutter/Dart/Android SDK موجود نه وو او له همدې امله Android Release نه شو جوړېدای.

## د CI له لارې جوړول
1. دا پروژه په خپل شخصي GitHub repository کې پورته کړئ؛ secrets او signing keystore مه commit کوئ.
2. د GitHub Actions لپاره `.github/workflows/ci.yml` فعال کړئ.
3. د عادي CI لپاره د `main` څانګې push یا `workflow_dispatch` وکاروئ؛ workflow به Flutter 3.41.0، dependencies، `dart analyze` او `flutter test` اجرا کړي او AAB جوړ کړي.
4. د رسمي tag/release لپاره لومړی په خوندي ډول د Android signing secrets تنظیم کړئ:
   - `ANDROID_KEYSTORE_BASE64`
   - `ANDROID_KEY_ALIAS`
   - `ANDROID_KEYSTORE_PASSWORD`
   - `ANDROID_KEY_PASSWORD`
5. د release tag یوازې هغه وخت جوړ کړئ چې keystore د مالک تر کنټرول لاندې وي او رازونه د GitHub Actions Secrets کې وي.
6. د Actions run کې تایید کړئ چې `app-release.aab`، checksum، provenance او manifest تولید شوي؛ یوازې د بریالي run له artifact څخه یې واخلئ.

## په حقیقي Android وسیلو کې د منلو ازموینه
- APK د debug/QA لپاره جوړ او په Android موبایل کې نصب کړئ.
- نوی کاروبار/حساب جوړ کړئ، پور ثبت کړئ، یوه تادیه ثبت کړئ او پاتې بیلانس وګورئ.
- backup جوړ او په پاک نصب کې restore وازمویئ.
- دوه حقیقي موبایلونه د جلا device ID ګانو سره وصل کړئ؛ په دواړو لورو کې بدلونونه sync کړئ.
- انټرنېټ قطع/وصل، تکراري غوښتنه او د sync ناکامي وازمویئ؛ ډاډ ترلاسه کړئ چې duplicate معاملې او د معلوماتو ضایع کېدل نه پېښېږي.
- تر دې ازموینو مخکې اپلیکیشن بشپړ یا production-ready مه اعلانوی.

## د دې چاپېریال محدودیت
له دې ځایه GitHub repository ته لاسرسی یا CI اجرا نه ده تایید شوې؛ نو دا لارښود د build بریالیتوب ادعا نه کوي.

## د QA APK اتومات جوړول
- نوی workflow: `.github/workflows/qa-apk.yml`
- په GitHub کې Actions > QA Android APK > Run workflow وټاکئ، یا `main`/`master` ته push وکړئ.
- workflow د Flutter 3.41.0 سره Android چمتو کوي، `dart analyze` او `flutter test` چلوي، debug QA APK جوړوي او د ۷ ورځو لپاره یې artifact ساتي.
- دا QA/debug APK دی، د Play Store د production release بدیل نه دی. د production AAB لپاره اصلي `ci.yml` او د release signing secrets ته اړتیا ده.
