# Release v51 — Backup Restore/Recovery Gate

Version: 1.0.1+37

## Added
- Restore/recovery contract gate covering the live-database safety copy.
- Explicit verification that stale SQLite WAL/SHM sidecars are removed before replacement.
- Contract checks that restored databases are reopened and validated for SQLite integrity and schema version before the safety copy is deleted.
- Rollback invariant check confirming the pre-restore database is restored if replacement validation fails.
- Real shell/Python smoke test for a valid backup and rejection of a checksum-tampered backup.
- CI now runs the restore/recovery gate alongside the existing backup verification gate.

## Verification limits
- Flutter/Android SDK is not available in this runtime, so no local AAB or physical-device test is claimed.
- Production HTTPS and two-device end-to-end sync still require the real deployment environment.
