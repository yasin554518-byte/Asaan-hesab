# Asan Hisab v1.0.1+30 — JSON API Content-Type Gate

- Sync push now requires `Content-Type: application/json` and returns HTTP 415 for unsupported media types.
- Added a backend contract test for rejecting non-JSON push requests.
- Version bumped to 1.0.1+30.
