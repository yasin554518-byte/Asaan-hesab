# Asan Hisab v133 — Centralized Financial Arithmetic

Version: 1.0.1+120

## Changes
- Centralized discount and remaining-balance validation in the Money utility.
- Sale creation now uses the shared financial arithmetic guard instead of duplicating payment/remaining calculations.
- Added regression tests for over-discount and overpayment cases.
- Runtime behavior remains unchanged for valid transactions.
