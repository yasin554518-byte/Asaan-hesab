# Asan Hisab v1.0.1+7 — Release Preflight

Automated preflight executed from the source tree:

- Source smoke checks: PASS
- Release static invariants: PASS
- Android application-id gate: PASS (`com.asanhisab.app`)
- Release candidate checks: PASS
- Python compile: PASS
- Backend contract tests: PASS

## Explicit external gates still required

These are intentionally not marked as passed because they require a real Flutter/Android/production environment:

1. `flutter pub get`, `dart analyze`, `flutter test`
2. `flutter build appbundle --release`
3. Real HTTPS deployment and certificate validation
4. Two physical Android devices performing live sync
5. Real-device RTL, PDF/printing, storage and notification QA
6. Production backup/restore drill
7. Play Console signing/upload and store listing review

No private signing key or production credential is included in this release package.
