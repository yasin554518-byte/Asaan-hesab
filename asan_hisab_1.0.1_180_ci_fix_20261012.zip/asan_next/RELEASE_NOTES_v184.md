# Release Notes — v184

- Version: 1.0.1+168
- Added lifecycle guards before entering Sync Status retry/sync async operations.
- Added a regression contract for those entry guards.
- No change to Sync business semantics or cursor handling.
