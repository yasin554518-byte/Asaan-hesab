# Release Notes v59 — Release Artifact Provenance Consistency Gate

- Version: 1.0.1+45.
- Added `release_artifact_provenance_contract_test.sh` to verify the release artifact/provenance contract before a release is accepted.
- The gate checks that the CI workflow uploads the AAB checksum and provenance together, provenance contains only the expected non-secret fields, and the recorded AAB SHA-256 matches the artifact when an AAB is available.
- Added a deterministic fixture test for provenance schema, checksum matching, version matching, and rejection of secret-like fields.
- No production credentials, signing keys, or tokens are added to the release package.
