# Asan Hisab v30 — mandatory signed release gate

Version: `1.0.1+16`

## Changes
- Added a dedicated release-signing verification gate after the AAB build.
- Normal PR/branch CI can still build an unsigned AAB for source/test validation.
- Tagged releases (`v*`) now fail unless Android signing material is present and the produced AAB passes `jarsigner` verification.
- The gate validates the configured upload-key alias and keystore before accepting the AAB as a release artifact.
- No keystore, password, or private signing material is included in the project ZIP.
