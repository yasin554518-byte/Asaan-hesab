# Release v50 — Backup Creation Verification Gate

Version: 1.0.1+36

- Backup creation now immediately invokes `deploy/verify_backup.sh` after writing the SHA-256 sidecar.
- A backup is therefore rejected at creation time if its checksum, SQLite integrity, or required sync schema is invalid.
- Backup contract testing now ensures the creation script cannot silently skip the verification step.
- No production credentials, tokens, keystores, or private keys are stored in the repository.
- Flutter/Android AAB build and real-device/two-phone production sync remain environment-dependent and are not claimed as completed here.
