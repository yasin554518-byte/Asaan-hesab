# Asan Hisab v32 — strict release-tag version gate

Version: 1.0.1+19

- Release tags must exactly match the `pubspec.yaml` version using the `v<version>` form.
- A mismatched release tag now fails before the Android build is treated as releasable.
- Existing mandatory signed-AAB gate remains enabled for `v*` tags.
- No signing secrets are committed to the repository.
