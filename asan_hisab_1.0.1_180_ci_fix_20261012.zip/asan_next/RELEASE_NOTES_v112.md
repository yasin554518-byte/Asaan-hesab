# Asan Hisab v112

Version: 1.0.1+98

## Sync scheduler hardening
- Automatic sync now uses one-shot scheduling instead of a fixed periodic timer.
- Transient sync failures use bounded exponential backoff, capped by `maxRetryDelay`.
- A successful sync resets the retry counter and restores the normal interval.
- Overlapping sync runs remain coalesced and local/offline bookkeeping remains isolated from sync failures.
- Added regression coverage for failure tracking and successful retry reset.

## Validation
- Scheduler regression tests added.
- Android AAB and production deployment remain explicit environment-dependent gates.
