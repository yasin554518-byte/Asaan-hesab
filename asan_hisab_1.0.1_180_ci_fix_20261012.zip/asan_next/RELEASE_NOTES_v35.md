# Asan Hisab v35

- Strengthened backend sync contract coverage for concurrent duplicate delivery.
- Added an assertion that idempotency leaves exactly one `sync_operations` row under concurrent pushes.
- Reconfirmed token revocation isolation: revoked device remains blocked while a second device remains usable.
- Version: 1.0.1+21.
