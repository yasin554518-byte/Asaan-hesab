# Asan Hisab v106

Version: 1.0.1+92

- Added provenance schema regression coverage ensuring workflow run identity fields are strings, not JSON numbers.
- Existing duplicate-key, identity-character, length, release-ref, checksum, bundle, sync, and security gates remain enforced.
