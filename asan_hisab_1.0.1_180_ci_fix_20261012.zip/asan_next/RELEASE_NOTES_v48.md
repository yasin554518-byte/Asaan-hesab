# Asan Hisab v48 — Release Provenance Gate

- Version: 1.0.1+34.
- Added deterministic release provenance JSON for tagged AAB releases.
- Provenance records app version, Git commit SHA, release ref/tag, and AAB SHA-256.
- No signing password, keystore, private key, or authentication token is written to provenance.
- CI uploads the provenance file alongside the signed AAB and checksum.
- Added a source-level provenance contract test.
