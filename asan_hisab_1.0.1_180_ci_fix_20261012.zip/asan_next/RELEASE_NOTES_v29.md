# Asan Hisab v29 — Android release signing gate

Version: `1.0.1+15`

## Changes
- Added CI-safe Android release signing configuration.
- Signing material is injected only from GitHub Actions secrets and is never committed to the repository.
- Added an Android signing contract test that fails if keystore/private-key material appears in source.
- CI configures release signing before the AAB build when all four signing secrets are present; otherwise the unsigned release build path remains explicit.
- Keystore and `key.properties` are created with restrictive permissions and are not uploaded as artifacts.

## Required GitHub Actions secrets for a signed Play upload build
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`

No signing secret is included in this ZIP.
