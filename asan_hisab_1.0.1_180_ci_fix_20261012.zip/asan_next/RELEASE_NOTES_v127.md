# Asan Hisab v127

- Version: 1.0.1+113
- SyncScheduler now has an explicit paused state for background lifecycle handling.
- Entering inactive/paused/detached cancels pending automatic sync timers.
- Returning to resumed state re-enables scheduling and performs an immediate sync attempt.
- Added regression tests for paused scheduling and resume behavior.
- Android AAB build was not executed because Flutter/Android SDK is unavailable in this environment.
- Production deployment was not executed because production environment/secrets are unavailable.
