# Asan Hisab v137 — 1.0.1+123

- Statement view now shows the current closing/outstanding balance prominently.
- Statement rows now expose debit, credit, and running balance together for clearer customer/supplier reconciliation.
- Existing transactional loan/payment and sync behavior is preserved.
- Flutter/Dart and real Android-device build gates remain environment-dependent.
