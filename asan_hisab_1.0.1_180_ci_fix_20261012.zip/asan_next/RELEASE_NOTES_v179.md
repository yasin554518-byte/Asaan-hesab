# v179

Version 1.0.1+163.

- Made Returns original-transaction selection race-safe so stale async results cannot overwrite a newer selection.
- Added regression contract for selection request ordering.
