# Asan Hisab v131

Version: 1.0.1+117

- Removed a duplicate SyncQueueService import from the sync queue policy test.
- Added a schema contract gate proving the sync queue idempotency unique index exists and is applied through the v3 migration path.
- Re-ran deterministic release and sync safety checks.

This release does not claim a Flutter/Android AAB build or physical-device test when those tools/devices are unavailable in the current environment.
