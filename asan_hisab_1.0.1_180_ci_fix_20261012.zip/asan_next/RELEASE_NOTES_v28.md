# Release notes — v28 (1.0.1+14)

- Fixed a backend token-revocation security issue: configured bootstrap tokens are inserted only when first seen and no longer reactivate an existing disabled token on every request.
- Added a backend contract regression test proving a revoked device token remains unauthorized while a second device token continues to work.
- Re-ran automated release preflight checks. Android AAB build remains a CI/Flutter-SDK gate; production deployment and real two-device end-to-end sync remain unverified.
