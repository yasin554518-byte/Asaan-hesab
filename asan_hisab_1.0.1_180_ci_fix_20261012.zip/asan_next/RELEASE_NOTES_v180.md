# v180

Version 1.0.1+164.

- Added a mounted-state guard after CSV Import confirmation dialog before entering the async import state.
- Added regression coverage for CSV Import confirmation lifecycle safety.
