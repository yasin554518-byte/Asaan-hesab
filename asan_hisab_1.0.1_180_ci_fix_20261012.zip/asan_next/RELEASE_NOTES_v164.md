# Asan Hisab v164 — 1.0.1+150

- Hardened Statement party selector against a stale/deleted `initialPartyId`.
- Invalid selector values now normalize to null instead of triggering Flutter DropdownButton value assertions.
- Added source-level regression contract for the selector normalization.
