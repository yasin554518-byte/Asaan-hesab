# Asan Hisab v104

- Version: 1.0.1+90
- Hardened release provenance JSON parsing to reject duplicate keys.
- Added regression coverage for duplicate provenance keys.
- Release preflight and ZIP integrity verified in the build environment.
- Android AAB build remains skipped because Flutter/Android SDK is unavailable in this environment.
- Production deployment remains skipped because production secrets/environment are unavailable.
