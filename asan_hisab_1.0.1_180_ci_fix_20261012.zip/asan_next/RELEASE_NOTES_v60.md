# Release Notes v60 — Release Bundle Integrity Gate

- Version: 1.0.1+46.
- Added `release_bundle_integrity_contract_test.sh` to validate the release bundle contract.
- The gate verifies the AAB, checksum, and provenance artifact paths are all present in CI.
- A deterministic fixture validates canonical SHA-256 checksum format and checksum-to-AAB matching.
- Release manifests must match the application version.
- The gate explicitly rejects common signing/secret material from the release bundle fixture.
- No production credentials, signing keys, or private secrets are added to the release package.
