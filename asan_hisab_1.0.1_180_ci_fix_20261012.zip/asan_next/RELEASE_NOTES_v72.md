# Release v72 — Versioned Release Artifact Gate

- Version: 1.0.1+58
- Release artifact names now include the Git release tag (`github.ref_name`) to prevent ambiguous AAB/checksum/provenance artifacts across releases.
- CI contract test requires the versioned artifact naming rule and release-tag gate.
- No signing secrets or private key material are included in artifact names or metadata.
