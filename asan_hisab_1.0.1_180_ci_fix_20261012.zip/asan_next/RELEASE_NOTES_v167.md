# Asan Hisab v167

Version: 1.0.1+153

- Harden Statement party-list loading with retryable error state.
- Prevent invalid/deleted initial party IDs from reaching firstWhere.
- Keep cached party-list Future to avoid redundant database queries during rebuilds.
