# Asan Hisab v140

Version 1.0.1+126.

- Enhanced Statement view with total Debit, total Credit, and net movement summary.
- Kept running balance derived from the same ordered ledger rows.
- Preserved existing sync, backup, return, and financial invariant gates.
