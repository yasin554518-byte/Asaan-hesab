# Asan Hisab v135

Version: 1.0.1+121

- Centralized purchase total/remaining validation through `Money`.
- Added sale-form validation preventing a discount greater than sale gross before submission.
- Keeps financial invariants consistent between UI and service layers.
