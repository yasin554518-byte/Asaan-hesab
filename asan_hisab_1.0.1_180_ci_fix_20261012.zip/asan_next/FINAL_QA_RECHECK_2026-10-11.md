# Asan Hisab — Final QA Recheck (source-level)

Date: 2026-10-11
Version: 1.0.1+180
Target application ID: com.asanhisab.app

## Additional checks run in this recheck

Passed:
- Sync queue schema contract
- Sync worker push-failure retry contract
- Manual sync retry/backoff contract
- Latest backup discovery contract
- CI workflow structure contract
- CI artifact retention contract (14 days)
- Production token entropy contract
- Release tag integrity contract (1.0.1+180)
- Release checksum path-safety contract
- Flutter state lifecycle contract
- Statement period opening-balance display contract
- Release bundle manifest artifact-size contract
- Release provenance run-identity canonical contract (after fixing its test harness to set PROVENANCE_PATH explicitly)
- Release provenance identity-length contract
- Release provenance release-ref contract
- Release provenance identity contract

The run-identity test harness originally failed because it passed a file argument that the copied checker does not consume; it was corrected to set the documented PROVENANCE_PATH environment variable. The corrected contract test passes.

## Earlier source-level checks

The following had previously passed and remain recorded as source-level checks:
- Android prepare contract
- Android signing contract checks
- Release candidate checks, including static invariants and sale/purchase lifecycle
- Release bundle manifest identity contract
- Release artifact provenance contract
- Release provenance contract
- Release bundle integrity contract
- Release bundle manifest contract
- Release checksum generation contract
- Release static invariants
- Backend contract tests
- Sale/purchase validation and lifecycle contract

## Release blockers (not verified)

- Flutter/Dart, Android SDK, ADB, and Gradle are not installed in the current environment.
- Android platform directory has not been generated; `tool/prepare_android.sh` requires Flutter.
- Network DNS is unavailable here, so missing SDKs could not be downloaded.
- No APK/AAB was built; no physical Android installation was verified.
- Sync was checked against local contract/mock-server tests only; two-device production sync remains unverified.

## Required next actions

On a runner with Flutter and Android SDK: run `tool/prepare_android.sh`, `flutter pub get`, `dart analyze`, `flutter test`, and `flutter build appbundle --release`; configure signing secrets securely; install and test the APK on Android; and verify sync/backup/restore across two real devices before declaring release complete.

Status: source-level checks listed above passed; release build and physical-device acceptance remain blocked/unverified.

## Additional CI gate checks executed in this follow-up

Passed in this environment:
- Version consistency (`1.0.1+180`)
- Source smoke checks
- Checkout credential persistence disabled
- CI workflow structure
- Least-privilege CI permissions
- CI secret handling
- CI release-tag trigger and signing contract
- CI release-trigger safety
- Release artifact upload contract
- Release artifact completeness contract
- Release artifact uniqueness contract
- CI artifact retention (14 days)

These are source/contract checks only. They do not substitute for running the GitHub Actions workflow or building and installing the Android app.

## Additional follow-up checks executed

Passed in this environment:
- Two-device sync contract test (local test server/mock contract; not physical devices)
- Sync payload safety contract test
- Version consistency check (`1.0.1+180`)

Still blocked/unverified:
- `tool/verify_android_application_id.sh` exits because the Android platform directory has not yet been generated.
- This environment has no Flutter, Dart, Android SDK, ADB, or Gradle, and network DNS is unavailable; APK/AAB build and physical-device acceptance cannot be completed here.
