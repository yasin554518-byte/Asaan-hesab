# Asan Hisab v138 — 1.0.1+124

- Made return transactions sync-safe: returns, return items, stock movements, ledger entries, and cash transactions now receive durable CREATE envelopes atomically with the return transaction.
- Added return sync contract gate.
- Release version advanced only after the real source change.
