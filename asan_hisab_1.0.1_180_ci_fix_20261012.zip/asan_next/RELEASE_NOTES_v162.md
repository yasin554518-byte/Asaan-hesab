# Asan Hisab v162 — 1.0.1+148

- Improved Statement error handling: failed Statement loads now show a visible error state and a retry action instead of leaving the user on an indefinite spinner.
- No financial or sync semantics changed.
