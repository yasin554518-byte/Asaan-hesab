# Asan Hisab v196 — 1.0.1+179

- Fixed Sync Status retry flow so the synchronous `refresh()` method is not incorrectly awaited.
- Kept the success message after the refresh call and mounted guard.
- Updated the Sync Status lifecycle contract to assert the corrected ordering.
