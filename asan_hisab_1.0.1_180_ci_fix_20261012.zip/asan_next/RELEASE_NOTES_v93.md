# Asan Hisab v93

- Version: 1.0.1+79
- Hardened release checksum-file validation so the referenced AAB path must be the exact canonical filename `app-release.aab`.
- Updated release checksum generation to emit the canonical basename, matching the hardened validation.
- Rejects absolute paths, path traversal, and path separators in checksum artifact references.
- Added a regression contract test covering malicious `../app-release.aab` references and the valid canonical reference.
