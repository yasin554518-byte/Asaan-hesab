# Asan Hisab v23 — Release Operations

## Automated gates
- Version/application-id consistency
- Source smoke and static release checks
- Flutter analyze/test
- Android release AAB build in CI
- Release artifact presence + SHA-256 check
- Backend compile, contract tests, Docker build and `/health` smoke test

## Required real-world gates before Play publication
- Configure the production HTTPS domain/TLS certificate.
- Provision a unique authenticated token for each authorized device.
- Run end-to-end sync on two physical Android devices.
- Verify backup/restore and accounting reconciliation with representative real data.
- Configure Play Console signing/upload credentials and complete the store listing.

No private signing key or production credential belongs in this repository.
