#!/usr/bin/env bash
set -euo pipefail
# Run on the production server host. Creates a consistent SQLite backup,
# writes a checksum, and optionally removes backups older than RETENTION_DAYS.
OUT_DIR="${1:-./backups}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
mkdir -p "$OUT_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
FILE="$OUT_DIR/asan_sync_${STAMP}.sqlite3"
CONTAINER="$(docker compose -f backend/docker-compose.yml ps -q asan-hisab-sync)"
if [ -z "$CONTAINER" ]; then
  echo "ERROR: asan-hisab-sync container is not running" >&2
  exit 1
fi
docker compose -f backend/docker-compose.yml exec -T asan-hisab-sync \
  python -c "import sqlite3; s=sqlite3.connect('/data/asan_sync.sqlite3'); d=sqlite3.connect('/tmp/backup.sqlite3'); s.backup(d); d.close(); s.close()"
docker cp "$CONTAINER:/tmp/backup.sqlite3" "$FILE"
docker compose -f backend/docker-compose.yml exec -T asan-hisab-sync rm -f /tmp/backup.sqlite3
sha256sum "$FILE" > "$FILE.sha256"
# Verify the freshly-created backup before it can be treated as a valid artifact.
"$(dirname "$0")/verify_backup.sh" "$FILE"
find "$OUT_DIR" -type f -name 'asan_sync_*.sqlite3' -mtime "+$RETENTION_DAYS" -delete
find "$OUT_DIR" -type f -name 'asan_sync_*.sqlite3.sha256' -mtime "+$RETENTION_DAYS" -delete
echo "Backup: $FILE"
echo "Checksum: $FILE.sha256"
echo "Retention: $RETENTION_DAYS days"
