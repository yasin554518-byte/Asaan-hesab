#!/usr/bin/env bash
set -euo pipefail

# Verify a SQLite backup produced by backup_sync_db.sh.
# Usage: ./deploy/verify_backup.sh /path/to/asan_sync_*.sqlite3
FILE="${1:-}"
fail(){ echo "FAIL: $*" >&2; exit 1; }
[[ -n "$FILE" ]] || fail "backup path is required"
[[ -f "$FILE" ]] || fail "backup file not found: $FILE"
[[ -s "$FILE" ]] || fail "backup file is empty: $FILE"

if [[ -f "$FILE.sha256" ]]; then
  (cd "$(dirname "$FILE")" && sha256sum -c "$(basename "$FILE").sha256") >/dev/null \
    || fail "backup checksum verification failed"
else
  fail "backup checksum file is missing: $FILE.sha256"
fi

python3 - "$FILE" <<'PY'
import sqlite3, sys
path=sys.argv[1]
con=sqlite3.connect(path)
try:
    result=con.execute('PRAGMA integrity_check').fetchone()
    if not result or result[0] != 'ok':
        raise SystemExit('FAIL: SQLite integrity_check did not return ok')
    required={
        'auth_devices','operations',
    }
    tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    missing=required-tables
    if missing:
        raise SystemExit('FAIL: backup missing required tables: ' + ', '.join(sorted(missing)))
finally:
    con.close()
print('PASS: backup checksum and SQLite integrity verification')
PY
