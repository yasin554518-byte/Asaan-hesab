# Release v52 — Two-Device Sync Replay/Cursor Gate

Version: 1.0.1+38

## Added
- Real backend contract coverage for two logical mobile devices in the same business.
- Offline-queue replay scenario: Device A pushes records while Device B is offline, then B resumes and pulls from cursor 0.
- Cursor-resume invariant: acknowledged operations are not replayed after the stored cursor.
- Reverse sync path: Device B writes while Device A is offline, then A resumes and receives the new operation.
- Lost-acknowledgement replay is idempotent and cannot create duplicate operation rows.
- Stale master-data version rejection and financial-record immutability are exercised in the same two-device flow.
- CI now runs the two-device sync contract gate.

## Verification limits
- This is a backend two-device simulation using the real HTTP handler, not a physical Android-device test.
- Flutter/Android SDK is not available in this runtime, so no local AAB or physical-device test is claimed.
- Production HTTPS still requires the real deployment secrets/environment.
