# Asan Hisab v65 — Dynamic Release Version Contract

- Version: 1.0.1+51
- Release line: v65
- Removed remaining hard-coded application versions from release bundle/provenance contract fixtures.
- Release tag/provenance tests now derive the expected version from `pubspec.yaml`.
- Release manifest updated to the current version.
- Existing security, sync, backup/restore, signing and CI gates retained.
