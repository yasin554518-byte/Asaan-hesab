# آسان حساب — Asan Hisab v1.0.1

Production-oriented Flutter starter for an offline-first Afghan business ledger/accounting app.

## Implemented source layers
- SQLite database schema with v2 migration support
- WAL + foreign keys + integrity check
- Products, customers, suppliers, sales, purchases, payments, expenses, returns, stock, ledger, cash, audit and sync tables
- Atomic Sale/Purchase/Payment/Expense/Return services
- Weighted-average stock costing
- Customer/Supplier statements
- Dashboard SQL aggregation
- Backup/restore safety layer
- PIN hashing with per-record salt
- Owner/Manager/Cashier permission model
- Session auto-lock service
- Audit logging service
- Atomic invoice-number allocation
- Sync queue with pending/retry/synced states
- Sync operation table for idempotency foundation
- CSV export service
- Invoice PDF generation service (font embedding for Pashto should be added as an app asset before production PDF release)
- First-run business setup with Owner PIN
- Pashto RTL dashboard shell with quick actions

## Release limitations
Flutter/Android SDK is not installed in the current execution environment, so this source has not been compiled into APK/AAB or device-tested here. Production release still requires `flutter pub get`, analyzer/tests, Android release signing, two-device sync testing, PDF font verification, backup/restore testing, and Google Play release checks.

## Next implementation sequence
1. Complete UI screens for Sales/Purchases/Payments/Returns/Stock/Customers/Suppliers.
2. Connect all forms to the existing atomic services.
3. Add secure cloud adapter for the sync queue and conflict/idempotency handling.
4. Add CSV import with preview + atomic validation.
5. Add local notifications and settings.
6. Add automated unit/integration tests and run the full release gate in a Flutter-capable environment.

## Latest direct implementation pass
- Added production-style HomeShell navigation with Dashboard, Sales, Purchases, Customers and More sections.
- Connected first-run setup to HomeShell.
- Added a starter invariant test for money validation.
- Financial engines remain service-layer driven; UI does not write directly to SQLite.

## 2026-09-25 UI integration
- Replaced dashboard placeholders with working Sale, Purchase, Payment, Customer and Calculator screens.
- Sale/Purchase forms call the existing atomic services and prevent duplicate references using timestamp references.
- Customer/Supplier selection is loaded from SQLite.

## Latest direct implementation pass
- Fixed Payment page nullable party state declaration.
- Added Business Profile Settings UI (name, owner, phone, address, currency, invoice prefix).
- Connected Settings into the More menu.
- Product creation now atomically records opening stock movement and audit entry.
- Preserved offline-first SQLite architecture and existing service layer.

## 2026-09-25 direct continuation
- Added strict atomic product CSV import service with validation, duplicate protection and opening-stock movements.
- Added CSV Import UI using paste/preview-style result flow without adding a fragile platform file-picker dependency.
- Expanded Reports with net sales, returns, COGS, gross profit, net profit, cash, stock value and customer/supplier due.
- Connected CSV Import from the More menu.

## Latest direct implementation pass — 2026-09-25
- Sync Queue statuses are now centralized (`pending`, `retry`, `synced`, `failed`, `conflict`).
- Sync management UI now shows pending/synced/failed/conflict counts and supports retrying failed queue items.
- Fixed the previous status-case mismatch that caused the Sync UI counters to show zero for lowercase queue statuses.
- Sync UI explicitly distinguishes the offline local queue from the still-unselected cloud backend; no fake cloud sync is claimed.

## Latest direct implementation pass — Sync/DB safety
- Database schema bumped to v3 with atomic unique sync-operation index, queue status index, audit/date index, and return lookup index.
- Sync queue now has database-level idempotency protection in addition to the application guard.
- Added sync queue status counters and applied-operation tracking helpers.
- Backup verification now requires the copied database schema to match the current app schema version.
- No cloud provider is claimed as connected; the implementation remains offline-first until a real authenticated backend is configured.

## Latest direct implementation pass — Security Gate
- Added `PinGate` before opening the main app for an existing business.
- Owner PIN is verified against the salted hash already stored in `users`.
- Three failed attempts trigger a 30-second temporary lock.
- PIN input is masked and the gate is RTL/Pashto friendly.
- This is source-level security; Flutter/Android build and device QA still require a Flutter SDK/build environment.


## Latest direct implementation pass
- Added User Management UI for Owner/Manager/Cashier roles, PIN creation/reset, activation/deactivation, audit logging, and protection against disabling the final active Owner.
- Database schema upgraded to v4 with unique business-scoped usernames and active-user index.
- Existing-data migration v3→v4 included; no data reset.

## 2026-09-25 direct continuation — Offline Notifications
- Added `NotificationService` for database-backed in-app alerts.
- Alerts cover low stock, customer due, and supplier due.
- Added Pashto/RTL Alerts UI under More → خبرتیاوې.
- No OS push/cloud notification is claimed; the feature remains offline-first until a real notification adapter is configured.

## Latest direct implementation pass — cloud sync boundary
- Added `CloudSyncAdapter` as the production transport contract for two-phone sync.
- Added `SyncWorker` to process the local queue only when a real authenticated backend is configured.
- Added an explicit unconfigured adapter that fails closed instead of pretending that cloud sync is active.
- Sync envelopes carry operation ID, record ID, table, operation, device ID, version and payload.
- Queue retries are idempotent and conflict statuses are preserved locally.

## Latest direct implementation pass — HTTPS sync transport
- Added `RestCloudSyncAdapter` using HTTPS only, bearer authentication, push/pull envelopes, HTTP status validation, and deterministic JSON parsing.
- Added `SyncConfigService` for business-local sync endpoint/token configuration.
- The app still defaults to the safe unconfigured adapter; no fake cloud sync is reported.
- A production backend must enforce business isolation, authenticated devices, operationId idempotency, version/conflict rules, and TLS.


## Release checklist truth
- Source-level implementation and toolchain-independent smoke checks can be performed in this environment.
- Flutter SDK/Android SDK are not installed here, so APK/AAB build, `dart analyze`, `flutter test`, real-device QA, and Play Console submission are intentionally not claimed as completed.
- A real authenticated HTTPS backend is still required for production two-phone cloud sync.

## 2026-09-25 direct continuation — Alert severity UI
- Alerts now show a separate urgent count in the summary row.
- Critical alerts are visibly marked as `بیړنی` while preserving offline-first behavior.
- Customer/supplier alert amounts remain directly tappable into the corresponding statement.

## 2026-09-28 direct continuation — Role-gated navigation QA
- Verified the login gate carries the authenticated user role into `SessionShell`.
- Sensitive More-menu entries are gated through `PermissionService` (backup/restore, settings/sync, reports and user management).
- Added release static invariants for role-gated navigation so future edits cannot silently expose owner-only controls.
- Source smoke checks and release static invariants pass.

## 2026-10-01 direct continuation — Sync backend
- Added a standard-library Python sync backend under `backend/` matching the existing Flutter REST adapter.
- Auth tokens are bound to one business and one device; cross-business/device requests are rejected.
- Server-side operation idempotency, financial immutability conflicts, master-data version checks, and pull cursors are implemented.
- Added Dockerfile and deployment README.
- Local API contract smoke test passed for health → push → pull.

## 2026-10-01 direct continuation — Backend hardening
- Added a repeatable standard-library backend contract test covering health, authenticated push, idempotent retry, cross-device pull, and cross-business isolation.
- Added Docker Compose and environment template for the single-node backend deployment.
- App version bumped to 1.0.1+2 for the next release gate.

## Security note
Sync authentication tokens are stored in OS secure storage, not in the SQLite application database.

## Production preflight
Before deploying the sync backend, copy `backend/.env.production.example` to `backend/.env`, replace all placeholders with long random per-device tokens, then run:
`./tool/production_preflight.sh backend/.env`
The preflight fails closed on placeholders, duplicate device bindings, short tokens, or private-key material.


## 2026-10-03 v49 — Backup verification gate
- Added a production backup verifier for the sync SQLite database.
- Verifies the SHA-256 sidecar, SQLite integrity, and required sync tables before a backup is treated as restorable.
- Added a CI contract test for the backup safety gate.
