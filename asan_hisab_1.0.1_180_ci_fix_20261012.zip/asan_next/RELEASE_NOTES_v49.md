# Release v49 — Backup Verification Gate

Version: 1.0.1+35

- Added `deploy/verify_backup.sh` to verify production sync-database backups.
- Backup verification now checks the SHA-256 sidecar and SQLite `PRAGMA integrity_check`.
- The verifier also checks that the required sync tables (`auth_devices`, `operations`) exist.
- Added `tool/backup_verification_contract_test.sh` to prevent accidental removal of the backup safety gate.
- No production credentials, tokens, keystores, or private keys are stored in the repository.
- Flutter/Android AAB build and real-device/two-phone production sync remain environment-dependent and are not claimed as completed here.
