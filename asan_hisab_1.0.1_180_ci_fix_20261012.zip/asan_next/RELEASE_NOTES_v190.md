# Asan Hisab v190 — 1.0.1+173

- Hardened CSV Import Preview post-await UI update into one mounted-guarded state transition.
- Added regression contract for CSV preview lifecycle safety.
