# Asan Hisab v1.0.1+27 — Production HTTPS Smoke Hardening

- Production smoke requests now URL-encode business/device identifiers instead of interpolating them into the query string.
- Production smoke rejects configured endpoints containing a query or fragment.
- Production smoke explicitly requires HTTPS/TLS for all requests.
- Version bumped to 1.0.1+27.
