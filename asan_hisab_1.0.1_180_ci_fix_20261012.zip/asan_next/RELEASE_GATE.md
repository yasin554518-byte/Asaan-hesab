# آسان حساب — Release Gate

## Current source status
- Version: 1.0.1+17
- SQLite schema: v4
- Offline-first local transactions: implemented
- Sync queue/idempotency foundation: implemented
- Remote pull/apply with business isolation and financial immutability: implemented
- REST HTTPS sync transport: implemented (backend still required)
- Cloud backend: **not connected yet**
- Backup integrity verification: implemented
- Restore safety-copy rollback: implemented

## Critical release checks
- [ ] Flutter SDK available
- [ ] `flutter pub get` (CI gate)
- [ ] `dart analyze` (CI gate)
- [ ] `flutter test` (CI gate)
- [ ] Android release build / AAB
- [ ] Fresh install test
- [ ] Upgrade test from prior database versions
- [ ] Sale cash/credit/partial reconciliation
- [ ] Purchase cash/credit/partial reconciliation
- [ ] Customer/supplier payment reconciliation
- [ ] Sales/purchase return reconciliation
- [ ] Cash vs profit cross-check
- [ ] Backup + restore on a real device
- [ ] Two-device authenticated cloud sync test
- [ ] PDF/CSV/Pashto RTL test
- [ ] Role/PIN/auto-lock test
- [ ] 10k products / 10k customers / 50k transactions stress test

## Release blockers
1. Any sale/stock mismatch
2. Any cash/customer/supplier balance mismatch
3. Duplicate financial operation after retry/sync
4. Data loss during migration or restore
5. Unauthorized financial operation
6. Failed release build or failing tests


## Latest direct hardening pass — 2026-09-25
- Backup WAL is checkpointed with TRUNCATE before copying.
- Restore validates backup integrity and exact schema version before replacing live data.
- Restore removes stale SQLite `-wal`/`-shm` sidecars before replacement.
- Restored database is reopened and verified again before success is reported.
- A failed restore retains the pre-restore safety copy and reopens the original database.

## Security gate added
- [x] App startup PIN gate
- [x] Three wrong PIN attempts trigger temporary lock
- [x] Correct Owner PIN unlocks app
- [x] PIN plaintext never stored
- [ ] Production build/device QA of the security flow


## Latest direct implementation pass
- Added User Management UI for Owner/Manager/Cashier roles, PIN creation/reset, activation/deactivation, audit logging, and protection against disabling the final active Owner.
- Database schema upgraded to v4 with unique business-scoped usernames and active-user index.
- Existing-data migration v3→v4 included; no data reset.

## Offline notification gate
- [ ] Low-stock alert matches minimum stock threshold.
- [ ] Customer/supplier due alerts match statement balances.
- [ ] Alerts work with internet disabled.
- [ ] OS push notification is not advertised until a real adapter/backend is configured.

## Latest direct source-QA hardening — 2026-09-25
- Added `tool/smoke_check.sh` for toolchain-independent source integrity checks.
- Added `QA_SMOKE.md` documenting exactly what the smoke check verifies and what it cannot replace.
- Smoke check intentionally fails closed when core schema/security/accounting/sync files or schema v4 are missing.

## Sync transport gate
- [ ] Configure a real HTTPS backend endpoint.
- [ ] Authenticate each device; never share one static token between phones.
- [ ] Server deduplicates by `(business_id, operation_id)`.
- [ ] Server rejects cross-business record access.
- [ ] Push conflict responses are deterministic.
- [ ] Pull application is tested against immutable financial records before production.
- [ ] Two-device test passes with zero duplicate financial transactions.

## 2026-10-01 direct continuation — Sync backend implementation
- Added `backend/app.py` implementing the existing Flutter REST sync contract.
- Added token-to-business/device authentication binding.
- Added operationId idempotency and server-side business isolation.
- Added deterministic conflict handling for immutable financial records and versioned master data.
- Added monotonic pull cursor and `/health` endpoint.
- Added Docker deployment file and backend deployment notes.
- Local contract test passed: health, authenticated push, and pull/cursor flow.
- Production deployment still requires a real HTTPS domain/certificate, production token provisioning, and two physical Android devices for end-to-end QA.

## 2026-10-01 continuation — reproducible CI/release gate
- Added GitHub Actions workflow for Flutter analysis, tests, Android AAB build, backend compile and backend contract test.
- Added `RELEASE_READINESS.md` to distinguish automated checks from physical-device/production checks.
- Backend 500 responses no longer expose internal exception details to clients.

## 2026-10-01 continuation — CI Android bootstrap
- Added `tool/prepare_android.sh` to generate the Android host project reproducibly in CI.
- CI now runs the Android AAB release build instead of assuming an `android/` directory already exists.
- CI uploads the generated `app-release.aab` as an artifact.
- Version bumped to `1.0.1+3` (historical).
- Final Android application id must be confirmed before the first Play Store publication.

## v10 CI hardening
- Flutter CI pinned to 3.35.2.
- Release AAB SHA-256 checksum generated and uploaded.
- Backend Docker image build is part of CI.
- Contract tests include unauthorized access rejection.

## 2026-10-01 continuation — v1.0.1+6 verification
- Local source smoke check passed.
- Local release static invariant check passed.
- Backend Python compile passed.
- Backend contract tests passed, including unauthorized access, duplicate/idempotent push, pull, cross-business isolation, and financial conflict handling.
- CI workflow now runs source smoke/static checks before Flutter and backend release gates.
- Release metadata was synchronized to `1.0.1+6` (historical).


## v1.0.1+17 active release baseline
- Current package version is `1.0.1+17`.
- `tool/version_consistency_check.sh` verifies the active version and prevents stale release-gate metadata from being mistaken for the current release.
- Automated gates remain separate from physical-device and production deployment gates.


## v1.0.1+17 signing gate
- CI can inject Play upload signing material from GitHub Actions secrets without storing secrets in source.
- Unsigned CI builds remain explicitly non-Play-ready until signing secrets are configured.

- v52 two-device sync replay/cursor contract gate added.

- v54 production API security headers and HTTPS-only HSTS gate added.
