# Asan Hisab v194

Version: 1.0.1+177

- Expense save now checks mounted before entering saving state.
- CRUD editor controllers are disposed when the dialog is cancelled or validation exits early.
- Added expense/CRUD lifecycle regression contract test.
