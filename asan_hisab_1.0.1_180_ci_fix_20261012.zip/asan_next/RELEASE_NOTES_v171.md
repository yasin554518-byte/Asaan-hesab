# v171 — 1.0.1+157

## Change
- Hardened Purchase save error handling against widget disposal: the error SnackBar is now shown only while the Purchase page remains mounted.
- Prevents post-dispose context access after an awaited purchase transaction.

## Validation
- Purchase lifecycle regression contract passed.
