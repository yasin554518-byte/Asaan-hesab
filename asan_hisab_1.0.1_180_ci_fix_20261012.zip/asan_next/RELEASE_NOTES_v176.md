# Release Notes v176

Version: 1.0.1+160

- Hardened CSV import preview/confirm async lifecycle handling.
- Prevented post-dispose setState in CSV preview and import error/success paths.
- Added release regression coverage for CSV import lifecycle safety.
