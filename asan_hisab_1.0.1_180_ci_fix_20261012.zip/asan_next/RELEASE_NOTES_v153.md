# Asan Hisab v153

Version: 1.0.1+140

## Changes
- Fixed Statement UI period-opening scope by loading entries and opening balance together.
- Removed an invalid pre-declaration of `periodOpening` in the Statement builder.
- Statement empty-period and date-filter balances now use `StatementService.openingBalanceAt`.
- Added a regression gate for the Statement snapshot loading path.

## Validation
- Static/release contract gates run in this environment.
- Flutter/Dart/AAB/device validation remains unavailable because the SDK/device are not present.
