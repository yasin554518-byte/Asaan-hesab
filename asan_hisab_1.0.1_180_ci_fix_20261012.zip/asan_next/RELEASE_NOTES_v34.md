# Asan Hisab v1.0.1+21 — Release Notes

## Security hardening
- Added a source-tree secret-material contract.
- Added `.gitignore` protection for production environment files and Android release signing material.
- CI release signing remains secret-injected and is never stored in the project ZIP.
- The release source tree is checked to ensure no keystore or production `.env` is accidentally bundled.
