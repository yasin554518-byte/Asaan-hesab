# Release Notes v101

Version: 1.0.1+87

- Tightened release bundle manifest commit SHA validation to require the same lowercase 40-hex identity format used by release provenance.
- Added regression coverage rejecting uppercase commit SHA identities.
- Release gates and Android/production availability remain explicitly gated by the current environment.
