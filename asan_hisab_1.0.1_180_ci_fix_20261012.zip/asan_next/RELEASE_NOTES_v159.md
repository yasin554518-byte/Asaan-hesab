# Asan Hisab v159 — 1.0.1+145

- Clarified the Statement opening-balance label to explicitly identify it as the filtered-period opening balance.
- Added a source-level regression contract for the label.
