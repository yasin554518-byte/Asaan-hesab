# Release v55 — Production Configuration Safety Gate

Version: 1.0.1+42

- Hardens production preflight validation for the sync base URL.
- Requires a valid HTTPS URL when `ASAN_SYNC_BASE_URL` is supplied.
- Rejects embedded credentials, query strings, fragments, and loopback hosts in production configuration.
- Adds an automated production configuration contract test covering valid and rejected configurations.
- Keeps device-token uniqueness and minimum token-strength checks from the previous production gate.

Automated scope: configuration and source/QA gates. A real Android AAB, signed artifact, production deployment, and physical two-device test still require the corresponding environment, secrets, and devices.
