# Asan Hisab v1.0.1+74 — Release Engineering Update

- Added canonical release AAB relative-path binding to the release bundle manifest.
- Added a CI contract test ensuring the manifest records the canonical signed AAB path.
- Existing provenance, artifact identity, checksum, sync, backup, and release gates remain enforced.
- This update does not claim a real Flutter AAB build; that still requires the Flutter/Android SDK environment.
