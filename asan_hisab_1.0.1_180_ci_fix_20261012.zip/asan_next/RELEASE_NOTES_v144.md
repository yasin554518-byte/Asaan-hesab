# Asan Hisab v144

Version 1.0.1+130.

- Statement history now carries transaction notes and stable created_at ordering.
- Ledger UI displays the note alongside the transaction date when present.
- Added a statement note contract test.
