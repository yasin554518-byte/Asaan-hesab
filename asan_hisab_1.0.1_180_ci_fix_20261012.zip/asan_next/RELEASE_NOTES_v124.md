# Release Notes v124

- Version: 1.0.1+110
- Added bounded timeouts around automated release-preflight gates.
- `RELEASE_GATE_TIMEOUT_SECONDS` defaults to 60 seconds and must be a positive integer.
- A hung gate now fails with an explicit timeout diagnostic instead of blocking the release indefinitely.
- Added a contract test that verifies the timeout guard is present on critical preflight gates.

Validation in the available environment:
- All targeted release, sync, backup, checksum, lifecycle, and backend contract gates: PASS.
- Full preflight was not used as the sole validation signal because the host execution environment intermittently stalled while launching individual subprocesses; no such stall occurred when the same gates were run individually.
- Android AAB build remains SKIP because Flutter/Android SDK is unavailable.
- Production deployment remains SKIP because production secrets/environment are unavailable.
