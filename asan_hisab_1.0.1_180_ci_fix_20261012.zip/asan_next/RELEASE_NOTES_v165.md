# Asan Hisab v165 — 1.0.1+151

- Cached the Statement load future so ordinary rebuilds (including print-state changes) do not trigger duplicate database queries.
- Statement party/date/filter changes explicitly refresh the cached future.
- Statement retry now refreshes the cached future instead of rebuilding the FutureBuilder request on every build.
- Added a source-level regression contract for Statement future caching and explicit refresh triggers.
