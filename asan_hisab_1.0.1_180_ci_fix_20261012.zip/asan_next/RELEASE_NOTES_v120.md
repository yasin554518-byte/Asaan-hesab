# Release Notes v120

- Backup/Restore now discovers the latest safe local backup after app restart instead of requiring the same UI session.
- Backup discovery ignores symlink entries and only accepts the canonical `asan_hisab_backup_*.db` naming pattern.
- Restore refreshes the latest backup path before proceeding.
- Version: 1.0.1+107
