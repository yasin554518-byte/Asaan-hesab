# Asan Hisab v143

Version: 1.0.1+129

## Change
- Manual loan notes are now persisted directly on the ledger entry, so customer statements and synchronized ledger records retain the note.
- Added a focused contract test for manual-loan note persistence.

## Validation
- Source contract validation: PASS
- Release/version checks: pending final run
