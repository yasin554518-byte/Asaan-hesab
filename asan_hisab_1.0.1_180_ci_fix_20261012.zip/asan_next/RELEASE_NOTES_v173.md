# Asan Hisab v173 — 1.0.1+159

- Sale and Purchase now reject discounts greater than gross amount before service calls.
- Sale and Purchase now reject overpayment before service calls.
- Sale and Purchase guard widget lifecycle before entering the saving state.
- Added a release contract test covering these validation and lifecycle invariants.
