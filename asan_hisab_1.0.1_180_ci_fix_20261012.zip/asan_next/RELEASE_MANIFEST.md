# Asan Hisab — Release Manifest

- Version: 1.0.1+180
- Application ID: com.asanhisab.app
- Release line: v187 (CSV Import post-await lifecycle guard)
- Automated source/QA gates: PASS (see `tool/final_release_preflight.sh`)
- Production environment validation: `tool/production_preflight.sh backend/.env`

## Still requires a real environment
1. Flutter/Android SDK release AAB build.
2. Real HTTPS domain and TLS certificate.
3. Production per-device token provisioning.
4. Two physical Android devices for end-to-end sync.
5. Backup/restore and accounting reconciliation on real data.
6. Play Console signing/upload and store listing review.
- Release signing: CI-secret gated; no keystore or private key is stored in source.
