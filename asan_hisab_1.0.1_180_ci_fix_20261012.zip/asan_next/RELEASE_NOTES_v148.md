# Asan Hisab v148 — 1.0.1+134

- Added optional from/to date filtering to party Statement.
- Running balance remains based on the complete ledger history, so filtered statements do not reset balances incorrectly.
- Statement PDF uses the filtered rows' persisted running balances.
- Added contract coverage for date-range support and inclusive end-of-day semantics.
- Flutter/Dart and real Android device/AAB validation remain environment-gated.
