# Asan Hisab v156

Version: 1.0.1+142

## Change
- Statement PDF now carries the ledger note into a dedicated note column.
- Added source-level regression coverage for PDF note propagation.
