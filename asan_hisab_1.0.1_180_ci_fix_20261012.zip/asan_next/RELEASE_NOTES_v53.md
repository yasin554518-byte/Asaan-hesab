# Asan Hisab v1.0.1+39 — Sync Payload Safety Gate

- Adds strict sync envelope identifier length limits.
- Adds a 256 KiB per-operation payload limit while retaining the 2 MiB request-body limit.
- Adds an automated contract test covering oversized payload rejection, oversized identifiers, and a valid operation.
- CI runs the new sync payload safety contract before Flutter tests/builds.

Automated scope: backend contract/safety gates and source/static checks. A real Android AAB, signed artifact, production HTTPS deployment, and physical two-device test still require the corresponding environment/secrets/devices.
