# Asan Hisab v150

Version: 1.0.1+136

- Prevent reversed Statement date ranges in the UI.
- Label filtered Statement closing balance accurately.
- Added date-filter regression contracts.
