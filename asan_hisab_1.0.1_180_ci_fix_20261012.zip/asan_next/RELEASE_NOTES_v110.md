# Asan Hisab v110

- Version: 1.0.1+97
- Hardened release bundle validation so the manifest artifact SHA-256 is independently recomputed from the release AAB and must match the declared value.
- Added regression coverage for the artifact SHA/AAB consistency contract.
- Existing release, provenance, checksum, sync, and backend gates retained.
