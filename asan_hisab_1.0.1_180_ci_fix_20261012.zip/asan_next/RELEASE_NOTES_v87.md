# Asan Hisab v87

Version 1.0.1+74.
Release provenance now carries workflow name, event name, AAB artifact name, and published artifact identity, with manifest cross-checks.
