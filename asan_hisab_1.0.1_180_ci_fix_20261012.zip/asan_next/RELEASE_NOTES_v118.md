# Asan Hisab v118

- Version: 1.0.1+105
- Hardened backup/restore against symlink destinations and symlink backup inputs.
- Prevented backup destination from resolving to the live database path.
- Added backup symlink/destination safety contract test.
- Backup restore/recovery verifier smoke: PASS.
- Android AAB build is not executed in this environment because Flutter/Android SDK is unavailable.
- Production deployment is not executed because production secrets/environment are unavailable.
