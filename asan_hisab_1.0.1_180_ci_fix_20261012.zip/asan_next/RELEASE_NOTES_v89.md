# Asan Hisab v1.0.1+75 — Release Engineering Update

- Added canonical checksum artifact path binding to the release bundle manifest.
- Added a contract gate ensuring the published checksum path remains `build/app-release.aab.sha256`.
- Updated release metadata to version 1.0.1+75.
- Flutter/Android AAB build remains pending until the Flutter/Android SDK is available.
