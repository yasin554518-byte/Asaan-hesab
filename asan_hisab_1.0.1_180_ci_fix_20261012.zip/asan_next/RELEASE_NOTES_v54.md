# Release v54 — Production API Security Headers Gate

Version: 1.0.1+40

- Adds strict API response security headers: CSP, Permissions-Policy, Cross-Origin-Resource-Policy, and X-Download-Options.
- Adds conditional HSTS when the reverse proxy explicitly marks the external request as HTTPS.
- Updates the Nginx deployment example to advertise the HTTPS HSTS policy.
- Adds an automated contract test for the security headers and HTTPS-only HSTS behavior.
- CI runs the API security headers gate before Flutter tests/builds.

Automated scope: backend contract/security gates and source/static checks. A real Android AAB, signed artifact, production HTTPS deployment, and physical two-device test still require the corresponding environment/secrets/devices.
