# د آسان حساب د Android جوړولو لارښود (پښتو)

## اوسنی حالت
- د سرچینې نسخه: `1.0.1+180`
- د Android package ID: `com.asanhisab.app`
- د QA جوړولو workflow: `.github/workflows/qa-apk.yml`
- دا ZIP د Flutter سرچینه ده؛ APK نه دی.

## د APK جوړولو طریقه
1. د پروژې ټول فایلونه په GitHub repository کې پورته کړئ (د ZIP دننه د `asan_next/` محتویات، نه د ZIP فایل په توګه).
2. د repository اصلي branch نوم `main` یا `master` کړئ، یا د GitHub د **Actions** برخې څخه **QA Android APK** وټاکئ.
3. که لومړی ځل وي، په Actions کې د workflow د اجرا اجازه ورکړئ؛ بیا **Run workflow** ووهئ.
4. انتظار وکړئ چې دا پړاوونه ټول شنه شي: Prepare Android host، Flutter dependencies، Dart analyze، Flutter tests، Build installable QA APK، Upload QA APK.
5. د بریالي run په پای کې د **Artifacts** له برخې `asan-hisab-qa-apk-...` ښکته کړئ او ZIP یې خلاص کړئ؛ دننه `app-debug.apk` وي.
6. APK په ازمایښتي Android موبایل کې نصب او د حسابونو، بیک‌اپ/بېرته راګرځولو او sync ازموینې عملي کړئ.

## که workflow ناکام شي
- د ناکام پړاو log خلاص کړئ او لومړنۍ اصلي خطا اصلاح کړئ؛ بیا workflow تکرار کړئ.
- که `dart analyze` یا `flutter test` ناکام وي، APK د منل شوي build په توګه مه کاروئ.
- د Play Store لپاره QA/debug APK بسنه نه کوي. د تولیدي release لپاره signing key او د backend خوندي production configuration جلا تنظیم کړئ؛ secrets په سرچینه یا chat کې مه لیکئ.

## مهم محدودیت
د GitHub Actions اجرا یوازې هغه وخت پیلېږي چې سرچینه GitHub repository ته push شي یا workflow په GitHub کې په لاس وچلول شي. په دې محلي چاپېریال کې Flutter/Dart/Android SDK او ستاسو repository ته لاسرسی نشته؛ له همدې امله له دې سند سره APK نه دی جوړ شوی او د دوو حقیقي موبایلونو sync لا نه دی تایید شوی.
